/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  net.minecraft.util.DamageSource
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import net.minecraft.util.DamageSource;

public class GzjDamageSource
extends DamageSource {
    public GzjDamageSource() {
        super("gzj");
    }

    public boolean isCreativePlayer() {
        return false;
    }

    public boolean isDamageAbsolute() {
        return true;
    }

    public boolean isDifficultyScaled() {
        return false;
    }

    public boolean isExplosion() {
        return false;
    }

    public boolean isFireDamage() {
        return false;
    }

    public boolean isMagicDamage() {
        return true;
    }

    public boolean isProjectile() {
        return true;
    }

    public boolean isUnblockable() {
        return true;
    }
}

