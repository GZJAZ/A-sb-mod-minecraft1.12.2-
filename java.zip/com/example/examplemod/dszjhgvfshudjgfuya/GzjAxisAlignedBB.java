/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GzjAxisAlignedBB
extends AxisAlignedBB {
    public static final GzjAxisAlignedBB badAxisAlignedBB = new GzjAxisAlignedBB();

    public GzjAxisAlignedBB() {
        super(Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN);
    }

    public boolean equals(Object p_equals_1_) {
        return true;
    }

    public AxisAlignedBB expand(double x, double y, double z) {
        return this;
    }

    public AxisAlignedBB union(AxisAlignedBB other) {
        return this;
    }

    public AxisAlignedBB intersect(AxisAlignedBB other) {
        return this;
    }

    public boolean intersects(AxisAlignedBB other) {
        return true;
    }

    public boolean intersects(Vec3d min, Vec3d max) {
        return true;
    }

    public boolean intersects(double x1, double y1, double z1, double x2, double y2, double z2) {
        return true;
    }

    public boolean intersectsWithXY(Vec3d vec) {
        return true;
    }

    public boolean intersectsWithXZ(Vec3d vec) {
        return true;
    }

    public boolean intersectsWithYZ(Vec3d vec) {
        return true;
    }

    public AxisAlignedBB offset(BlockPos pos) {
        return this;
    }

    public AxisAlignedBB offset(Vec3d vec) {
        return this;
    }

    public AxisAlignedBB offset(double x, double y, double z) {
        return this;
    }

    public AxisAlignedBB setMaxY(double y2) {
        return this;
    }

    public AxisAlignedBB shrink(double value) {
        return this;
    }

    public double getAverageEdgeLength() {
        return Double.NaN;
    }

    public Vec3d getCenter() {
        return super.getCenter();
    }

    @SideOnly(value=Side.CLIENT)
    public boolean hasNaN() {
        return false;
    }

    public double calculateXOffset(AxisAlignedBB other, double offsetX) {
        return Double.NaN;
    }

    public double calculateYOffset(AxisAlignedBB other, double offsetY) {
        return Double.NaN;
    }

    public double calculateZOffset(AxisAlignedBB other, double offsetZ) {
        return Double.NaN;
    }

    public boolean contains(Vec3d vec) {
        return true;
    }

    public AxisAlignedBB contract(double x, double y, double z) {
        return this;
    }
}

