/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.PlayerControllerMP
 *  net.minecraft.stats.RecipeBook
 *  net.minecraft.stats.StatisticsManager
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.world.World;

public class GzjPlayerControllerMP
extends PlayerControllerMP {
    private final Minecraft mc;
    private final NetHandlerPlayClient connection;

    public GzjPlayerControllerMP(Minecraft mcIn, NetHandlerPlayClient netHandler) {
        super(mcIn, netHandler);
        this.mc = mcIn;
        this.connection = netHandler;
    }

    public EntityPlayerSP createPlayer(World p_192830_1_, StatisticsManager p_192830_2_, RecipeBook p_192830_3_) {
        return new GzjEntityPlayerSP(this.mc, p_192830_1_, this.connection, p_192830_2_, p_192830_3_);
    }
}

