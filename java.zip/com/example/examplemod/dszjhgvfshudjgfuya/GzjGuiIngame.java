/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.player.EntityPlayer
 */
package com.example.examplemod.dszjhgvfshudjgfuya;
import com.example.examplemod.util.GodList;
import com.example.examplemod.util.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class GzjGuiIngame
extends GzjGuiIngameForge {
    public GzjGuiIngame(Minecraft mc) {
        super(mc);
    }
    @Override
    public void renderHealth(int width, int height) {
        if (GodList.isGzjPlayer((EntityPlayer) Minecraft.getMinecraft().player)) {
            Helper.drawHealth(width, height, 20.0);
        }
        super.renderHealth(width, height);
    }
}

