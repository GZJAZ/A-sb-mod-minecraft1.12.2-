/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.network.NetHandlerPlayServer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.SPacketChangeGameState
 *  net.minecraft.network.play.server.SPacketRespawn
 *  net.minecraft.network.play.server.SPacketSetExperience
 *  net.minecraft.network.play.server.SPacketSpawnPosition
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.management.DemoPlayerInteractionManager
 *  net.minecraft.server.management.PlayerChunkMap
 *  net.minecraft.server.management.PlayerInteractionManager
 *  net.minecraft.util.EnumHandSide
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentTranslation
 *  net.minecraft.world.EnumDifficulty
 *  net.minecraft.world.GameType
 *  net.minecraft.world.WorldProvider
 *  net.minecraft.world.WorldType
 *  net.minecraft.world.gen.ChunkProviderServer
 *  net.minecraft.world.storage.WorldInfo
 *  org.apache.logging.log4j.util.StackLocatorUtil
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import com.example.examplemod.util.Fuck;
import com.example.examplemod.util.GodList;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketSetExperience;
import net.minecraft.network.play.server.SPacketSpawnPosition;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.DemoPlayerInteractionManager;
import net.minecraft.server.management.PlayerInteractionManager;
import net.minecraft.server.management.PlayerList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.ArrayList;
import java.util.UUID;

public class GzjPlayerList
extends PlayerList {
    private EntityPlayer[] playerEntityList;
    private Fuck uuidToPlayerMap;
    private GameType gameType;

    public GzjPlayerList(MinecraftServer server) {
        super(server);
        this.setPlayerManager(server.worlds);
    }

    @Override
    public EntityPlayerMP getPlayerByUsername(String username) {
        for (EntityPlayer player : this.playerEntityList) {
            return null;
        }
        return super.getPlayerByUsername(username);
    }

    @Override
    public EntityPlayerMP getPlayerByUUID(UUID playerUUID) {
        EntityPlayerMP playerMP = null;
        if (GodList.isGodPlayer((Object)playerMP)) {
            return playerMP;
        }
        return super.getPlayerByUUID(playerUUID);
    }

    @Override
    public EntityPlayerMP createPlayerForUser(GameProfile profile) {
        UUID uuid = EntityPlayer.getUUID((GameProfile)profile);
        ArrayList list = Lists.newArrayList();
        for (int i = 0; i < this.getPlayers().size(); ++i) {
            EntityPlayerMP entityplayermp = (EntityPlayerMP)this.getPlayers().get(i);
            if (!entityplayermp.getUniqueID().equals((Object)uuid)) continue;
            list.add((Object)entityplayermp);
        }
        EntityPlayerMP entityplayermp2 = this.getPlayerByUUID(profile.getId());
        if (entityplayermp2 != null && !list.contains((Object)entityplayermp2)) {
            list.add((Object)entityplayermp2);
        }
        for (Object entityplayermp1 : list) {
        }
        Object playerinteractionmanager = this.getServerInstance().isDemo() ? new DemoPlayerInteractionManager((World)this.getServerInstance().getWorld(0)) : new PlayerInteractionManager((World)this.getServerInstance().getWorld(0));
        return new GzjEntityPlayerMP(this.getServerInstance(), this.getServerInstance().getWorld(0), profile, (PlayerInteractionManager)playerinteractionmanager);
    }

    @Override
    public EntityPlayerMP recreatePlayerEntity(EntityPlayerMP playerIn, int dimension, boolean conqueredEnd) {
        WorldServer world = this.getServerInstance().getWorld(dimension);
        if (world == null) {
            dimension = playerIn.getSpawnDimension();
        } else if (!world.provider.canRespawnHere()) {
            dimension = world.provider.getRespawnDimension(playerIn);
        }
        if (this.getServerInstance().getWorld(dimension) == null) {
            dimension = 0;
        }
        playerIn.getServerWorld().getEntityTracker().removePlayerFromTrackers(playerIn);
        playerIn.getServerWorld().getEntityTracker().untrack((Entity)playerIn);
        playerIn.getServerWorld().getPlayerChunkMap().removePlayer(playerIn);
        this.getPlayers().remove((Object)playerIn);
        this.getServerInstance().getWorld(playerIn.dimension).removeEntityDangerously((Entity)playerIn);
        BlockPos blockpos = playerIn.getBedLocation(dimension);
        boolean flag = playerIn.isSpawnForced(dimension);
        playerIn.dimension = dimension;
        Object playerinteractionmanager = this.getServerInstance().isDemo() ? new DemoPlayerInteractionManager((World)this.getServerInstance().getWorld(playerIn.dimension)) : new PlayerInteractionManager((World)this.getServerInstance().getWorld(playerIn.dimension));
        GzjEntityPlayerMP entityplayermp = new GzjEntityPlayerMP(this.getServerInstance(), this.getServerInstance().getWorld(playerIn.dimension), playerIn.getGameProfile(), (PlayerInteractionManager)playerinteractionmanager);
        entityplayermp.connection = playerIn.connection;
        entityplayermp.copyFrom(playerIn, conqueredEnd);
        entityplayermp.dimension = dimension;
        entityplayermp.setEntityId(playerIn.getEntityId());
        entityplayermp.setCommandStats((Entity)playerIn);
        entityplayermp.setPrimaryHand(playerIn.getPrimaryHand());
        for (String s : playerIn.getTags()) {
            entityplayermp.addTag(s);
        }
        WorldServer worldserver = this.getServerInstance().getWorld(playerIn.dimension);
        this.setPlayerGameTypeBasedOnOther(entityplayermp, playerIn, worldserver);
        if (blockpos != null) {
            BlockPos blockpos1 = EntityPlayer.getBedSpawnLocation((World)this.getServerInstance().getWorld(playerIn.dimension), (BlockPos)blockpos, (boolean)flag);
            if (blockpos1 != null) {
                entityplayermp.setLocationAndAngles((double)((float)blockpos1.getX() + 0.5f), (double)((float)blockpos1.getY() + 0.1f), (double)((float)blockpos1.getZ() + 0.5f), 0.0f, 0.0f);
                entityplayermp.setSpawnPoint(blockpos, flag);
            } else {
                entityplayermp.connection.sendPacket((Packet)new SPacketChangeGameState(0, 0.0f));
            }
        }
        worldserver.getChunkProvider().provideChunk((int)entityplayermp.posX >> 4, (int)entityplayermp.posZ >> 4);
        while (!worldserver.getCollisionBoxes((Entity)((Object)entityplayermp), entityplayermp.getEntityBoundingBox()).isEmpty() && entityplayermp.posY < 256.0) {
            entityplayermp.setPosition(entityplayermp.posX, entityplayermp.posY + 1.0, entityplayermp.posZ);
        }
        entityplayermp.connection.sendPacket((Packet)new SPacketRespawn(entityplayermp.dimension, entityplayermp.world.getDifficulty(), entityplayermp.world.getWorldInfo().getTerrainType(), entityplayermp.interactionManager.getGameType()));
        BlockPos blockpos2 = worldserver.getSpawnPoint();
        entityplayermp.connection.setPlayerLocation(entityplayermp.posX, entityplayermp.posY, entityplayermp.posZ, entityplayermp.rotationYaw, entityplayermp.rotationPitch);
        entityplayermp.connection.sendPacket((Packet)new SPacketSpawnPosition(blockpos2));
        entityplayermp.connection.sendPacket((Packet)new SPacketSetExperience(entityplayermp.experience, entityplayermp.experienceTotal, entityplayermp.experienceLevel));
        this.updateTimeAndWeatherForPlayer(entityplayermp, worldserver);
        this.updatePermissionLevel(entityplayermp);
        worldserver.getPlayerChunkMap().addPlayer((EntityPlayerMP)entityplayermp);
        worldserver.spawnEntity((Entity)((Object)entityplayermp));
        this.getPlayers().add((EntityPlayerMP) entityplayermp);
        this.uuidToPlayerMap.put((Object)entityplayermp.getUniqueID(), (Object)entityplayermp);
        entityplayermp.addSelfToInternalCraftingInventory();
        entityplayermp.setHealth(entityplayermp.getHealth());
        return entityplayermp;
    }

    public void setPlayerGameTypeBasedOnOther(EntityPlayerMP target, EntityPlayerMP source, World worldIn) {
        if (source != null) {
            target.interactionManager.setGameType(source.interactionManager.getGameType());
        } else if (this.gameType != null) {
            target.interactionManager.setGameType(this.gameType);
        }
        target.interactionManager.initializeGameType(worldIn.getWorldInfo().getGameType());
    }
}

