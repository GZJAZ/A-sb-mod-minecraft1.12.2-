/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MouseHelper
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import com.example.examplemod.util.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.util.MouseHelper;

public class GzjMouseHelper
extends MouseHelper {
    private final Minecraft mc = Minecraft.getMinecraft();

    public void ungrabMouseCursor() {
        if (this.mc.currentScreen == null) {
            return;
        }
        if (!Helper.isAllowGui(this.mc.currentScreen)) {
            this.mc.currentScreen = null;
            return;
        }
        super.ungrabMouseCursor();
    }
}

