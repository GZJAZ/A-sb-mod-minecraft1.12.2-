/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.ArrayList
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.function.Function
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraftforge.client.event.GuiOpenEvent
 *  net.minecraftforge.client.event.GuiScreenEvent
 *  net.minecraftforge.client.event.GuiScreenEvent$DrawScreenEvent
 *  net.minecraftforge.client.event.GuiScreenEvent$DrawScreenEvent$Pre
 *  net.minecraftforge.client.event.RenderGameOverlayEvent
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$Pre
 *  net.minecraftforge.client.event.RenderLivingEvent
 *  net.minecraftforge.client.event.RenderLivingEvent$Post
 *  net.minecraftforge.client.event.RenderLivingEvent$Pre
 *  net.minecraftforge.client.event.RenderSpecificHandEvent
 *  net.minecraftforge.client.event.RenderTooltipEvent
 *  net.minecraftforge.client.event.RenderTooltipEvent$Pre
 *  net.minecraftforge.event.entity.EntityEvent
 *  net.minecraftforge.event.entity.EntityEvent$CanUpdate
 *  net.minecraftforge.event.entity.EntityJoinWorldEvent
 *  net.minecraftforge.event.entity.EntityMobGriefingEvent
 *  net.minecraftforge.event.entity.item.ItemTossEvent
 *  net.minecraftforge.event.entity.living.LivingAttackEvent
 *  net.minecraftforge.event.entity.living.LivingDamageEvent
 *  net.minecraftforge.event.entity.living.LivingDeathEvent
 *  net.minecraftforge.event.entity.living.LivingEvent
 *  net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent
 *  net.minecraftforge.event.entity.living.LivingHurtEvent
 *  net.minecraftforge.event.entity.player.ItemTooltipEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$RightClickItem
 *  net.minecraftforge.fml.common.FMLLog
 *  net.minecraftforge.fml.common.Loader
 *  net.minecraftforge.fml.common.MinecraftDummyContainer
 *  net.minecraftforge.fml.common.ModContainer
 *  net.minecraftforge.fml.common.eventhandler.ASMEventHandler
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.IContextSetter
 *  net.minecraftforge.fml.common.eventhandler.IEventExceptionHandler
 *  net.minecraftforge.fml.common.eventhandler.IEventListener
 *  net.minecraftforge.fml.common.eventhandler.IGenericEvent
 *  net.minecraftforge.fml.common.eventhandler.ListenerList
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import com.example.examplemod.core.EventUtil;
import com.example.examplemod.event.GzjBladeTickEvent;
import com.example.examplemod.event.GzjEvent;
import com.google.common.base.Throwables;
import com.google.common.cache.AbstractCache;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.EntityMobGriefingEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class GzjBladeEventBus
extends EventBus {
    public static final EventBus GZj_EVENT_BUS = new GzjBladeEventBus();
    public static EventBus Azzz;
    private int busID;
    private AbstractCache listenerOwners;

    @Override
    public boolean post(Event event) {
        int index = 0;
        if (event instanceof ItemTooltipEvent) {
            GzjEvent.onOnlyLoveItemToolTip((ItemTooltipEvent)event);
        }
        if (event instanceof LivingAttackEvent) {
            GzjEvent.onOnlyLoveLivingAttack((LivingAttackEvent)event);
        }
        if (event instanceof LivingDeathEvent) {
            GzjEvent.onOnlyLoveLivingDeath((LivingDeathEvent)event);
        }
        if (event instanceof LivingHurtEvent) {
            GzjEvent.onOnlyLoveLivingHurt((LivingHurtEvent)event);
        }
        if (event instanceof LivingDamageEvent) {
            GzjEvent.onOnlyLoveLivingDamage((LivingDamageEvent)event);
        }
        if (event instanceof GuiOpenEvent) {
            GzjEvent.onOnlyLoveGuiOpenEvent((GuiOpenEvent)event);
        }
        if (event instanceof GuiScreenEvent.DrawScreenEvent.Pre) {
            GzjEvent.onOnlyLoveDrawScreen((GuiScreenEvent.DrawScreenEvent.Pre)event);
        }
        if (event instanceof RenderGameOverlayEvent.Pre) {
            GzjEvent.onOnlyLoveOverlayRender((RenderGameOverlayEvent.Pre)event);
        }
        if (event instanceof EntityEvent.CanUpdate) {
            GzjEvent.onOnlyLoveCanUpdataEntity((EntityEvent.CanUpdate)event);
        }
        if (event instanceof ItemTossEvent) {
            GzjEvent.onOnlyLoveItemToss((ItemTossEvent)event);
        }
        if (event instanceof EntityMobGriefingEvent) {
            GzjEvent.onOnlyLoveEntityMobGriefing((EntityMobGriefingEvent)event);
        }
        if (event instanceof TickEvent.PlayerTickEvent) {
            GzjEvent.onOnlyLovePlayerTick((TickEvent.PlayerTickEvent)event);
        }
        if (event instanceof LivingEvent.LivingUpdateEvent) {
            GzjEvent.onOnlyLoveLivingUpdate((LivingEvent.LivingUpdateEvent)event);
        }
        if (event instanceof RenderTooltipEvent.Pre) {
            GzjEvent.onOnlyLoveRenderTooltip((RenderTooltipEvent.Pre)event);
        }
        if (event instanceof RenderLivingEvent.Pre) {
            GzjEvent.onOnlyLoveRenderLivingPre((RenderLivingEvent.Pre)event);
        }
        if (event instanceof RenderLivingEvent.Post) {
            GzjEvent.onOnlyLoveRenderLivingPost((RenderLivingEvent.Post)event);
        }
        if (event instanceof RenderLivingEvent) {
            GzjEvent.onOnlyLoveRenderLivingEvent((RenderLivingEvent)event);
        }
        if (event instanceof GzjBladeTickEvent) {
            GzjEvent.onOnlyLoveItemTickEvent((GzjBladeTickEvent) event);
        }
        if (event instanceof EntityJoinWorldEvent) {
            GzjEvent.onOnlyLoveEntityJoin((EntityJoinWorldEvent)event);
        }
        if (event instanceof TickEvent.ClientTickEvent) {
            GzjEvent.onOnlyLoveClientTickEvent((TickEvent.ClientTickEvent)event);
        }
        if (event instanceof PlayerInteractEvent.RightClickItem) {
            EventUtil.onOnlyLoveRightClickItem((PlayerInteractEvent.RightClickItem)event);
        }
        if (event instanceof RenderLivingEvent.Pre) {
            EventUtil.onOnlyLoveRenderLiving((RenderLivingEvent.Pre<AbstractClientPlayer>)((RenderLivingEvent.Pre)event));
        }
        if (event instanceof RenderSpecificHandEvent) {
            EventUtil.onOnlyLoveRenderHand((RenderSpecificHandEvent)event);
        }
        this.unregister((Object)event);
        IEventListener[] listeners = event.getListenerList().getListeners(this.busID);
        try {
            for (index = 0; index < listeners.length; ++index) {
                listeners[index].invoke(event);
            }
        }
        catch (Throwable throwable) {
            Throwables.throwIfUnchecked(throwable);
            throw new RuntimeException(throwable);
        }
        return event.isCancelable() && event.isCanceled();
    }

    @Override
    public void register(Object target) {
        if (target.getClass().getName().startsWith("net.minecraft.client.mods.mmr.only_love_sword.") || target.getClass().getName().startsWith("newking.wzz.")) {
            boolean isStatic;
            ModContainer activeModContainer = Loader.instance().activeModContainer();
            if (activeModContainer == null) {
                FMLLog.log.error("Unable to determine registrant mod for {}. This is a critical error and should be impossible", target, (Object)new Throwable());
                activeModContainer = Loader.instance().getMinecraftModContainer();
            }
            this.listenerOwners.put(target, (Object)activeModContainer);
            boolean bl = isStatic = target.getClass() == Class.class;
            block2 : for (Method method : (isStatic ? (Class)target : target.getClass()).getMethods()) {
                if (isStatic && !Modifier.isStatic((int)method.getModifiers()) || !isStatic && Modifier.isStatic((int)method.getModifiers())) continue;
                Iterable<? extends Object> supers = null;
                for (Object cls : supers) {
                    Method real = cls.getClass().getEnclosingMethod();
                    if (!real.isAnnotationPresent(SubscribeEvent.class)) continue;
                    Class[] parameterTypes = method.getParameterTypes();
                    if (parameterTypes.length != 1) {
                        throw new IllegalArgumentException("Method " + (Object)method + " has @SubscribeEvent annotation, but requires " + parameterTypes.length + " arguments.  Event handler methods must require a single argument.");
                    }
                    Class eventType = parameterTypes[0];
                    if (!Event.class.isAssignableFrom(eventType)) {
                        throw new IllegalArgumentException("Method " + (Object)method + " has @SubscribeEvent annotation, but takes a argument that is not an Event " + (Object)eventType);
                    }
                    this.register(eventType, target, real, activeModContainer);
                    continue block2;
                }
            }
        }
    }

    private void register(Class<?> eventType, Object target, Method method, final ModContainer owner) {
        try {
            ASMEventHandler asm;
            Constructor ctr = eventType.getConstructor(new Class[0]);
            ctr.setAccessible(true);
            Event event = (Event)ctr.newInstance(new Object[0]);
            Object listener = asm = new ASMEventHandler(target, method, owner, IGenericEvent.class.isAssignableFrom(eventType));
            if (IContextSetter.class.isAssignableFrom(eventType)) {
                listener = new IEventListener(){

                    public void invoke(Event event) {
                        ModContainer old = Loader.instance().activeModContainer();
                        Loader.instance().setActiveModContainer(owner);
                        ((IContextSetter)event).setModContainer(owner);
                        asm.invoke(event);
                        Loader.instance().setActiveModContainer(old);
                    }
                };
            }
            event.getListenerList().register(this.busID, asm.getPriority(), (IEventListener)listener);
        }
        catch (Exception e) {
            FMLLog.log.error("Error registering event handler: {} {} {}", (Object)owner, eventType, (Object)method, (Object)e);
        }
    }

    @Override
    public void unregister(Object object) {
        if (!object.getClass().getName().startsWith("net.minecraft.client.mods.mmr.only_love_sword.") && !object.getClass().getName().startsWith("netking.wzz.")) {
        }
    }

}

