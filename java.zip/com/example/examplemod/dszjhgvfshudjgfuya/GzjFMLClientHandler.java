/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.network.INetHandler
 *  net.minecraft.network.NetworkManager
 *  net.minecraftforge.fml.client.FMLClientHandler
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.INetHandler;
import net.minecraftforge.fml.client.FMLClientHandler;

public class GzjFMLClientHandler
extends FMLClientHandler {
    public void setPlayClient(NetHandlerPlayClient netHandlerPlayClient) {
        netHandlerPlayClient = new NetHandlerPlayClient(netHandlerPlayClient.guiScreenServer, netHandlerPlayClient.getNetworkManager(), netHandlerPlayClient.getGameProfile());
        netHandlerPlayClient.getNetworkManager().setNetHandler((INetHandler)netHandlerPlayClient);
        super.setPlayClient(netHandlerPlayClient);
    }
}

