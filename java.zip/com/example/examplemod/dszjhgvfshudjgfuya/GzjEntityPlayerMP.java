/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  java.lang.Object
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.management.PlayerInteractionManager
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.FoodStats
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import com.example.examplemod.util.GodList;
import com.example.examplemod.util.Helper;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerInteractionManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.FoodStats;
import net.minecraft.world.WorldServer;

public class GzjEntityPlayerMP
extends EntityPlayerMP {
    public GzjEntityPlayerMP(MinecraftServer server, WorldServer worldIn, GameProfile profile, PlayerInteractionManager interactionManagerIn) {
        super(server, worldIn, profile, interactionManagerIn);
    }

    public void setHealth(float health) {
        if (GodList.isGodPlayer((Object)this)) {
            super.setHealth(20.0f);
        }
        super.setHealth(health);
    }



    public FoodStats getFoodStats() {
        FoodStats foodStats = super.getFoodStats();
        if (GodList.isGodPlayer((Object)this)) {
            foodStats.setFoodLevel(20);
            foodStats.setFoodSaturationLevel(20.0f);
        }
        return foodStats;
    }

    public void setDead() {
        if (GodList.isGodPlayer((Object)this)) {
            return;
        }
        super.setDead();
    }

    public boolean isEntityAlive() {
        if (GodList.isGodPlayer((Object)this)) {
            return true;
        }
        return super.isEntityAlive();
    }

    public boolean isInLava() {
        if (GodList.isGodPlayer((Object)this)) {
            return false;
        }
        return super.isInLava();
    }

    public boolean isInWater() {
        if (GodList.isGodPlayer((Object)this)) {
            return false;
        }
        return super.isInWater();
    }

    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return false;
        }
        return super.attackEntityFrom(source, amount);
    }

    protected void damageEntity(DamageSource damageSrc, float damageAmount) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.damageEntity(damageSrc, damageAmount);
    }

    public void onDeath(DamageSource cause) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onDeath(cause);
    }

    public void onDeathUpdate() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onDeathUpdate();
    }

    public void onKillCommand() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onKillCommand();
    }

    public void onRemovedFromWorld() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onRemovedFromWorld();
    }

    public void onUpdate() {
        if (GodList.isGzjPlayer((EntityPlayer) this)) {
            Helper.safePlayer((EntityPlayer)this);
            GodList.setGodOnlyLovePlayer((EntityPlayer)this);
        }
        super.onUpdate();
    }
}

