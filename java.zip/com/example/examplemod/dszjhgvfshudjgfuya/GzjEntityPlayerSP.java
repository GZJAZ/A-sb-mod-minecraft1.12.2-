/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.stats.RecipeBook
 *  net.minecraft.stats.StatisticsManager
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.FoodStats
 */
package com.example.examplemod.dszjhgvfshudjgfuya;

import com.example.examplemod.core.EventUtil;
import com.example.examplemod.util.GodList;
import com.example.examplemod.util.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.FoodStats;
import net.minecraft.world.World;

public class GzjEntityPlayerSP
extends EntityPlayerSP {
    public GzjEntityPlayerSP(Minecraft p_i47378_1_, World p_i47378_2_, NetHandlerPlayClient p_i47378_3_, StatisticsManager p_i47378_4_, RecipeBook p_i47378_5_) {
        super(p_i47378_1_, p_i47378_2_, p_i47378_3_, p_i47378_4_, p_i47378_5_);
    }

    public void setHealth(float health) {
        if (GodList.isGzjPlayer((EntityPlayer) this)) {
            super.setHealth(20.0f);
        }
        super.setHealth(health);
    }

    public float getHealth() {
        return EventUtil.getHealth((EntityLivingBase)((Object)this));
    }

    public float getMaxHealth() {
        if (GodList.isGodPlayer((Object)this)) {
            return 20.0f;
        }
        return super.getMaxHealth();
    }

    public FoodStats getFoodStats() {
        FoodStats foodStats = super.getFoodStats();
        if (GodList.isGodPlayer((Object)this)) {
            foodStats.setFoodLevel(20);
            foodStats.setFoodSaturationLevel(20.0f);
        }
        return foodStats;
    }

    public void setDead() {
        if (GodList.isGodPlayer((Object)this)) {
            return;
        }
        super.setDead();
    }

    public boolean isEntityAlive() {
        if (GodList.isGodPlayer((Object)this)) {
            return true;
        }
        return super.isEntityAlive();
    }

    public boolean isInLava() {
        if (GodList.isGodPlayer((Object)this)) {
            return false;
        }
        return super.isInLava();
    }

    public boolean isInWater() {
        if (GodList.isGodPlayer((Object)this)) {
            return false;
        }
        return super.isInWater();
    }

    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return false;
        }
        return super.attackEntityFrom(source, amount);
    }

    protected void damageEntity(DamageSource damageSrc, float damageAmount) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.damageEntity(damageSrc, damageAmount);
    }

    public void onDeath(DamageSource cause) {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onDeath(cause);
    }

    public void onDeathUpdate() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onDeathUpdate();
    }

    public void onKillCommand() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onKillCommand();
    }

    public void onRemovedFromWorld() {
        if (GodList.isGodPlayer((Object)this)) {
            Helper.safePlayer((EntityPlayer)this);
            return;
        }
        super.onRemovedFromWorld();
    }

    public void onUpdate() {
        if (GodList.isGodPlayer((Object)this)) {
            GodList.setGodOnlyLovePlayer((EntityPlayer)this);
            Helper.safePlayer((EntityPlayer)this);
        }
        super.onUpdate();
    }
}

