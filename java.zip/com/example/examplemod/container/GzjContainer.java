/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  net.minecraftforge.fml.common.DummyModContainer
 *  net.minecraftforge.fml.common.LoadController
 *  net.minecraftforge.fml.common.ModMetadata
 *  net.minecraftforge.fml.relauncher.IFMLLoadingPlugin
 *  net.minecraftforge.fml.relauncher.IFMLLoadingPlugin$MCVersion
 *  net.minecraftforge.fml.relauncher.IFMLLoadingPlugin$Name
 */
package com.example.examplemod.container;

import net.minecraftforge.fml.common.DummyModContainer;
import net.minecraftforge.fml.common.LoadController;
import net.minecraftforge.fml.common.ModMetadata;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

@IFMLLoadingPlugin.MCVersion(value="1.12.2")
@IFMLLoadingPlugin.Name(value="Gzj Core")
public class GzjContainer
extends DummyModContainer {
    public static ModMetadata Meta;

    public GzjContainer() {
        super(new ModMetadata());
        Meta = this.getMetadata();
        GzjContainer.Meta.modId = "Gzj Core";
        GzjContainer.Meta.name = "Gzj Core";
        GzjContainer.Meta.version = "1.12.2";
    }

    public boolean registerBus(EventBus bus, LoadController controller) {
        bus.register((Object)this);
        return true;
    }
}

