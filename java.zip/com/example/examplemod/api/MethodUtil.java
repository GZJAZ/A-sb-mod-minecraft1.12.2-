/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package com.example.examplemod.api;

import java.lang.reflect.Method;

public interface MethodUtil {
    public /* varargs */ Method getMethod(Class<?> var1, String var2, Class<?> ... var3) throws NoSuchMethodException, NoSuchFieldException;

    public /* varargs */ Method findMethod(Class<?> var1, String var2, Class<?> ... var3) throws NoSuchFieldException;
}

