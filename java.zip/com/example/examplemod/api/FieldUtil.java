/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 */
package com.example.examplemod.api;

import java.lang.reflect.Field;

public interface FieldUtil {
    public Field getField(Class<?> var1, String var2) throws NoSuchFieldException;

    public /* varargs */ Field findField(Class<?> var1, String ... var2) throws NoSuchFieldException;
}

