/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.HashMap
 *  java.util.Map
 */
package com.example.examplemod.api;

import com.example.examplemod.util.Helper;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
public class ClassHelper
implements FieldUtil,
MethodUtil {
    private static ClassHelper classHelper;
    private final Map<String, Field> fields = new HashMap();
    private final Map<String, Method> methods = new HashMap();

    public ClassHelper() {
        classHelper = this;
    }

    public static ClassHelper getClassHelper() {
        if (classHelper == null) {
            classHelper = new ClassHelper();
        }
        return classHelper;
    }

    public void setField(Class<?> clas, String name, Object key, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field f = this.getField(clas, name);
        if (Modifier.isStatic((int)f.getModifiers()) && !Modifier.isFinal((int)f.getModifiers())) {
            f.setAccessible(true);
            f.set(key, value);
        } else {
            f.setAccessible(true);
            f.set((Object)key.toString(), f.get((Object)value.toString()));
        }
        if (Modifier.isFinal((int)f.getModifiers())) {
            Helper.killFinalField(f);
        }
    }

    public /* varargs */ void setMethods(Class<?> classes, String name, Object key, Object value, Class<?> ... types) throws NoSuchFieldException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method method = this.getMethod(classes, name, types);
        if (Modifier.isStatic((int)method.getModifiers()) && !Modifier.isFinal((int)method.getModifiers())) {
            method.setAccessible(true);
            method.invoke(key, new Object[]{value});
        } else {
            method.setAccessible(true);
            method.invoke((Object)key.toString(), new Object[]{this.methods.get((Object)value.toString())});
        }
    }

    @Override
    public Field getField(Class<?> c, String fieldNames) throws NoSuchFieldException {
        for (Field field : c.getDeclaredFields()) {
            if (field == null || !Modifier.isStatic((int)field.getModifiers()) || Modifier.isFinal((int)field.getModifiers())) continue;
            field.setAccessible(true);
        }
        if (c.getDeclaredField(fieldNames) == null) {
            return null;
        }
        return this.findField(c, fieldNames);
    }

    @Override
    public /* varargs */ Field findField(Class<?> clazz, String ... fieldNames) throws NoSuchFieldException {
        for (String string : fieldNames) {
            Field field = (Field)this.fields.get((Object)(clazz.toString() + "|" + string));
            if (field == null) {
                try {
                    field = clazz.getDeclaredField(string);
                    field.setAccessible(true);
                    this.fields.put((String) (clazz.toString() + "|" + string), (Field) field);
                    return field;
                }
                catch (NoSuchFieldException noSuchFieldException) {
                    continue;
                }
            }
            return field;
        }
        throw new NoSuchFieldException("Not Found Field");
    }

    @Override
    public /* varargs */ Method getMethod(Class<?> c, String fieldName, Class<?> ... types) throws NoSuchMethodException, NoSuchFieldException {
        for (Method method : c.getDeclaredMethods()) {
            if (method == null || !Modifier.isStatic((int)method.getModifiers()) || Modifier.isFinal((int)method.getModifiers())) continue;
            method.setAccessible(true);
        }
        if (c.getDeclaredMethod(fieldName, types) == null) {
            return null;
        }
        return this.findMethod(c, fieldName, types);
    }

    @Override
    public /* varargs */ Method findMethod(Class<?> clazz, String fieldNames, Class<?> ... types) throws NoSuchFieldException {
        Method method = (Method)this.methods.get((Object)(clazz.toString() + "|"));
        if (method == null) {
            try {
                method = clazz.getDeclaredMethod(fieldNames, types);
                method.setAccessible(true);
                this.methods.put((String) (clazz.toString() + "|"), (Method) method);
                return method;
            }
            catch (NoSuchMethodException noSuchMethodException) {}
        } else {
            return method;
        }
        throw new NoSuchFieldException("Not Found Method");
    }
}

