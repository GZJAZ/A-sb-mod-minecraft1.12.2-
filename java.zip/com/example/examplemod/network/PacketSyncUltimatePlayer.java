package com.example.examplemod.network;

import com.example.examplemod.util.GzjUtil;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketSyncUltimatePlayer
        implements IMessageHandler<PacketSyncUltimatePlayer.MessageSyncUltimatePlayer, IMessage> {
    public static class MessageSyncUltimatePlayer implements IMessage {
        private String name;

        public MessageSyncUltimatePlayer() {
        }

        public MessageSyncUltimatePlayer(String name) {
            this.name = name;
        }

        @Override
        public void fromBytes(ByteBuf buf) {
            byte[] buffer = new byte[buf.readableBytes()];
            buf.readBytes(buffer);
            name = new String(buffer);
        }

        @Override
        public void toBytes(ByteBuf buf) {
            buf.writeBytes(name.getBytes());
        }

        public String getName() {
            return name;
        }

    }

    @Override
    public IMessage onMessage(MessageSyncUltimatePlayer message, MessageContext ctx) {
        GzjUtil.addUltimatePlayer(message.getName());
        return null;
    }
}
