/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.awt.Color
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.List
 *  java.util.Random
 *  mods.flammpfeil.slashblade.client.model.obj.Face
 *  mods.flammpfeil.slashblade.client.model.obj.WavefrontObject
 *  mods.flammpfeil.slashblade.entity.EntitySlashDimension
 *  mods.flammpfeil.slashblade.util.ResourceLocationRaw
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.client.renderer.texture.TextureManager
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.opengl.GL11
 */
package com.example.examplemod.entity.render;

import mods.flammpfeil.slashblade.client.model.obj.Face;
import mods.flammpfeil.slashblade.client.model.obj.WavefrontObject;
import mods.flammpfeil.slashblade.entity.EntitySlashDimension;
import mods.flammpfeil.slashblade.util.ResourceLocationRaw;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class RenderSuperDimension
extends Render {
    public static WavefrontObject model = null;
    public static ResourceLocationRaw modelLocation = new ResourceLocationRaw("flammpfeil.slashblade", "model/util/slashdim.obj");
    public static ResourceLocationRaw textureLocation = new ResourceLocationRaw("flammpfeil.slashblade", "model/util/slashdim.png");

    public RenderSuperDimension(RenderManager renderManager) {
        super(renderManager);
    }

    private TextureManager engine() {
        return this.renderManager.renderEngine;
    }

    public void doRender(Entity entity, double x, double y, double z, float yaw, float partialRenderTick) {
        if (this.renderOutlines) {
            GlStateManager.disableLighting();
            GlStateManager.setActiveTexture((int)OpenGlHelper.lightmapTexUnit);
            GlStateManager.disableTexture2D();
            GlStateManager.setActiveTexture((int)OpenGlHelper.defaultTexUnit);
            GlStateManager.enableColorMaterial();
            float cycleTicks = 40.0f;
            float b = Math.abs((float)((float)entity.ticksExisted % cycleTicks / cycleTicks - 0.5f)) + 0.5f;
            GlStateManager.enableOutlineMode((int)Color.getHSBColor((float)0.0f, (float)0.0f, (float)b).getRGB());
        }
        this.renderModel(entity, x, y, z, yaw, partialRenderTick);
        if (this.renderOutlines) {
            GlStateManager.disableOutlineMode();
            GlStateManager.disableColorMaterial();
            GlStateManager.enableLighting();
            GlStateManager.setActiveTexture((int)OpenGlHelper.lightmapTexUnit);
            GlStateManager.enableTexture2D();
            GlStateManager.setActiveTexture((int)OpenGlHelper.defaultTexUnit);
        }
    }

    public void renderModel(Entity entity, double x, double y, double z, float yaw, float partialRenderTick) {
        if (model == null) {
            model = new WavefrontObject(modelLocation);
        }
        this.bindEntityTexture(entity);
        GL11.glPushMatrix();
        GL11.glPushAttrib((int)1048575);
        GL11.glShadeModel((int)7425);
        GL11.glDisable((int)2896);
        GL11.glEnable((int)3042);
        Random random = new Random();
        List colors = Arrays.asList((Object[])((Object[])new Integer[]{16711680, 65280, 255, 16776960, 16711935, 65535}));
        int color = (Integer)colors.get(random.nextInt(colors.size()));
        int lifetime = 20;
        if (entity instanceof EntitySlashDimension) {
            color = ((EntitySlashDimension)entity).getColor();
            lifetime = ((EntitySlashDimension)entity).getLifeTime();
        }
        boolean inverse = color < 0;
        double deathTime = lifetime;
        double baseAlpha = Math.sin((double)(1.5707963267948966 * (Math.min((double)deathTime, (double)((float)(lifetime - entity.ticksExisted) - partialRenderTick)) / deathTime)));
        int seed = entity.getEntityData().getInteger("seed");
        Color col = new Color(color);
        float[] hsb = Color.RGBtoHSB((int)col.getRed(), (int)col.getGreen(), (int)col.getBlue(), (float[])null);
        int baseColor = Color.getHSBColor((float)(0.5f + hsb[0]), (float)hsb[1], (float)0.2f).getRGB() & 16777215;
        GL11.glTranslatef((float)((float)x), (float)((float)y), (float)((float)z));
        float rotParTicks = 200.0f;
        float rot = (float)entity.ticksExisted % rotParTicks / rotParTicks * 360.0f + partialRenderTick * (360.0f / rotParTicks);
        float scale = 0.1f;
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        float lastx = OpenGlHelper.lastBrightnessX;
        float lasty = OpenGlHelper.lastBrightnessY;
        OpenGlHelper.setLightmapTextureCoords((int)OpenGlHelper.lightmapTexUnit, (float)240.0f, (float)240.0f);
        Face.setColor((int)(baseColor |= (int)(102.0 * baseAlpha) << 24));
        OpenGlHelper.glBlendFunc((int)770, (int)1, (int)1, (int)0);
        GlStateManager.glBlendEquation((int)32779);
        GL11.glPushMatrix();
        for (int i = 0; i < 5; ++i) {
            GL11.glScaled((double)0.95, (double)0.95, (double)0.95);
            model.renderPart("base");
        }
        GL11.glPopMatrix();
        int loop = 3;
        for (int i = 0; i < loop; ++i) {
            GL11.glPushMatrix();
            float ticks = 15.0f;
            float wave = ((float)entity.ticksExisted + ticks / (float)loop * (float)i + partialRenderTick) % ticks;
            double waveScale = 1.0 + 0.03 * (double)wave;
            GL11.glScaled((double)waveScale, (double)waveScale, (double)waveScale);
            Face.setColor((int)(baseColor & 16777215 | (int)(136.0f * ((ticks - wave) / ticks)) << 24));
            model.renderPart("base");
            GL11.glPopMatrix();
        }
        GlStateManager.glBlendEquation((int)32774);
        int windCount = 5;
        for (int i = 0; i < windCount; ++i) {
            GL11.glPushMatrix();
            GL11.glRotated((double)(360.0 / (double)windCount * (double)i), (double)1.0, (double)0.0, (double)0.0);
            GL11.glRotated((double)30.0, (double)0.0, (double)1.0, (double)0.0);
            double rotWind = 18.0;
            double offsetBase = 7.0;
            double offset = (double)i * offsetBase;
            double motionLen = offsetBase * (double)(windCount - 1);
            double ticks = (float)entity.ticksExisted + partialRenderTick + (float)seed;
            double offsetTicks = ticks + offset;
            double progress = offsetTicks % motionLen / motionLen;
            double rad = 6.283185307179586;
            Face.setColor((int)(color & 16777215 | (int)Math.min((double)0.0, (double)(255.0 * Math.sin((double)(rad *= progress)))) << 24));
            double windScale = 0.4 + progress;
            GL11.glScaled((double)windScale, (double)windScale, (double)windScale);
            GL11.glRotated((double)(rotWind * offsetTicks), (double)0.0, (double)0.0, (double)1.0);
            model.renderPart("wind");
            GL11.glPopMatrix();
        }
        Face.resetColor();
        OpenGlHelper.setLightmapTextureCoords((int)OpenGlHelper.lightmapTexUnit, (float)lastx, (float)lasty);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glShadeModel((int)7424);
        GL11.glPopAttrib();
        GL11.glPopMatrix();
    }

    protected ResourceLocationRaw getEntityTexture(Entity entity) {
        return textureLocation;
    }
}

