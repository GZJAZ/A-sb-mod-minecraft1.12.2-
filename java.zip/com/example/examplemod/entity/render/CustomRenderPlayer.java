package com.example.examplemod.entity.render;
import com.example.examplemod.model.GzjModelPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.player.EntityPlayer;

public class CustomRenderPlayer extends RenderPlayer {
    public CustomRenderPlayer(RenderManager p_i46102_1_) {
        super(p_i46102_1_);
    }
    public void doRender(EntityPlayer entityPlayer, double x, double y, double z, float entityYaw, float partialTicks) {
        GzjModelPlayer customModel = new GzjModelPlayer();
        customModel.setRotationAngles(entityPlayer, 0, 0, entityPlayer.ticksExisted, 0, 0.1f);
        customModel.render(entityPlayer, 0, 0, 0, 0, 0, 0.0625f);
        super.doRender((AbstractClientPlayer) entityPlayer, x, y, z, entityYaw, partialTicks);
    }
}
