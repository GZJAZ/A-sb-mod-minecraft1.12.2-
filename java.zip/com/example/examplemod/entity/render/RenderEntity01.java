/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  java.lang.String
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelPlayer
 *  net.minecraft.client.renderer.entity.RenderBiped
 *  net.minecraft.client.renderer.entity.RenderLivingBase
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.client.renderer.entity.layers.LayerRenderer
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.example.examplemod.entity.render;

import com.example.examplemod.model.GzjModelPlayer;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(value=Side.CLIENT)
public class RenderEntity01
        extends RenderLivingBase<EntityPlayer> {
    public RenderEntity01(RenderManager renderManagerIn) {
        super(renderManagerIn, (ModelBiped)new GzjModelPlayer(), 0.5f);

    }

    public GzjModelPlayer getModel() {
        return (GzjModelPlayer)this.mainModel;
    }

    protected ResourceLocation getEntityTexture(EntityPlayer entity) {
        ResourceLocation location = new ResourceLocation("gzjmod", "textures/entitycw.png");
        return location;
    }
}

