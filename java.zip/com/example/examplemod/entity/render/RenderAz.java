//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.example.examplemod.entity.render;

import mods.flammpfeil.slashblade.client.model.obj.Face;
import mods.flammpfeil.slashblade.client.model.obj.WavefrontObject;
import mods.flammpfeil.slashblade.entity.EntitySlashDimension;
import mods.flammpfeil.slashblade.util.ResourceLocationRaw;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Random;

public class RenderAz extends Render {
    public static WavefrontObject model = null;
    public static ResourceLocationRaw modelLocation = new ResourceLocationRaw("flammpfeil.slashblade", "model/slashdim.obj");
    public static ResourceLocationRaw textureLocation = new ResourceLocationRaw("flammpfeil.slashblade", "model/slashdim.png");

    public RenderAz(RenderManager renderManager) {
        super(renderManager);
    }

    private TextureManager engine() {
        return this.renderManager.renderEngine;
    }

    public void doRender(Entity entity, double x, double y, double z, float yaw, float partialRenderTick) {
        if (this.renderOutlines) {
            GlStateManager.disableLighting();
            GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
            GlStateManager.disableTexture2D();
            GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
            GlStateManager.enableColorMaterial();
            float cycleTicks = 40.0F;
            float b = Math.abs((float)entity.ticksExisted % cycleTicks / cycleTicks - 0.5F) + 0.5F;
            GlStateManager.enableOutlineMode(Color.getHSBColor(0.0F, 0.0F, b).getRGB());
        }

        this.renderModel(entity, x, y, z, yaw, partialRenderTick);
        if (this.renderOutlines) {
            GlStateManager.disableOutlineMode();
            GlStateManager.disableColorMaterial();
            GlStateManager.enableLighting();
            GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
            GlStateManager.enableTexture2D();
            GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
        }

    }

    public void renderModel(Entity entity, double x, double y, double z, float yaw, float partialRenderTick) {
        if (model == null) {
            model = new WavefrontObject(modelLocation);
        }
        GL11.glColor4f(new Random().nextLong(), new Random().nextLong(), new Random().nextLong(), new Random().nextLong());

        this.bindEntityTexture(entity);
        GL11.glPushMatrix();
        GL11.glPushAttrib(1048575);
        GL11.glShadeModel(7425);
        GL11.glDisable(2896);
        GL11.glEnable(3042);
        int color = 5592575;
        int lifetime = 20;
        if (entity instanceof EntitySlashDimension) {
            color = ((EntitySlashDimension)entity).getColor();
            lifetime = ((EntitySlashDimension)entity).getLifeTime();
        }

        boolean inverse = color < 0;
        double deathTime = (double)lifetime;
        double baseAlpha = Math.sin(1.5707963267948966 * (Math.min(deathTime, (double)((float)(lifetime - entity.ticksExisted) - partialRenderTick)) / deathTime));
        int seed = entity.getEntityData().getInteger("seed");
        Color col = new Color(color);
        float[] hsb = Color.RGBtoHSB(col.getRed(), col.getGreen(), col.getBlue(), (float[])null);
        int baseColor = Color.getHSBColor(0.5F + hsb[0], hsb[1], 0.2F).getRGB() & 16777215;
        baseColor |= (int)(102.0 * baseAlpha) << 24;
        GL11.glTranslatef((float)x, (float)y, (float)z);
        float rotParTicks = 40.0F;
        float rot = (float)entity.ticksExisted % rotParTicks / rotParTicks * 360.0F + partialRenderTick * (360.0F / rotParTicks);
        float scale = 0.01F;
        GL11.glScalef(scale, scale, scale);
        float lastx = OpenGlHelper.lastBrightnessX;
        float lasty = OpenGlHelper.lastBrightnessY;
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
        Face.setColor(baseColor);
        OpenGlHelper.glBlendFunc(770, 1, 1, 0);
        GlStateManager.glBlendEquation(32779);
        GL11.glPushMatrix();

        for(int i = 0; i < 5; ++i) {
            GL11.glScaled(0.95, 0.95, 0.95);
            model.renderPart("base");
        }

        GL11.glPopMatrix();
        int loop = 3;

        for(int i = 0; i < loop; ++i) {
            GL11.glPushMatrix();
            float ticks = 15.0F;
            float wave = ((float)entity.ticksExisted + ticks / (float)loop * (float)i + partialRenderTick) % ticks;
            double waveScale = 1.0 + 0.03 * (double)wave;
            GL11.glScaled(waveScale, waveScale, waveScale);
            Face.setColor(baseColor & 16777215 | (int)(136.0F * ((ticks - wave) / ticks)) << 24);
            model.renderPart("base");
            GL11.glPopMatrix();
        }

        GlStateManager.glBlendEquation(32774);
        int windCount = 5;

        for(int i = 0; i < windCount; ++i) {
            GL11.glPushMatrix();
            GL11.glRotated(360.0 / (double)windCount * (double)i, 1.0, 0.0, 0.0);
            GL11.glRotated(30.0, 0.0, 1.0, 0.0);
            double rotWind = 18.0;
            double offsetBase = 7.0;
            double offset = (double)i * offsetBase;
            double motionLen = offsetBase * (double)(windCount - 1);
            double ticks = (double)((float)entity.ticksExisted + partialRenderTick + (float)seed);
            double offsetTicks = ticks + offset;
            double progress = offsetTicks % motionLen / motionLen;
            double rad = 6.283185307179586;
            rad *= progress;
            Face.setColor(color & 16777215 | (int)Math.min(0.0, 255.0 * Math.sin(rad)) << 24);
            double windScale = 0.4 + progress;
            GL11.glScaled(windScale, windScale, windScale);
            GL11.glRotated(rotWind * offsetTicks, 0.0, 0.0, 1.0);
            model.renderPart("wind");
            GL11.glPopMatrix();
        }

        Face.resetColor();
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lastx, lasty);
        GL11.glDisable(3042);
        GL11.glEnable(2896);
        GL11.glShadeModel(7424);
        GL11.glPopAttrib();
        GL11.glPopMatrix();
    }

    protected ResourceLocationRaw getEntityTexture(Entity p_110775_1_) {
        return textureLocation;
    }
}
