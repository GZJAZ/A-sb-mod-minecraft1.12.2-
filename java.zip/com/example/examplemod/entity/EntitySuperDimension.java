/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  java.util.Random
 *  mods.flammpfeil.slashblade.ability.ArmorPiercing
 *  mods.flammpfeil.slashblade.ability.StylishRankManager
 *  mods.flammpfeil.slashblade.ability.StylishRankManager$AttackTypes
 *  mods.flammpfeil.slashblade.ability.TeleportCanceller
 *  mods.flammpfeil.slashblade.entity.selector.EntitySelectorAttackable
 *  mods.flammpfeil.slashblade.entity.selector.EntitySelectorDestructable
 *  mods.flammpfeil.slashblade.item.ItemSlashBlade
 *  mods.flammpfeil.slashblade.util.ReflectionAccessHelper
 *  net.minecraft.block.material.Material
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.MoverType
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.entity.projectile.EntityFireball
 *  net.minecraft.entity.projectile.EntityThrowable
 *  net.minecraft.init.Enchantments
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.Item
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EntityDamageSource
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.common.registry.IThrowableEntity
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.example.examplemod.entity;

import com.google.common.base.Predicate;
import mods.flammpfeil.slashblade.ability.ArmorPiercing;
import mods.flammpfeil.slashblade.ability.StylishRankManager;
import mods.flammpfeil.slashblade.ability.TeleportCanceller;
import mods.flammpfeil.slashblade.entity.selector.EntitySelectorAttackable;
import mods.flammpfeil.slashblade.entity.selector.EntitySelectorDestructable;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import mods.flammpfeil.slashblade.util.ReflectionAccessHelper;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Enchantments;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.IThrowableEntity;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EntitySuperDimension
        extends Entity
        implements IThrowableEntity {
    protected Entity thrower;
    protected ItemStack blade = ItemStack.EMPTY;
    protected List<Entity> alreadyHitEntity = new ArrayList();
    protected float AttackLevel = 0.0f;
    private static final DataParameter<Integer> LIFETIME = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Boolean> SINGLE_HIT = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> IS_SLASH_DIMENSION = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> THROWER_ENTITY_ID = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> INTERVAL = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> COLOR = EntityDataManager.createKey(EntitySuperDimension.class, (DataSerializer)DataSerializers.VARINT);

    public EntitySuperDimension(World par1World) {
        super(par1World);
        this.ticksExisted = 0;
        this.getEntityData().setInteger("seed", this.rand.nextInt(50));
    }

    public EntitySuperDimension(World par1World, EntityLivingBase entityLiving, float AttackLevel, boolean multiHit) {
        this(par1World, entityLiving, AttackLevel);
        this.setIsSingleHit(multiHit);
    }

    public EntitySuperDimension(World par1World, EntityLivingBase entityLiving, float AttackLevel) {
        this(par1World);
        this.AttackLevel = AttackLevel;
        this.thrower = entityLiving;
        this.blade = entityLiving.getHeldItemMainhand();
        if (!this.blade.isEmpty() && !(this.blade.getItem() instanceof ItemSlashBlade)) {
            this.blade = ItemStack.EMPTY;
        }
        this.alreadyHitEntity.clear();
        this.alreadyHitEntity.add((Entity) this.thrower);
        this.alreadyHitEntity.add((Entity) this.thrower.getRidingEntity());
        this.alreadyHitEntity.addAll(this.thrower.getPassengers());
        this.ticksExisted = 0;
        this.setSize(4.0f, 4.0f);
    }

    @Override
    protected void entityInit() {
        this.getDataManager().register(LIFETIME, (Integer) 20);
        this.getDataManager().register(SINGLE_HIT, (Boolean) false);
        this.getDataManager().register(IS_SLASH_DIMENSION, (Boolean) false);
        this.getDataManager().register(THROWER_ENTITY_ID, (Integer)0);
        this.getDataManager().register(INTERVAL, (Integer)7);
        this.getDataManager().register(COLOR, (Integer)3355647);
    }

    public boolean getIsSingleHit() {
        return (Boolean)this.getDataManager().get(SINGLE_HIT);
    }

    public void setIsSingleHit(boolean isSingleHit) {
        this.getDataManager().set(SINGLE_HIT, (Boolean) isSingleHit);
    }

    public int getLifeTime() {
        return (Integer)this.getDataManager().get(LIFETIME);
    }

    public void setLifeTime(int lifetime) {
        this.getDataManager().set(LIFETIME, (Integer)lifetime);
    }

    public boolean getIsSlashDimension() {
        return (Boolean)this.getDataManager().get(IS_SLASH_DIMENSION);
    }

    public void setIsSlashDimension(boolean isSlashDimension) {
        this.getDataManager().set(IS_SLASH_DIMENSION, (Boolean) isSlashDimension);
    }

    public int getInterval() {
        return (Integer)this.getDataManager().get(INTERVAL);
    }

    public void setInterval(int value) {
        this.getDataManager().set(INTERVAL, (Integer)value);
    }

    public int getColor() {
        return (Integer)this.getDataManager().get(COLOR);
    }

    public void setColor(int value) {
        this.getDataManager().set(COLOR, (Integer)value);
    }

    public int getThrowerEntityId() {
        return (Integer)this.getDataManager().get(THROWER_ENTITY_ID);
    }

    public void setThrowerEntityId(int entityid) {
        this.getDataManager().set(THROWER_ENTITY_ID, (Integer)entityid);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        this.lastTickPosX = this.posX;
        this.lastTickPosY = this.posY;
        this.lastTickPosZ = this.posZ;
        if (!this.world.isRemote) {
            if (this.ticksExisted < 8 && this.ticksExisted % 2 == 0) {
                this.playSound(SoundEvents.ENTITY_WITHER_HURT, 0.2f, 0.5f + 0.25f * this.rand.nextFloat());
            }
            if (this.getThrower() != null) {
                AxisAlignedBB bb = this.getEntityBoundingBox();
                if (this.getThrower() instanceof EntityLivingBase) {
                    EntityLivingBase entityLiving = (EntityLivingBase)this.getThrower();
                    List<Entity> list = this.world.getEntitiesInAABBexcluding(this.getThrower(), bb, (Predicate<? super Entity>)EntitySelectorDestructable.getInstance());
                    StylishRankManager.setNextAttackType((Entity)this.thrower, (String)StylishRankManager.AttackTypes.DestructObject);
                    list.removeAll(this.alreadyHitEntity);
                    this.alreadyHitEntity.addAll(list);
                    for (Entity curEntity : list) {
                        if (this.blade.isEmpty()) break;
                        boolean isDestruction = true;
                        if (curEntity instanceof EntityFireball) {
                            isDestruction = ((EntityFireball)curEntity).shootingEntity != null && ((EntityFireball)curEntity).shootingEntity.getEntityId() == entityLiving.getEntityId() ? false : !curEntity.attackEntityFrom(DamageSource.causeMobDamage((EntityLivingBase)entityLiving), this.AttackLevel);
                        } else if (curEntity instanceof EntityArrow) {
                            if (((EntityArrow)curEntity).shootingEntity != null && ((EntityArrow)curEntity).shootingEntity.getEntityId() == entityLiving.getEntityId()) {
                                isDestruction = false;
                            }
                        } else if (curEntity instanceof IThrowableEntity) {
                            if (((IThrowableEntity)curEntity).getThrower() != null && ((IThrowableEntity)curEntity).getThrower().getEntityId() == entityLiving.getEntityId()) {
                                isDestruction = false;
                            }
                        } else if (curEntity instanceof EntityThrowable && ((EntityThrowable)curEntity).getThrower() != null && ((EntityThrowable)curEntity).getThrower().getEntityId() == entityLiving.getEntityId()) {
                            isDestruction = false;
                        }
                        if (!isDestruction) continue;
                        ReflectionAccessHelper.setVelocity((Entity)curEntity, (double)0.0, (double)0.0, (double)0.0);
                        curEntity.setDead();
                        for (int var1 = 0; var1 < 10; ++var1) {
                            Random rand = this.getRand();
                            double var2 = rand.nextGaussian() * 0.02;
                            double var4 = rand.nextGaussian() * 0.02;
                            double var6 = rand.nextGaussian() * 0.02;
                            double var8 = 10.0;
                            this.world.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, curEntity.posX + (double)(rand.nextFloat() * curEntity.width * 2.0f) - (double)curEntity.width - var2 * var8, curEntity.posY + (double)(rand.nextFloat() * curEntity.height) - var4 * var8, curEntity.posZ + (double)(rand.nextFloat() * curEntity.width * 2.0f) - (double)curEntity.width - var6 * var8, var2, var4, var6, new int[0]);
                        }
                        StylishRankManager.doAttack((Entity)this.thrower);
                    }
                }
                if (this.getIsSingleHit() || this.ticksExisted % 2 == 0) {
                    List<Entity> list = this.world.getEntitiesInAABBexcluding(this.getThrower(), bb, (Predicate<? super Entity>)EntitySelectorAttackable.getInstance());
                    list.removeAll(this.alreadyHitEntity);
                    if (this.getIsSingleHit()) {
                        this.alreadyHitEntity.addAll(list);
                    }
                    float magicDamage = Math.max((float)1.0f, (float)this.AttackLevel);
                    StylishRankManager.setNextAttackType((Entity)this.thrower, (String)StylishRankManager.AttackTypes.SlashDimMagic);
                    for (Entity curEntity : list) {
                        if (this.blade.isEmpty()) break;
                        if (this.getIsSlashDimension()) {
                            ArmorPiercing.doAPAttack((Entity)curEntity, (float)magicDamage);
                        }
                        Vec3d pos = curEntity.getPositionVector();
                        TeleportCanceller.setCancel((Entity)curEntity);
                        curEntity.hurtResistantTime = 0;
                        DamageSource ds = new EntityDamageSource("directMagic", this.getThrower()).setDamageBypassesArmor().setMagicDamage().setProjectile();
                        if (!this.blade.isEmpty() && curEntity instanceof EntityLivingBase) {
                            ((ItemSlashBlade)this.blade.getItem()).hitEntity(this.blade, (EntityLivingBase)curEntity, (EntityLivingBase)this.thrower);
                        }
                        if (!curEntity.getPositionVector().equals((Object)pos)) {
                            curEntity.setPositionAndUpdate(pos.x, pos.y, pos.z);
                        }
                        curEntity.motionX = 0.0;
                        curEntity.motionY = 0.0;
                        curEntity.motionZ = 0.0;
                        if (3 >= this.ticksExisted || this.blade.isEmpty() || !(curEntity instanceof EntityLivingBase)) continue;
                        if (this.getIsSlashDimension()) {
                            curEntity.addVelocity(0.0, 0.5, 0.0);
                            continue;
                        }
                        int level = EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.PUNCH, (ItemStack)this.blade);
                        if (0 < level) {
                            curEntity.addVelocity(Math.sin((double)(this.getThrower().rotationYaw * 3.1415927f / 180.0f)) * (double)level * 0.5, 0.2, -Math.cos((double)(this.getThrower().rotationYaw * 3.1415927f / 180.0f)) * (double)level * 0.5);
                            continue;
                        }
                        curEntity.addVelocity(-Math.sin((double)(this.getThrower().rotationYaw * 3.1415927f / 180.0f)) * 0.5, 0.2, Math.cos((double)(this.getThrower().rotationYaw * 3.1415927f / 180.0f)) * 0.5);
                    }
                }
            }
        }
        if (this.ticksExisted >= this.getLifeTime()) {
            this.alreadyHitEntity.clear();
            this.alreadyHitEntity = null;
            this.setDead();
        }
    }

    public Random getRand() {
        return this.rand;
    }

    @Override
    public boolean isOffsetPositionInLiquid(double par1, double par3, double par5) {
        return false;
    }

    @Override
    public void move(MoverType moverType, double par1, double par3, double par5) {
    }

    @Override
    protected void dealFireDamage(int par1) {
    }

    @Override
    public boolean handleWaterMovement() {
        return false;
    }

    @Override
    public boolean isInsideOfMaterial(Material par1Material) {
        return false;
    }

    @Override
    public boolean isInLava() {
        return false;
    }

    @SideOnly(value=Side.CLIENT)
    @Override
    public int getBrightnessForRender() {
        float f1 = 0.5f;
        if (f1 < 0.0f) {
            f1 = 0.0f;
        }
        if (f1 > 1.0f) {
            f1 = 1.0f;
        }
        int i = super.getBrightnessForRender();
        int j = i & 255;
        int k = i >> 16 & 255;
        if ((j += (int)(f1 * 15.0f * 16.0f)) > 240) {
            j = 240;
        }
        return j | k << 16;
    }

    @Override
    public float getBrightness() {
        float f1 = super.getBrightness();
        float f2 = 0.9f;
        f2 = f2 * f2 * f2 * f2;
        return f1 * (1.0f - f2) + f2;
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {
    }

    @SideOnly(value=Side.CLIENT)
    public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9) {
    }

    @Override
    public void setPortal(BlockPos pos) {
    }

    @Override
    public boolean isBurning() {
        return false;
    }

    @Override
    public boolean shouldRenderInPass(int pass) {
        return pass == 1;
    }

    @Override
    public void setInWeb() {
    }

    public Entity getThrower() {
        int id;
        if (this.thrower == null && (id = this.getThrowerEntityId()) != 0) {
            this.thrower = this.getEntityWorld().getEntityByID(id);
        }
        return this.thrower;
    }

    public void setThrower(Entity entity) {
        if (entity != null) {
            this.setThrowerEntityId(entity.getEntityId());
        }
        this.thrower = entity;
    }
}

