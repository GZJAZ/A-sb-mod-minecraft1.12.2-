package com.example.examplemod.entity;

import com.google.common.collect.Maps;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.FakePlayer;

import java.util.Map;

public final class GzjFakePlayer extends FakePlayer {
    // Map of all active fake player usernames to their entities
    private static Map<GameProfile, GzjFakePlayer> fakePlayers = Maps.newHashMap();

    public GzjFakePlayer(WorldServer world, GameProfile name) {
        super(world, name);
    }

    @Override
    public void closeScreen() {

    }

    public static GzjFakePlayer getFakePlayer(EntityPlayerMP player) {
        GameProfile profile = player.getGameProfile();
        if (fakePlayers.containsKey(profile)) {
            return fakePlayers.get(profile);
        }

        GzjFakePlayer fakePlayer = new GzjFakePlayer(player.getServerWorld(), profile);
        fakePlayers.put(profile, fakePlayer);
        return fakePlayer;
    }
}
