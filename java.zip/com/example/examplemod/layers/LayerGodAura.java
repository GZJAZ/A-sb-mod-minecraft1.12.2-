/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Random
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelPlayer
 *  net.minecraft.client.renderer.EntityRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.client.renderer.entity.RenderPlayer
 *  net.minecraft.client.renderer.entity.layers.LayerRenderer
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.MathHelper
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.example.examplemod.layers;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.Random;

@SideOnly(value=Side.CLIENT)
public class LayerGodAura
implements LayerRenderer<EntityPlayer> {
    private static final ResourceLocation WITHER_ARMOR = new ResourceLocation("textures/misc/enchanted_item_glint.png");
    private final RenderPlayer renderPlayer;
    private final ModelPlayer modelPlayer = new ModelPlayer(0.0f, false);

    public LayerGodAura(RenderPlayer renderPlayer) {
        this.renderPlayer = renderPlayer;
    }


    public void doRenderLayer(EntityPlayer entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            if (entitylivingbaseIn.isEntityAlive()) {
                Random random = new Random();
                GlStateManager.depthMask((boolean) (!entitylivingbaseIn.isInvisible()));
                this.renderPlayer.bindTexture(WITHER_ARMOR);
                GlStateManager.matrixMode((int) 5890);
                GlStateManager.loadIdentity();
                float f = (float) entitylivingbaseIn.ticksExisted + partialTicks;
                float f1 = MathHelper.cos((float) (f * 0.02f)) * 3.0f;
                float f2 = f * 0.01f;
                GlStateManager.translate((float) f1, (float) f2, (float) 0.0f);
                GlStateManager.matrixMode((int) 5888);
                GlStateManager.enableBlend();
                float f3 = 0.5f;
                GlStateManager.color((float) random.nextFloat(), (float) random.nextFloat(), (float) random.nextFloat(), (float) 1.0f);
                GlStateManager.disableLighting();
                GlStateManager.blendFunc((GlStateManager.SourceFactor) GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor) GlStateManager.DestFactor.ONE);
                this.modelPlayer.setLivingAnimations((EntityLivingBase) entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks);
                this.modelPlayer.setModelAttributes((ModelBase) this.renderPlayer.getMainModel());
                Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
                this.modelPlayer.render((Entity) entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
                Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
                GlStateManager.matrixMode((int) 5890);
                GlStateManager.loadIdentity();
                GlStateManager.matrixMode((int) 5888);
                GlStateManager.enableLighting();
                GlStateManager.disableBlend();
            }
        }

    public boolean shouldCombineTextures() {
        return false;
    }
}

