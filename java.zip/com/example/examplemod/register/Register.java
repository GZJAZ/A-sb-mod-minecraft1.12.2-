/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemSword
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.event.RegistryEvent
 *  net.minecraftforge.event.RegistryEvent$Register
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.network.NetworkRegistry
 *  net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package com.example.examplemod.register;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber
public final class Register {
    public static final List<Item> ITEMS = new ArrayList();
    public static SimpleNetworkWrapper instance = NetworkRegistry.INSTANCE.newSimpleChannel("timestop");


    @SubscribeEvent
    public static void onItemRegistry(RegistryEvent.Register<Item> event) {
    }
}

