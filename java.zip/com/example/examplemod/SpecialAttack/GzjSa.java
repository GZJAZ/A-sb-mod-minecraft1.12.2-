/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.String
 *  mods.flammpfeil.slashblade.TagPropertyAccessor$TagPropertyIntegerWithRange
 *  mods.flammpfeil.slashblade.ability.StylishRankManager
 *  mods.flammpfeil.slashblade.item.ItemSlashBlade
 *  mods.flammpfeil.slashblade.specialattack.SpecialAttackBase
 *  net.minecraft.nbt.NBTTagCompound
 */
package com.example.examplemod.SpecialAttack;

import com.example.examplemod.entity.EntitySuperDimension;
import mods.flammpfeil.slashblade.ability.StylishRankManager;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import mods.flammpfeil.slashblade.specialattack.SpecialAttackBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class GzjSa
        extends SpecialAttackBase {
    public static final GzjSa theSa = new GzjSa();

    public String toString() {
        return "GzjSa";
    }

    public void doSpacialAttack(ItemStack stack, EntityPlayer player) {
        World world = player.world;
        NBTTagCompound tag = ItemSlashBlade.getItemTagCompound((ItemStack)stack);
        int cost = -10;
        if (!ItemSlashBlade.ProudSoul.tryAdd(tag, Integer.valueOf((int)-10), false)) {
            ItemSlashBlade.damageItem((ItemStack)stack, (int)10000, (EntityLivingBase)player);
        }
        int count = 8 + StylishRankManager.getStylishRank((Entity)player);
        EntitySuperDimension superDimension = new EntitySuperDimension(world, player, count);
        superDimension.setPosition(player.posX, player.posY + 1.0, player.posZ);
        superDimension.setLifeTime(200);
        world.spawnEntity(superDimension);
    }
}

