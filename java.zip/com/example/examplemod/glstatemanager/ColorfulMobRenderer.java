/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.awt.Color
 *  java.util.Random
 *  java.util.UUID
 *  javax.annotation.Nullable
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.ResourceLocation
 */
package com.example.examplemod.glstatemanager;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;

import javax.annotation.Nullable;
import java.awt.*;
import java.util.Random;

public class ColorfulMobRenderer
extends RenderLiving<EntityLiving> {
    private EntityLiving entity;

    public ColorfulMobRenderer(RenderManager renderManager, ModelBase modelBase, float shadowSize) {
        super(renderManager, modelBase, shadowSize);
    }

    public void doRender(EntityLiving entity, double x, double y, double z, float entityYaw, float partialTicks) {
        this.entity = entity;
        GlStateManager.enableColorMaterial();
        GlStateManager.enableOutlineMode((int)ColorfulMobRenderer.getColor((EntityLivingBase)entity));
        GlStateManager.pushMatrix();
        GlStateManager.translate((double)x, (double)y, (double)z);
        super.doRender(entity, 0.0, 0.0, 0.0, entityYaw, partialTicks);
        GlStateManager.popMatrix();
        GlStateManager.disableOutlineMode();
        GlStateManager.disableColorMaterial();
    }

    public void setRenderOutlines(boolean renderOutlinesIn) {
        super.setRenderOutlines(renderOutlinesIn);
        if (renderOutlinesIn) {
            GlStateManager.enableColorMaterial();
            GlStateManager.enableOutlineMode((int)ColorfulMobRenderer.getColor((EntityLivingBase)this.entity));
        } else {
            GlStateManager.disableOutlineMode();
            GlStateManager.disableColorMaterial();
        }
    }

    public static int getColor(EntityLivingBase entity) {
        Random random = new Random((long)entity.getUniqueID().hashCode());
        return Color.getHSBColor((float)random.nextFloat(), (float)1.0f, (float)1.0f).getRGB();
    }

    @Nullable
    protected ResourceLocation getEntityTexture(EntityLiving entityLiving) {
        return null;
    }
}

