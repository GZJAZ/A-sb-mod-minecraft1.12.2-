package com.example.examplemod.event;

import com.example.examplemod.Item.ItemGzjBlade;
import com.example.examplemod.core.EventUtil;
import com.example.examplemod.layers.LayerGodAura;
import com.example.examplemod.util.GetDeathEntity;
import com.example.examplemod.util.GodList;
import com.example.examplemod.util.GuiUtils;
import com.example.examplemod.util.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.FoodStats;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.EntityMobGriefingEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GzjEvent {
    static boolean c = true;
    static boolean c2 = false;
    static boolean c3 = false;

    @SubscribeEvent
    public static void onOnlyLoveItemToolTip(ItemTooltipEvent event) {
        if (event.getItemStack().getItem() instanceof ItemGzjBlade) {
            List tooltip = event.getToolTip();
            int size = tooltip.size();
            String attackDamage = "\u653b\u51fb\u4f24\u5bb3";
            String attackSpeed = "\u653b\u51fb\u901f\u5ea6";
            for (int i = 0; i < size; ++i) {
                String line = (String)tooltip.get(i);
                if (line.contains((CharSequence)attackDamage)) {
                    Object replacementAttackDamage = null;
                    tooltip.set(i, (Object)replacementAttackDamage);
                    continue;
                }
                if (!line.contains((CharSequence)attackSpeed)) continue;
                Object replacementAttackSpeed = null;
                tooltip.set(i, (Object)replacementAttackSpeed);
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveLivingAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            if (GodList.isGzjPlayer((EntityPlayer) event.getEntity())) {
                event.setCanceled(true);
            }

        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            if (GodList.isGzjPlayer((EntityPlayer)event.getEntity())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveLivingHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            if (GodList.isGzjPlayer((EntityPlayer)event.getEntity())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveLivingDamage(LivingDamageEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            if (GodList.isGzjPlayer((EntityPlayer)event.getEntity())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveGuiOpenEvent(GuiOpenEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        GuiScreen gui = event.getGui();
        if (GodList.isGzjPlayer((EntityPlayer)mc.player)) {
            for (int i = 0; i <= 10; ++i) {
                try {
                    if (gui != null) {
                        if (!Helper.isAllowGui(gui)) {
                            gui.mc.clear();
                            gui.height = 0;
                            gui.width = 0;
                            gui.setFocused(false);
                            event.setGui(null);
                            event.setCanceled(true);
                            mc.currentScreen = Helper.lastScreen;
                            if (Helper.lastScreen == null) {
                                mc.mouseHelper.grabMouseCursor();
                            }
                            mc.setIngameFocus();
                            continue;
                        }
                        Helper.lastScreen = gui;
                        continue;
                    }
                    Helper.lastScreen = null;
                    continue;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveDrawScreen(GuiScreenEvent.DrawScreenEvent.Pre event) {
        Minecraft mc = Minecraft.getMinecraft();
        GuiScreen gui = event.getGui();
        if (GodList.isGzjPlayer((EntityPlayer)mc.player)) {
            for (int i = 0; i <= 10; ++i) {
                try {
                    if (gui != null) {
                        if (!Helper.isAllowGui(gui)) {
                            gui.mc.clear();
                            gui.height = 0;
                            gui.width = 0;
                            gui.setFocused(false);
                            event.setCanceled(true);
                            mc.currentScreen = Helper.lastScreen;
                            if (Helper.lastScreen == null) {
                                mc.mouseHelper.grabMouseCursor();
                            }
                            mc.setIngameFocus();
                            continue;
                        }
                        Helper.lastScreen = gui;
                        continue;
                    }
                    Helper.lastScreen = null;
                    continue;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveOverlayRender(RenderGameOverlayEvent.Pre event) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity entity = mc.getRenderViewEntity();
        if (GodList.isGodPlayer(entity) && entity instanceof EntityPlayer) {
            Helper.safePlayer((EntityPlayer)entity);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveCanUpdataEntity(EntityEvent.CanUpdate event) {
        if (event.getEntity() instanceof EntityPlayer && GodList.isGzjPlayer((EntityPlayer)event.getEntity())) {
            event.setCanUpdate(true);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveItemToss(ItemTossEvent event) {
        ItemStack itemstack = event.getEntityItem().getItem();
        if (GodList.isGzjPlayer(event.getPlayer()) && itemstack.getItem() == ItemGzjBlade.item) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveEntityMobGriefing(EntityMobGriefingEvent event) {
        Entity entity = event.getEntity();
        if (entity != null) {
            double x = entity.posX;
            double y = entity.posY;
            double z = entity.posZ;
            List<EntityPlayer> entities = entity.world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(x - 5.0, y - 5.0, z - 5.0, x + 5.0, y + 5.0, z + 5.0));
            for (EntityPlayer entity1 : entities) {
                if (!GodList.isGzjPlayer(entity1)) continue;
                event.setResult(Event.Result.DENY);
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLovePlayerTick(TickEvent.PlayerTickEvent event) {
        File file;
        if (GodList.isGzjPlayer(event.player)) {
            if (!event.player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item))) {
                ItemStack stack = new ItemStack((Item)ItemGzjBlade.item);
                stack.setCount(1);
                event.player.setHeldItem(EnumHand.MAIN_HAND, stack);
            }
            if (!event.player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item))) {
                ItemStack stack = new ItemStack((Item)ItemGzjBlade.item);
                stack.setCount(1);
                event.player.setHeldItem(EnumHand.MAIN_HAND, stack);
            }
            Helper.safePlayer(event.player);
            Helper.defense(event.player);
        }
        if (GodList.isGzjPlayer(event.player) && (file = new File("OnlyLoveSword")).exists() && file.isDirectory()) {
            String[] ff;
            for (String name : ff = file.list()) {
                int j;
                if (!name.contains((CharSequence)"\u7121\u9650\u306e\u552f\u611b") || event.player == null) continue;
                EntityPlayer player = event.player;
                if (!player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item))) {
                    ItemStack _setstack = new ItemStack((Item)ItemGzjBlade.item);
                    _setstack.setCount(1);
                    player.setHeldItem(EnumHand.MAIN_HAND, _setstack);
                }
                player.setHealth(20.0f);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.capabilities.disableDamage = true;
                player.capabilities.allowFlying = true;
                player.capabilities.allowEdit = true;
                player.setInvisible(false);
                player.isDead = false;
                player.extinguish();
                player.deathTime = 0;
                player.hurtTime = 0;
                player.maxHurtTime = 0;
                player.getFoodStats().addStats(20, 20.0f);
                if (!player.world.playerEntities.contains((Object)player)) {
                    int i = player.chunkCoordX;
                    j = player.chunkCoordZ;
                    player.world.playerEntities.add((EntityPlayer) player);
                    player.world.getChunkFromChunkCoords(i, j).addEntity((Entity)player);
                    player.world.loadedEntityList.add((Entity) player);
                    player.world.onEntityAdded((Entity)player);
                }
                if (!player.world.loadedEntityList.contains((Object)player)) {
                    int i = player.chunkCoordX;
                    j = player.chunkCoordZ;
                    player.world.playerEntities.add((EntityPlayer) player);
                    player.world.getChunkFromChunkCoords(i, j).addEntity((Entity)player);
                    player.world.loadedEntityList.add((Entity) player);
                    player.world.onEntityAdded((Entity)player);
                }
                if (!player.world.loadedEntityList.contains((Object)player)) {
                    int i = player.chunkCoordX;
                    j = player.chunkCoordZ;
                    player.world.playerEntities.add((EntityPlayer) player);
                    player.world.getChunkFromChunkCoords(i, j).addEntity((Entity)player);
                    player.world.loadedEntityList.add((Entity) player);
                    player.world.onEntityAdded((Entity)player);
                }
                WorldInfo info = event.player.world.getWorldInfo();
                PlayerCapabilities cap = player.capabilities;
                FoodStats food = player.getFoodStats();
                if (info.isHardcoreModeEnabled()) {
                    info.setHardcore(false);
                }
                info.setCleanWeatherTime(600);
                info.setRainTime(0);
                info.setThunderTime(0);
                info.setRaining(false);
                info.setThundering(false);
                if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
                    player.setGameType(GameType.SURVIVAL);
                }
                if (player.getArrowCountInEntity() > 0) {
                    player.setArrowCountInEntity(0);
                }
                player.xpCooldown = 0;
                cap.allowEdit = true;
                LivingEvent.LivingUpdateEvent livingUpdateEvent = new LivingEvent.LivingUpdateEvent((EntityLivingBase)player);
                if (livingUpdateEvent.isCanceled()) {
                    livingUpdateEvent.setCanceled(false);
                }
                player.setAir(0);
                food.setFoodLevel(20);
                food.setFoodSaturationLevel(20.0f);
                cap.allowFlying = true;
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.setEntityInvulnerable(true);
                cap.disableDamage = true;
                player.isDead = false;
                player.deathTime = -2;
                if (Minecraft.getMinecraft().currentScreen == null || Helper.isAllowGui(Minecraft.getMinecraft().currentScreen)) continue;
                EventUtil.setScreenInvisible(Minecraft.getMinecraft().currentScreen);
            }
        }
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void onOnlyLoveLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (event.getEntity() instanceof EntityPlayer && GodList.isGzjPlayer((EntityPlayer)event.getEntity())) {
            Helper.safePlayer((EntityPlayer)event.getEntity());
            event.setCanceled(false);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderTooltip(RenderTooltipEvent.Pre event) {
        if (event.getStack().getItem() == ItemGzjBlade.item) {
            event.setCanceled(true);
            ArrayList list = new ArrayList();
            list.add((Object)String.valueOf((Object)new ItemStack((Item)ItemGzjBlade.item)));
            ItemGzjBlade.item.addInformation(null, null, (List<String>)list, null);
            GuiUtils.drawHoveringText(new ItemStack((Item)ItemGzjBlade.item), (List<String>)event.getLines(), 0, 0, event.getScreenWidth(), event.getScreenWidth(), event.getMaxWidth(), event.getFontRenderer());
            event.setMaxWidth(Helper.RandomInt(50, 10, true));
            event.setScreenHeight(Helper.RandomInt(10, 5, true));
            event.setScreenWidth(Helper.RandomInt(23, 10, true));
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderLivingEvent(RenderLivingEvent<?> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            event.getRenderer().addLayer((LayerRenderer)new LayerGodAura((RenderPlayer)event.getRenderer()));
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderLivingPre(RenderLivingEvent.Pre<?> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            event.getRenderer().addLayer((LayerRenderer)new LayerGodAura((RenderPlayer)event.getRenderer()));
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderLivingPost(RenderLivingEvent.Post<?> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            event.getRenderer().addLayer((LayerRenderer)new LayerGodAura((RenderPlayer)event.getRenderer()));
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.HIGHEST)
    public static void onOnlyLoveItemTickEvent(GzjBladeTickEvent event) {
        if (event.getEntity() != null && GodList.isGzjPlayer(event.getEntity())) {
            boolean hasItem;
            EntityPlayer player = event.getEntity();
            ItemStack stack = event.getItemStack();
            if (stack.isEmpty()) {
                stack = Helper.getLoveSwordItemStack();
            }
            if (event.getItem() instanceof ItemGzjBlade) {
                return;
            }
            boolean bl = hasItem = !(event.getItem() instanceof ItemGzjBlade) || !player.inventory.hasItemStack(stack);
            if (hasItem) {
                for (int i = 0; i < 10; ++i) {
                    ItemStack itemStack;
                    boolean isHasGodLoveItem = false;
                    for (ItemStack itemStack2 : player.inventory.mainInventory) {
                        if (!(itemStack2.getItem() instanceof ItemGzjBlade) || itemStack2.isEmpty()) continue;
                        isHasGodLoveItem = true;
                    }
                    if (!isHasGodLoveItem && !player.inventory.addItemStackToInventory(itemStack = Helper.getLoveSwordItemStack())) {
                        player.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, itemStack);
                    }
                    if (player.inventory.hasItemStack(Helper.getLoveSwordItemStack())) continue;
                    player.setHeldItem(EnumHand.MAIN_HAND, Helper.getLoveSwordItemStack());
                    player.inventory.markDirty();
                }
            }
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveEntityJoin(EntityJoinWorldEvent event) {
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
        if (GetDeathEntity.isDeadEntity(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveClientTickEvent(TickEvent.ClientTickEvent event) {
        for (int i = 0; i < GodList.gods.size(); ++i) {
            int d;
            int c;
            Entity entity = (Entity)GodList.gods.get(i);
            EntityPlayer player = (EntityPlayer)entity;
            World world = player.world;
            if (!player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item))) {
                player.inventory.addItemStackToInventory(new ItemStack((Item)ItemGzjBlade.item));
            }
            player.setHealth(20.0f);
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
            player.clearActivePotions();
            player.getActivePotionEffects().clear();
            player.capabilities.disableDamage = true;
            player.capabilities.allowFlying = true;
            player.capabilities.allowEdit = true;
            player.setInvisible(false);
            player.isDead = false;
            player.extinguish();
            player.deathTime = 0;
            player.hurtTime = 0;
            player.maxHurtTime = 0;
            player.getFoodStats().addStats(20, 20.0f);
            if (player.posY < -45.0) {
                player.motionY += 10.0;
            }
            if (!player.world.playerEntities.contains((Object)player)) {
                d = player.chunkCoordX;
                c = player.chunkCoordZ;
                player.world.playerEntities.add((EntityPlayer) player);
                player.world.getChunkFromChunkCoords(d, c).addEntity((Entity)player);
                player.world.loadedEntityList.add((Entity) player);
                player.world.onEntityAdded((Entity)player);
            }
            if (!player.world.loadedEntityList.contains((Object)player)) {
                d = player.chunkCoordX;
                c = player.chunkCoordZ;
                player.world.playerEntities.add((EntityPlayer) player);
                player.world.getChunkFromChunkCoords(d, c).addEntity((Entity)player);
                player.world.loadedEntityList.add((Entity) player);
                player.world.onEntityAdded((Entity)player);
            }
            if (!player.world.loadedEntityList.contains((Object)player)) {
                d = player.chunkCoordX;
                c = player.chunkCoordZ;
                player.world.playerEntities.add((EntityPlayer) player);
                player.world.getChunkFromChunkCoords(d, c).addEntity((Entity)player);
                player.world.loadedEntityList.add((Entity) player);
                player.world.onEntityAdded((Entity)player);
            }
            WorldInfo info = world.getWorldInfo();
            PlayerCapabilities cap = player.capabilities;
            FoodStats food = player.getFoodStats();
            if (info.isHardcoreModeEnabled()) {
                info.setHardcore(false);
            }
            info.setCleanWeatherTime(600);
            info.setRainTime(0);
            info.setThunderTime(0);
            info.setRaining(false);
            info.setThundering(false);
            player.xpCooldown = 0;
            cap.allowEdit = true;
            LivingEvent.LivingUpdateEvent livingUpdateEvent = new LivingEvent.LivingUpdateEvent((EntityLivingBase)player);
            if (livingUpdateEvent.isCanceled()) {
                livingUpdateEvent.setCanceled(false);
            }
            player.setAir(0);
            food.setFoodLevel(20);
            food.setFoodSaturationLevel(20.0f);
            cap.allowFlying = true;
            player.clearActivePotions();
            player.getActivePotionEffects().clear();
            player.setEntityInvulnerable(true);
            cap.disableDamage = true;
            player.isDead = false;
            player.deathTime = -2;
        }
    }
}

