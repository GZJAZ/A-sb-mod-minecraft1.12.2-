/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package com.example.examplemod.event;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GzjBladeTickEvent
extends Event {
    private final EntityPlayer entity;
    private final ItemStack itemStack;

    public GzjBladeTickEvent(EntityPlayer player, ItemStack stack) {
        this.entity = player;
        this.itemStack = stack;
    }

    public ItemStack getItemStack() {
        return this.itemStack;
    }

    public EntityPlayer getEntity() {
        return this.entity;
    }

    public Item getItem() {
        return this.itemStack.getItem();
    }
}

