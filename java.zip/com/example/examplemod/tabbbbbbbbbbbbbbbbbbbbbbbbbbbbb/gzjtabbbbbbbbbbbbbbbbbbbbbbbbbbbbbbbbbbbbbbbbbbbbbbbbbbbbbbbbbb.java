package com.example.examplemod.tabbbbbbbbbbbbbbbbbbbbbbbbbbbbb;

import com.example.examplemod.Item.ItemGzjBlade;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class gzjtabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
        extends CreativeTabs {
    public static TextFormatting[] c = new TextFormatting[]{TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.RED, TextFormatting.WHITE, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY};

    public gzjtabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb() {
        super("godtab");
    }

    public ItemStack getTabIconItem() {
        return new ItemStack((Item) ItemGzjBlade.item);
    }

    @SideOnly(value=Side.CLIENT)
    public String getTranslatedTabLabel() {
        return gzjtabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.fm("\u5929\u771F\u7684\u9E3D\u5B50\u7CBE\u7269\u54C1\u680F", c, 50.0);
    }

    @SideOnly(value=Side.CLIENT)
    public String getBackgroundImageName() {
        return "max.png";
    }

    public static String fm(String input, TextFormatting[] colours, double delay) {
        String string = "";
        if (delay <= 0.0) {
            delay = 0.001;
        }
        int offset = (int)Math.floor((double)((double)(System.currentTimeMillis() & 16383L) / delay)) % colours.length;
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            string = string + colours[(colours.length + i - offset) % colours.length].toString();
            string = string + c;
        }
        return string;
    }
}

