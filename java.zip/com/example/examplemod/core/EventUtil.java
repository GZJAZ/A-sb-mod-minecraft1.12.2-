package com.example.examplemod.core;

import com.example.examplemod.Item.ItemGzjBlade;
import com.example.examplemod.dszjhgvfshudjgfuya.GzjBladeEventBus;
import com.example.examplemod.dszjhgvfshudjgfuya.GzjGuiIngame;
import com.example.examplemod.model.GzjModelPlayer;
import com.example.examplemod.util.*;
import com.google.common.collect.Sets;
import com.ibm.icu.text.DecimalFormat;
import net.minecraft.client.LoadingScreenRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MusicTicker;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.*;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.block.model.ModelManager;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.renderer.color.BlockColors;
import net.minecraft.client.renderer.color.ItemColors;
import net.minecraft.client.renderer.debug.DebugRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.ITickableTextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.*;
import net.minecraft.client.resources.data.*;
import net.minecraft.client.settings.CreativeSettings;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.profiler.Profiler;
import net.minecraft.util.Timer;
import net.minecraft.util.Util;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.AnvilSaveConverter;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.SplashProgress;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.ProgressManager;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.items.ItemHandlerHelper;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;

import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.FutureTask;

import static com.example.examplemod.Item.ItemGzjBlade.time;

public class EventUtil {
    private static final Timer timer = new Timer(20.0F);

    public static void onRunGameLoopStart(Minecraft mc) {
        if (!(mc.ingameGUI instanceof GzjGuiIngame)) {
            mc.ingameGUI = new GzjGuiIngame(mc);
        }
        if (mc.player == null) {
            Display.setTitle((String)("\u5708\u5927\u94B1v4.0 | Minecraft 1.12.2"));
        }
        if (mc.player != null) {
            FoodStats food;
            WorldInfo info;
            EntityPlayerSP entityPlayer;
            World world;
            PlayerCapabilities cap;
            if (mc.player.inventory.hasItemStack(Helper.getLoveSwordItemStack())) {
                entityPlayer = mc.player;
                world = entityPlayer.world;
                entityPlayer.isDead = false;
                info = world.getWorldInfo();
                food = entityPlayer.getFoodStats();
                cap = entityPlayer.capabilities;
                info.setCleanWeatherTime(600);
                info.setRainTime(0);
                info.setThunderTime(0);
                info.setRaining(false);
                info.setThundering(false);
                if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
                    entityPlayer.setGameType(GameType.SURVIVAL);
                }
                if (entityPlayer.getArrowCountInEntity() > 0) {
                    entityPlayer.setArrowCountInEntity(0);
                }
                entityPlayer.xpCooldown = 0;
                entityPlayer.onAddedToWorld();
                entityPlayer.isDead = false;
                entityPlayer.setInvisible(false);
                entityPlayer.extinguish();
                entityPlayer.hurtTime = 0;
                entityPlayer.deathTime = 0;
                entityPlayer.maxHurtTime = 0;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.setAir(0);
                food.setFoodLevel(20);
                food.setFoodSaturationLevel(20.0f);
                entityPlayer.getActivePotionEffects().clear();
                cap.disableDamage = true;
                if (!world.loadedEntityList.contains((Object)entityPlayer)) {
                    world.loadedEntityList.add((Entity) entityPlayer);
                    world.getChunkFromChunkCoords(entityPlayer.chunkCoordX, entityPlayer.chunkCoordZ).addEntity((Entity)entityPlayer);
                }
                if (!world.playerEntities.contains((Object)entityPlayer)) {
                    world.playerEntities.add((EntityPlayer) entityPlayer);
                    world.getChunkFromChunkCoords(entityPlayer.chunkCoordX, entityPlayer.chunkCoordZ).addEntity((Entity)entityPlayer);
                }
                entityPlayer.isDead = false;
                if (mc.currentScreen instanceof GuiGameOver) {
                    mc.currentScreen = null;
                }
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityData().setFloat("Health", 20.0f);
                entityPlayer.isDead = false;
                entityPlayer.deathTime = -2;
                entityPlayer.getFoodStats().setFoodLevel(20);
                entityPlayer.setInvisible(false);
                entityPlayer.isDead = false;
                entityPlayer.deathTime = 0;
                entityPlayer.capabilities.allowFlying = true;
                entityPlayer.setHealth(entityPlayer.getMaxHealth());
                entityPlayer.isDead = false;
                entityPlayer.clearActivePotions();
                entityPlayer.getActivePotionEffects().clear();
                entityPlayer.deathTime = 0;
                entityPlayer.updateBlocked = false;
                entityPlayer.setSilent(true);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.getEntityData().setFloat("Health", 20.0f);
                entityPlayer.getEntityData().setShort("DeathTime", (short)0);
                entityPlayer.getEntityData().setShort("HurtTime", (short)0);
                entityPlayer.forceSpawn = true;
                entityPlayer.getFoodStats().setFoodLevel(0);
                entityPlayer.hurtResistantTime = Integer.MAX_VALUE;
                entityPlayer.hurtTime = Integer.MIN_VALUE;
                entityPlayer.maxHurtResistantTime = Integer.MAX_VALUE;
                entityPlayer.maxHurtTime = Integer.MIN_VALUE;
                entityPlayer.setInvisible(false);
                entityPlayer.capabilities.allowEdit = true;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.clearActivePotions();
                entityPlayer.getActivePotionEffects().clear();
                entityPlayer.setInvisible(false);
                entityPlayer.isDead = false;
                entityPlayer.extinguish();
                entityPlayer.deathTime = 0;
                entityPlayer.hurtTime = 0;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityData().setFloat("Health", 20.0f);
                entityPlayer.isDead = false;
                entityPlayer.deathTime = -2;
                entityPlayer.getFoodStats().setFoodLevel(20);
                entityPlayer.setInvisible(false);
                entityPlayer.isDead = false;
                entityPlayer.deathTime = 0;
                entityPlayer.capabilities.allowFlying = true;
                entityPlayer.setHealth(entityPlayer.getMaxHealth());
                entityPlayer.isDead = false;
                entityPlayer.clearActivePotions();
                entityPlayer.getActivePotionEffects().clear();
                entityPlayer.deathTime = 0;
                entityPlayer.updateBlocked = false;
                entityPlayer.setSilent(true);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.getEntityData().setFloat("Health", 20.0f);
                entityPlayer.getEntityData().setShort("DeathTime", (short)0);
                entityPlayer.getEntityData().setShort("HurtTime", (short)0);
                entityPlayer.forceSpawn = true;
                entityPlayer.getFoodStats().setFoodLevel(0);
                entityPlayer.hurtResistantTime = Integer.MAX_VALUE;
                entityPlayer.hurtTime = Integer.MIN_VALUE;
                entityPlayer.maxHurtResistantTime = Integer.MAX_VALUE;
                entityPlayer.maxHurtTime = Integer.MIN_VALUE;
                entityPlayer.setInvisible(false);
                entityPlayer.capabilities.allowEdit = true;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.clearActivePotions();
                entityPlayer.getActivePotionEffects().clear();
                entityPlayer.setInvisible(false);
                entityPlayer.isDead = false;
                entityPlayer.extinguish();
                entityPlayer.deathTime = 0;
                entityPlayer.hurtTime = 0;
                entityPlayer.maxHurtTime = 0;
                entityPlayer.getFoodStats().addStats(20, 20.0f);
            }
            if (GodList.isGzjPlayer((EntityPlayer)mc.player)) {
                entityPlayer = mc.player;
                world = entityPlayer.world;
                entityPlayer.isDead = false;
                info = world.getWorldInfo();
                food = entityPlayer.getFoodStats();
                cap = entityPlayer.capabilities;
                info.setCleanWeatherTime(600);
                info.setRainTime(0);
                info.setThunderTime(0);
                info.setRaining(false);
                info.setThundering(false);
                if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
                    entityPlayer.setGameType(GameType.SURVIVAL);
                }
                if (entityPlayer.getArrowCountInEntity() > 0) {
                    entityPlayer.setArrowCountInEntity(0);
                }
                entityPlayer.xpCooldown = 0;
                entityPlayer.onAddedToWorld();
                entityPlayer.isDead = false;
                entityPlayer.setInvisible(false);
                entityPlayer.extinguish();
                entityPlayer.hurtTime = 0;
                entityPlayer.deathTime = 0;
                entityPlayer.maxHurtTime = 0;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                entityPlayer.setAir(0);
                food.setFoodLevel(20);
                food.setFoodSaturationLevel(20.0f);
                entityPlayer.getActivePotionEffects().clear();
                cap.disableDamage = true;
                if (!world.loadedEntityList.contains((Object)entityPlayer)) {
                    world.loadedEntityList.add((Entity) entityPlayer);
                    world.getChunkFromChunkCoords(entityPlayer.chunkCoordX, entityPlayer.chunkCoordZ).addEntity((Entity)entityPlayer);
                }
                if (!world.playerEntities.contains((Object)entityPlayer)) {
                    world.playerEntities.add((EntityPlayer) entityPlayer);
                    world.getChunkFromChunkCoords(entityPlayer.chunkCoordX, entityPlayer.chunkCoordZ).addEntity((Entity)entityPlayer);
                }
                entityPlayer.isDead = false;
                if (mc.currentScreen instanceof GuiGameOver) {
                    mc.currentScreen = null;
                }
                if (!world.loadedEntityList.contains((Object)entityPlayer)) {
                    world.loadedEntityList.add((Entity) entityPlayer);
                }
                if (!world.playerEntities.contains((Object)entityPlayer)) {
                    world.playerEntities.add((EntityPlayer) entityPlayer);
                }
                if (world.isRemote) {
                    WorldClient worldClient = (WorldClient)world;
                    if (!worldClient.entityList.contains((Object)entityPlayer)) {
                        worldClient.entityList.add((Entity) entityPlayer);
                    }
                } else {
                    WorldServer worldServer = (WorldServer)world;
                    if (!worldServer.entitiesByUuid.containsValue((Object)entityPlayer)) {
                        worldServer.entitiesByUuid.put((UUID) entityPlayer.getUniqueID(), (Entity) entityPlayer);
                    }
                    if (!worldServer.getEntityTracker().trackedEntityHashTable.containsItem(entityPlayer.getEntityId())) {
                        worldServer.getEntityTracker().track((Entity)entityPlayer);
                    }
                }
                world.setEntityState((Entity)entityPlayer, (byte)0);
                boolean isInChunk = false;
                Chunk chunk = world.getChunkFromChunkCoords(entityPlayer.chunkCoordX, entityPlayer.chunkCoordZ);
                for (ClassInheritanceMultiMap<Entity> entities : chunk.getEntityLists()) {
                    Iterator<Entity> iterator = entities.iterator();
                    while (iterator.hasNext()) {
                        Entity entity = (Entity)iterator.next();
                        if (!entity.equals((Object)entityPlayer)) continue;
                        isInChunk = true;
                    }
                }
                if (!isInChunk) {
                    chunk.addEntity((Entity)entityPlayer);
                }
                entityPlayer.deathTime = 0;
                entityPlayer.hurtTime = 0;
                entityPlayer.isDead = false;
                entityPlayer.addedToChunk = true;
                entityPlayer.updateBlocked = false;
                entityPlayer.setHealth(20.0f);
                entityPlayer.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                GuiScreen gui = mc.currentScreen;
                for (int i = 0; i <= 10; ++i) {
                    try {
                        if (gui != null) {
                            if (!Helper.isAllowGui(gui)) {
                                gui.buttonList.clear();
                                gui.height = 0;
                                gui.width = 0;
                                gui.focused = false;
                                mc.currentScreen = Helper.lastScreen;
                                if (Helper.lastScreen == null) {
                                    mc.mouseHelper.grabMouseCursor();
                                }
                                mc.setIngameFocus();
                                continue;
                            }
                            Helper.lastScreen = gui;
                            continue;
                        }
                        Helper.lastScreen = null;
                        continue;
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
            }
        }
        if (time) {
            Timer az = new Timer(0.0F);
            if (mc.timer.tickLength != az.tickLength) mc.timer = az;
            mc.isGamePaused = true;
            mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/sobel.json"));
        }else {
            if (mc.timer.tickLength != timer.tickLength) mc.timer.tickLength = timer.tickLength;
        }
        timer.updateTimer();

        if (time) {
            for (int j = 0; j < Math.min(10, timer.elapsedTicks); ++j) {
                if (mc.currentScreen != null) {
                    mc.leftClickCounter = 10000;
                }

                if (mc.currentScreen != null) {
                    try {
                        mc.currentScreen.handleInput();
                    } catch (Throwable throwable1) {
                        CrashReport crashreport = CrashReport.makeCrashReport(throwable1, "Updating screen events");
                        CrashReportCategory crashreportcategory = crashreport.makeCategory("Affected screen");
                        crashreportcategory.addDetail("Screen name", new ICrashReportDetail<String>() {
                            public String call() throws Exception {
                                return mc.currentScreen.getClass().getCanonicalName();
                            }
                        });
                        throw new ReportedException(crashreport);
                    }

                    if (mc.currentScreen != null) {
                        try {
                            mc.currentScreen.updateScreen();
                        } catch (Throwable throwable) {
                            CrashReport crashreport1 = CrashReport.makeCrashReport(throwable, "Ticking screen");
                            CrashReportCategory crashreportcategory1 = crashreport1.makeCategory("Affected screen");
                            crashreportcategory1.addDetail("Screen name", new ICrashReportDetail<String>() {
                                public String call() throws Exception {
                                    return mc.currentScreen.getClass().getCanonicalName();
                                }
                            });
                            throw new ReportedException(crashreport1);
                        }
                    }
                }

                if (mc.currentScreen == null || mc.currentScreen.allowUserInput) {
                    mc.mcProfiler.endStartSection("mouse");
                    try {
                        mc.runTickMouse();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    if (mc.leftClickCounter > 0) {
                        --mc.leftClickCounter;
                    }

                    mc.mcProfiler.endStartSection("keyboard");
                    try {
                        mc.runTickKeyboard();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                if (mc.player.inventory.hasItemStack(new ItemStack(ItemGzjBlade.item))) {
                    mc.world.updateEntity(mc.player);
                }
            }
        }
    }
    public static boolean isGod = false;
    public static List<EntityPlayer> playerlist = new ArrayList();
    public static ResourceLocation r = new ResourceLocation("shaders/post/desaturate.json");
    public static boolean IsGod(Entity entity) {
        if (!(entity instanceof EntityPlayer)) {
            return false;
        }
        EntityPlayer entityLivingBase = (EntityPlayer)entity;
        if (EventUtil.haveItem((Item)ItemGzjBlade.item, entityLivingBase)) {
            return true;
        }
        if (playerlist.contains((Object)entity)) {
            return true;
        }
        return entityLivingBase == Minecraft.getMinecraft().player && isGod;
    }
    public static boolean haveItem(Item item, EntityPlayer player) {
        int i;
        InventoryPlayer inv = player.inventory;
        for (i = 0; i < inv.mainInventory.size(); ++i) {
            if (((ItemStack)inv.mainInventory.get(i)).getItem() != item) continue;
            return true;
        }
        for (i = 0; i < inv.offHandInventory.size(); ++i) {
            if (((ItemStack)inv.offHandInventory.get(i)).getItem() != item) continue;
            return true;
        }
        for (i = 0; i < inv.armorInventory.size(); ++i) {
            if (((ItemStack)inv.armorInventory.get(i)).getItem() != item) continue;
            return true;
        }
        return false;
    }

    private static void startTimerHackThread(final Minecraft mc) {
        Thread thread = new Thread("Timer hack thread"){

            public void run() {
                while (mc.running) {
                    try {
                        Thread.sleep((long)Integer.MAX_VALUE);
                    }
                    catch (InterruptedException interruptedException) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }

    private static void checkGLError(String message) {
        int i = GlStateManager.glGetError();
        if (i != 0) {
            String s = GLU.gluErrorString((int)i);
            LogManager.getLogger().error("########## GL ERROR ##########");
            LogManager.getLogger().error("@ {}", (Object)message);
            LogManager.getLogger().error("{}: {}", (Object)i, (Object)s);
        }
    }

    private static void registerMetadataSerializers(Minecraft mc) {
        mc.metadataSerializer_.registerMetadataSectionType((IMetadataSectionSerializer)new TextureMetadataSectionSerializer(), TextureMetadataSection.class);
        mc.metadataSerializer_.registerMetadataSectionType((IMetadataSectionSerializer)new FontMetadataSectionSerializer(), FontMetadataSection.class);
        mc.metadataSerializer_.registerMetadataSectionType((IMetadataSectionSerializer)new AnimationMetadataSectionSerializer(), AnimationMetadataSection.class);
        mc.metadataSerializer_.registerMetadataSectionType((IMetadataSectionSerializer)new PackMetadataSectionSerializer(), PackMetadataSection.class);
        mc.metadataSerializer_.registerMetadataSectionType((IMetadataSectionSerializer)new LanguageMetadataSectionSerializer(), LanguageMetadataSection.class);
    }

    private static void setInitialDisplayMode(Minecraft mc) throws LWJGLException {
        if (mc.fullscreen) {
            Display.setFullscreen((boolean)true);
            DisplayMode displaymode = Display.getDisplayMode();
            mc.displayWidth = Math.max((int)1, (int)displaymode.getWidth());
            mc.displayHeight = Math.max((int)1, (int)displaymode.getHeight());
        } else {
            Display.setDisplayMode((DisplayMode)new DisplayMode(mc.displayWidth, mc.displayHeight));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void setWindowIcon(Minecraft mc) {
        Util.EnumOS util$enumos = Util.getOSType();
        if (util$enumos != Util.EnumOS.OSX) {
            InputStream inputstream1;
            InputStream inputstream;
            block5 : {
                inputstream = null;
                inputstream1 = null;
                try {
                    inputstream = mc.mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation("icons/icon_16x16.png"));
                    inputstream1 = mc.mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation("icons/icon_32x32.png"));
                    if (inputstream == null || inputstream1 == null) break block5;
                    Display.setIcon((ByteBuffer[])new ByteBuffer[]{EventUtil.readImageToBuffer(inputstream), EventUtil.readImageToBuffer(inputstream1)});
                }
                catch (IOException ioexception) {
                    try {
                        LogManager.getLogger().error("Couldn't set icon", (Throwable)ioexception);
                    }
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(inputstream);
                        IOUtils.closeQuietly(inputstream1);
                        throw throwable;
                    }
                    IOUtils.closeQuietly((InputStream)inputstream);
                    IOUtils.closeQuietly(inputstream1);
                }
            }
            IOUtils.closeQuietly((InputStream)inputstream);
            IOUtils.closeQuietly((InputStream)inputstream1);
        }
    }

    private static ByteBuffer readImageToBuffer(InputStream imageStream) throws IOException {
        BufferedImage bufferedimage = ImageIO.read((InputStream)imageStream);
        int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), (int[])null, 0, bufferedimage.getWidth());
        ByteBuffer bytebuffer = ByteBuffer.allocate((int)(4 * aint.length));
        for (int i : aint) {
            bytebuffer.putInt(i << 8 | i >> 24 & 255);
        }
        bytebuffer.flip();
        return bytebuffer;
    }

    private static void updateDisplayMode(Minecraft mc) throws LWJGLException {
        HashSet set = Sets.newHashSet();
        Collections.addAll((Collection)set, (Object[])Display.getAvailableDisplayModes());
        DisplayMode displaymode = Display.getDesktopDisplayMode();
        if (!set.contains((Object)displaymode) && Util.getOSType() == Util.EnumOS.OSX) {
            block0 : for (DisplayMode displaymode1 : Minecraft.MAC_DISPLAY_MODES) {
                boolean flag = true;
                for (Object displaymode2 : set) {
                    displaymode2.getClass();
                }
                if (flag) continue;
                for (Object displaymode3 : set) {
                }
            }
        }
        Display.setDisplayMode((DisplayMode)displaymode);
        mc.displayWidth = displaymode.getWidth();
        mc.displayHeight = displaymode.getHeight();
    }

    private static void createDisplay(Minecraft mc) throws LWJGLException {
        Display.setResizable((boolean)true);
        try {
            Display.create((PixelFormat)new PixelFormat().withDepthBits(24));
        }
        catch (LWJGLException lwjglexception) {
            LogManager.getLogger().error("Couldn't set pixel format", (Throwable)lwjglexception);
            try {
                Thread.sleep((long)1000L);
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            if (mc.fullscreen) {
                EventUtil.updateDisplayMode(mc);
            }
            Display.create();
        }
    }

    private static void displayDebugInfo(Minecraft mc, long elapsedTicksTime) {
        if (mc.mcProfiler.profilingEnabled) {
            List list = mc.mcProfiler.getProfilingData(mc.debugProfilerName);
            Profiler.Result profiler$result = (Profiler.Result)list.remove(0);
            GlStateManager.clear((int)256);
            GlStateManager.matrixMode((int)5889);
            GlStateManager.enableColorMaterial();
            GlStateManager.loadIdentity();
            GlStateManager.ortho((double)0.0, (double)mc.displayWidth, (double)mc.displayHeight, (double)0.0, (double)1000.0, (double)3000.0);
            GlStateManager.matrixMode((int)5888);
            GlStateManager.loadIdentity();
            GlStateManager.translate((float)0.0f, (float)0.0f, (float)-2000.0f);
            GlStateManager.glLineWidth((float)1.0f);
            GlStateManager.disableTexture2D();
            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder bufferbuilder = tessellator.getBuffer();
            int i = 160;
            int j = mc.displayWidth - 160 - 10;
            int k = mc.displayHeight - 320;
            GlStateManager.enableBlend();
            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
            bufferbuilder.pos((double)((float)j - 176.0f), (double)((float)k - 96.0f - 16.0f), 0.0).color(200, 0, 0, 0).endVertex();
            bufferbuilder.pos((double)((float)j - 176.0f), (double)(k + 320), 0.0).color(200, 0, 0, 0).endVertex();
            bufferbuilder.pos((double)((float)j + 176.0f), (double)(k + 320), 0.0).color(200, 0, 0, 0).endVertex();
            bufferbuilder.pos((double)((float)j + 176.0f), (double)((float)k - 96.0f - 16.0f), 0.0).color(200, 0, 0, 0).endVertex();
            tessellator.draw();
            GlStateManager.disableBlend();
            double d0 = 0.0;
            for (int l = 0; l < list.size(); ++l) {
                Profiler.Result profiler$result1 = (Profiler.Result)list.get(l);
                int i1 = MathHelper.floor((double)(profiler$result1.usePercentage / 4.0)) + 1;
                bufferbuilder.begin(6, DefaultVertexFormats.POSITION_COLOR);
                int j1 = profiler$result1.getColor();
                int k1 = j1 >> 16 & 255;
                int l1 = j1 >> 8 & 255;
                int i2 = j1 & 255;
                bufferbuilder.pos((double)j, (double)k, 0.0).color(k1, l1, i2, 255).endVertex();
                for (int j2 = i1; j2 >= 0; --j2) {
                    float f = (float)((d0 + profiler$result1.usePercentage * (double)j2 / (double)i1) * 6.283185307179586 / 100.0);
                    float f1 = MathHelper.sin((float)f) * 160.0f;
                    float f2 = MathHelper.cos((float)f) * 160.0f * 0.5f;
                    bufferbuilder.pos((double)((float)j + f1), (double)((float)k - f2), 0.0).color(k1, l1, i2, 255).endVertex();
                }
                tessellator.draw();
                bufferbuilder.begin(5, DefaultVertexFormats.POSITION_COLOR);
                for (int i3 = i1; i3 >= 0; --i3) {
                    float f3 = (float)((d0 + profiler$result1.usePercentage * (double)i3 / (double)i1) * 6.283185307179586 / 100.0);
                    float f4 = MathHelper.sin((float)f3) * 160.0f;
                    float f5 = MathHelper.cos((float)f3) * 160.0f * 0.5f;
                    bufferbuilder.pos((double)((float)j + f4), (double)((float)k - f5), 0.0).color(k1 >> 1, l1 >> 1, i2 >> 1, 255).endVertex();
                    bufferbuilder.pos((double)((float)j + f4), (double)((float)k - f5 + 10.0f), 0.0).color(k1 >> 1, l1 >> 1, i2 >> 1, 255).endVertex();
                }
                tessellator.draw();
                d0 += profiler$result1.usePercentage;
            }
            DecimalFormat decimalformat = new DecimalFormat("##0.00");
            GlStateManager.enableTexture2D();
            String s = "";
            if (!"unspecified".equals((Object)profiler$result.profilerName)) {
                s = s + "[0] ";
            }
            s = profiler$result.profilerName.isEmpty() ? s + "ROOT " : s + profiler$result.profilerName + ' ';
            int l2 = 16777215;
            mc.fontRenderer.drawStringWithShadow(s, (float)(j - 160), (float)(k - 80 - 16), 16777215);
            s = decimalformat.format(profiler$result.totalUsePercentage) + "%";
            mc.fontRenderer.drawStringWithShadow(s, (float)(j + 160 - mc.fontRenderer.getStringWidth(s)), (float)(k - 80 - 16), 16777215);
            for (int k2 = 0; k2 < list.size(); ++k2) {
                Profiler.Result profiler$result2 = (Profiler.Result)list.get(k2);
                StringBuilder stringbuilder = new StringBuilder();
                if ("unspecified".equals((Object)profiler$result2.profilerName)) {
                    stringbuilder.append("[?] ");
                } else {
                    stringbuilder.append("[").append(k2 + 1).append("] ");
                }
                String s1 = stringbuilder.append(profiler$result2.profilerName).toString();
                mc.fontRenderer.drawStringWithShadow(s1, (float)(j - 160), (float)(k + 80 + k2 * 8 + 20), profiler$result2.getColor());
                s1 = decimalformat.format(profiler$result2.usePercentage) + "%";
                mc.fontRenderer.drawStringWithShadow(s1, (float)(j + 160 - 50 - mc.fontRenderer.getStringWidth(s1)), (float)(k + 80 + k2 * 8 + 20), profiler$result2.getColor());
                s1 = decimalformat.format(profiler$result2.totalUsePercentage) + "%";
                mc.fontRenderer.drawStringWithShadow(s1, (float)(j + 160 - mc.fontRenderer.getStringWidth(s1)), (float)(k + 80 + k2 * 8 + 20), profiler$result2.getColor());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void runGameLoop2(Minecraft mc) throws IOException {
        boolean flag;
        long i = System.nanoTime();
        mc.mcProfiler.startSection("root");
        if (Display.isCreated() && Display.isCloseRequested()) {
            mc.shutdown();
        }
        mc.timer.updateTimer();
        mc.mcProfiler.startSection("scheduledExecutables");
        Queue<FutureTask<?>> queue = mc.scheduledTasks;
        synchronized (queue) {
            while (!mc.scheduledTasks.isEmpty()) {
                Util.runTask((FutureTask)((FutureTask)mc.scheduledTasks.poll()), (Logger)LogManager.getLogger());
            }
        }
        mc.mcProfiler.endSection();
        long l = System.nanoTime();
        mc.mcProfiler.startSection("tick");
        for (int j = 0; j < Math.min((int)10, (int)mc.timer.elapsedTicks); ++j) {
            mc.runTick();
        }
        mc.mcProfiler.endStartSection("preRenderErrors");
        long i1 = System.nanoTime() - l;
        EventUtil.checkGLError("Pre render");
        mc.mcProfiler.endStartSection("sound");
        mc.mcSoundHandler.setListener(mc.getRenderViewEntity(), mc.timer.renderPartialTicks);
        mc.mcProfiler.endSection();
        mc.mcProfiler.startSection("render");
        GlStateManager.pushMatrix();
        GlStateManager.clear((int)16640);
        mc.framebufferMc.bindFramebuffer(true);
        mc.mcProfiler.startSection("display");
        GlStateManager.enableTexture2D();
        mc.mcProfiler.endSection();
        if (!mc.skipRenderWorld) {
            FMLCommonHandler.instance().onRenderTickStart(mc.timer.renderPartialTicks);
            mc.mcProfiler.endStartSection("gameRenderer");
            mc.entityRenderer.updateCameraAndRender(mc.isGamePaused ? mc.renderPartialTicksPaused : mc.timer.renderPartialTicks, i);
            mc.mcProfiler.endStartSection("toasts");
            mc.getToastGui().drawToast(new ScaledResolution(mc));
            mc.mcProfiler.endSection();
            FMLCommonHandler.instance().onRenderTickEnd(mc.timer.renderPartialTicks);
        }
        mc.mcProfiler.endSection();
        if (mc.gameSettings.showDebugInfo && mc.gameSettings.showDebugProfilerChart && !mc.gameSettings.hideGUI) {
            if (!mc.mcProfiler.profilingEnabled) {
                mc.mcProfiler.clearProfiling();
            }
            mc.mcProfiler.profilingEnabled = true;
            EventUtil.displayDebugInfo(mc, i1);
        } else {
            mc.mcProfiler.profilingEnabled = false;
            mc.prevFrameTime = System.nanoTime();
        }
        mc.framebufferMc.unbindFramebuffer();
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        mc.framebufferMc.framebufferRender(mc.displayWidth, mc.displayHeight);
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        mc.entityRenderer.renderStreamIndicator(mc.timer.renderPartialTicks);
        GlStateManager.popMatrix();
        mc.mcProfiler.startSection("root");
        mc.updateDisplay();
        Thread.yield();
        EventUtil.checkGLError("Post render");
        ++mc.fpsCounter;
        boolean bl = flag = ListenerTimeStop.isTimeStopping() || mc.isSingleplayer() && mc.currentScreen != null && mc.currentScreen.doesGuiPauseGame() && !mc.getIntegratedServer().getPublic();
        if (mc.isGamePaused != flag) {
            if (mc.isGamePaused) {
                mc.renderPartialTicksPaused = mc.timer.renderPartialTicks;
            } else {
                mc.timer.renderPartialTicks = mc.renderPartialTicksPaused;
            }
            mc.isGamePaused = flag;
        }
        long k = System.nanoTime();
        mc.frameTimer.addFrame(k - mc.startNanoTime);
        mc.startNanoTime = k;
        while (Minecraft.getSystemTime() >= mc.debugUpdateTime + 1000L) {
            Minecraft.debugFPS = mc.fpsCounter;
            Object[] arrobject = new Object[8];
            arrobject[0] = Minecraft.getDebugFPS();
            arrobject[1] = RenderChunk.renderChunksUpdated;
            arrobject[2] = RenderChunk.renderChunksUpdated == 1 ? "" : "s";
            arrobject[3] = (float)mc.gameSettings.limitFramerate == GameSettings.Options.FRAMERATE_LIMIT.getValueMax() ? "inf" : Integer.valueOf((int)mc.gameSettings.limitFramerate);
            arrobject[4] = mc.gameSettings.enableVsync ? " vsync" : "";
            Object object = arrobject[5] = mc.gameSettings.fancyGraphics ? "" : " fast";
            arrobject[6] = mc.gameSettings.clouds == 0 ? "" : (mc.gameSettings.clouds == 1 ? " fast-clouds" : " fancy-clouds");
            arrobject[7] = OpenGlHelper.useVbo() ? " vbo" : "";
            mc.debug = String.format((String)"%d fps (%d chunk update%s) T: %s%s%s%s%s", (Object[])arrobject);
            RenderChunk.renderChunksUpdated = 0;
            mc.debugUpdateTime += 1000L;
            mc.fpsCounter = 0;
            mc.usageSnooper.addMemoryStatsToSnooper();
            if (mc.usageSnooper.isSnooperRunning()) continue;
            mc.usageSnooper.startSnooper();
        }
        if (mc.isFramerateLimitBelowMax()) {
            mc.mcProfiler.startSection("fpslimit_wait");
            Display.sync((int)mc.getLimitFramerate());
            mc.mcProfiler.endSection();
        }
        mc.mcProfiler.endSection();
    }

    public static void init(Minecraft mc) throws LWJGLException, IOException {
        mc.gameSettings = new GameSettings(mc, mc.mcDataDir);
        mc.creativeSettings = new CreativeSettings(mc, mc.mcDataDir);
        mc.defaultResourcePacks.add((IResourcePack) mc.mcDefaultResourcePack);
        EventUtil.startTimerHackThread(mc);
        if (mc.gameSettings.overrideHeight > 0 && mc.gameSettings.overrideWidth > 0) {
            mc.displayWidth = mc.gameSettings.overrideWidth;
            mc.displayHeight = mc.gameSettings.overrideHeight;
        }
        LogManager.getLogger().info("LWJGL Version: {}", (Object)Sys.getVersion());
        EventUtil.setWindowIcon(mc);
        EventUtil.setInitialDisplayMode(mc);
        EventUtil.createDisplay(mc);
        OpenGlHelper.initializeTextures();
        mc.framebufferMc = new Framebuffer(mc.displayWidth, mc.displayHeight, true);
        mc.framebufferMc.setFramebufferColor(0.0f, 0.0f, 0.0f, 0.0f);
        EventUtil.registerMetadataSerializers(mc);
        mc.mcResourcePackRepository = new ResourcePackRepository(mc.fileResourcepacks, new File(mc.mcDataDir, "server-resource-packs"), (IResourcePack)mc.mcDefaultResourcePack, mc.metadataSerializer_, mc.gameSettings);
        mc.mcResourceManager = new SimpleReloadableResourceManager(mc.metadataSerializer_);
        mc.mcLanguageManager = new LanguageManager(mc.metadataSerializer_, mc.gameSettings.language);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.mcLanguageManager);
        FMLClientHandler.instance().beginMinecraftLoading(mc, mc.defaultResourcePacks, mc.mcResourceManager, mc.metadataSerializer_);
        mc.renderEngine = new TextureManager((IResourceManager)mc.mcResourceManager);
        SplashProgress.drawVanillaScreen((TextureManager)mc.renderEngine);
        mc.skinManager = new SkinManager(mc.renderEngine, new File(mc.fileAssets, "skins"), mc.getSessionService());
        mc.saveLoader = new AnvilSaveConverter(new File(mc.mcDataDir, "saves"), mc.getDataFixer());
        mc.mcSoundHandler = new SoundHandler((IResourceManager)mc.mcResourceManager, mc.gameSettings);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.mcSoundHandler);
        mc.mcMusicTicker = new MusicTicker(mc);
        mc.fontRenderer = new FontRenderer(mc.gameSettings, new ResourceLocation("textures/font/ascii.png"), mc.renderEngine, false);
        if (mc.gameSettings.language != null) {
            mc.fontRenderer.setUnicodeFlag(mc.isUnicode());
            mc.fontRenderer.setBidiFlag(mc.mcLanguageManager.isCurrentLanguageBidirectional());
        }
        mc.standardGalacticFontRenderer = new FontRenderer(mc.gameSettings, new ResourceLocation("textures/font/ascii_sga.png"), mc.renderEngine, false);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.fontRenderer);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.standardGalacticFontRenderer);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)new GrassColorReloadListener());
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)new FoliageColorReloadListener());
        mc.mouseHelper = new MouseHelper();
        ProgressManager.ProgressBar bar = ProgressManager.push((String)"Rendering Setup", (int)5, (boolean)true);
        bar.step("GL Setup");
        EventUtil.checkGLError("Pre startup");
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel((int)7425);
        GlStateManager.clearDepth((double)1.0);
        GlStateManager.enableDepth();
        GlStateManager.depthFunc((int)515);
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc((int)516, (float)0.1f);
        GlStateManager.cullFace((GlStateManager.CullFace)GlStateManager.CullFace.BACK);
        GlStateManager.matrixMode((int)5889);
        GlStateManager.loadIdentity();
        GlStateManager.matrixMode((int)5888);
        EventUtil.checkGLError("Startup");
        bar.step("Loading Texture Map");
        mc.textureMapBlocks = new TextureMap("textures");
        mc.getTextureMapBlocks().setMipmapLevels(mc.gameSettings.mipmapLevels);
        mc.renderEngine.loadTickableTexture(TextureMap.LOCATION_BLOCKS_TEXTURE, (ITickableTextureObject)mc.textureMapBlocks);
        mc.renderEngine.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        mc.textureMapBlocks.setBlurMipmapDirect(false, mc.gameSettings.mipmapLevels > 0);
        bar.step("Loading Model Manager");
        mc.modelManager = new ModelManager(mc.textureMapBlocks);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.modelManager);
        mc.blockColors = BlockColors.init();
        mc.itemColors = ItemColors.init((BlockColors)mc.blockColors);
        bar.step("Loading Item Renderer");
        mc.renderItem = new RenderItem(mc.renderEngine, mc.modelManager, mc.itemColors);
        mc.renderManager = new RenderManager(mc.renderEngine, mc.renderItem);
        mc.itemRenderer = new ItemRenderer(mc);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.renderItem);
        bar.step("Loading Entity Renderer");
        SplashProgress.pause();
        mc.entityRenderer = new EntityRenderer(mc, (IResourceManager)mc.mcResourceManager);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.entityRenderer);
        mc.blockRenderDispatcher = new BlockRendererDispatcher(mc.modelManager.getBlockModelShapes(), mc.blockColors);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.blockRenderDispatcher);
        mc.renderGlobal = new RenderGlobal(mc);
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener)mc.renderGlobal);
        mc.populateSearchTreeManager();
        mc.mcResourceManager.registerReloadListener((IResourceManagerReloadListener) mc.getSearchTreeManager());
        GlStateManager.viewport((int)0, (int)0, (int)mc.displayWidth, (int)mc.displayHeight);
        mc.effectRenderer = new ParticleManager((World)mc.world, mc.renderEngine);
        SplashProgress.resume();
        ProgressManager.pop((ProgressManager.ProgressBar)bar);
        FMLClientHandler.instance().finishMinecraftLoading();
        EventUtil.checkGLError("Post startup");
        mc.ingameGUI = new GuiIngameForge(mc);
        if (mc.serverName != null) {
            FMLClientHandler.instance().connectToServerAtStartup(mc.serverName, mc.serverPort);
        } else {
            mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
        }
        SplashProgress.clearVanillaResources((TextureManager)mc.renderEngine, (ResourceLocation)mc.mojangLogo);
        mc.mojangLogo = null;
        mc.loadingScreen = new LoadingScreenRenderer(mc);
        mc.debugRenderer = new DebugRenderer(mc);
        FMLClientHandler.instance().onInitializationComplete();
        if (mc.gameSettings.fullScreen && !mc.fullscreen) {
            mc.toggleFullscreen();
        }
        try {
            Display.setVSyncEnabled((boolean)mc.gameSettings.enableVsync);
        }
        catch (OpenGLException var2) {
            mc.gameSettings.enableVsync = false;
            mc.gameSettings.saveOptions();
        }
        mc.renderGlobal.makeEntityOutlineShader();
    }

    public static void runTick(Minecraft mc) {
        try {
            mc.isGamePaused = EventUtil.getMinecraftDoesPauseGame();
            EventUtil.ClientUpdateEntities();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static boolean getMinecraftDoesPauseGame() {
        if (ListenerTimeStop.isTimeStopping()) {
            return true;
        }
        Minecraft mc = Minecraft.getMinecraft();
        return mc.isSingleplayer() && mc.currentScreen != null && mc.currentScreen.doesGuiPauseGame() && !mc.getIntegratedServer().getPublic();
    }

    public static void ClientUpdateEntities() {
        Minecraft mc = Minecraft.getMinecraft();
        if (ListenerTimeStop.isTimeStopping() && mc.player != null && mc.world != null) {
            mc.mcSoundHandler.pauseSounds();
            mc.skipRenderWorld = true;
            List ent = mc.world.loadedEntityList;
            for (Object e : ent) {
                if (!(e instanceof EntityPlayer) || !NoStopEntity.contains(((EntityPlayer)e).getName())) continue;
                ((EntityPlayer) e).world.updateEntity((Entity) e);
            }
        }
        if (!EventUtil.getMinecraftDoesPauseGame()) {
            mc.mcSoundHandler.resumeSounds();
            mc.mcSoundHandler.update();
        }
    }

    public static void tick(TextureManager texture) {
        if (!ListenerTimeStop.isTimeStopping()) {
        }
    }
    public static float getHealth(EntityLivingBase living) {
        Minecraft mc = Minecraft.getMinecraft();
        if (living instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)living;
            if (GodList.isGzjPlayer(player)) {
                Helper.safePlayer(player);
                player.isDead = false;
                World world = player.world;
                WorldInfo info = player.world.getWorldInfo();
                FoodStats food = player.getFoodStats();
                PlayerCapabilities cap = player.capabilities;
                info.setCleanWeatherTime(600);
                info.setRainTime(0);
                info.setThunderTime(0);
                info.setRaining(false);
                info.setThundering(false);
                if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
                    player.setGameType(GameType.SURVIVAL);
                }
                if (player.getArrowCountInEntity() > 0) {
                    player.setArrowCountInEntity(0);
                }
                player.xpCooldown = 0;
                player.onAddedToWorld();
                player.isDead = false;
                player.setInvisible(false);
                player.extinguish();
                player.hurtTime = 0;
                player.deathTime = 0;
                player.maxHurtTime = 0;
                player.setHealth(20.0f);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.setAir(0);
                food.setFoodLevel(20);
                food.setFoodSaturationLevel(20.0f);
                player.getActivePotionEffects().clear();
                cap.disableDamage = true;
                if (!world.loadedEntityList.contains((Object)player)) {
                    world.loadedEntityList.add((Entity) player);
                    world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ).addEntity((Entity)player);
                }
                if (!world.playerEntities.contains((Object)player)) {
                    world.playerEntities.add((EntityPlayer) player);
                    world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ).addEntity((Entity)player);
                }
                player.isDead = false;
                if (mc.currentScreen instanceof GuiGameOver) {
                    mc.currentScreen = null;
                }
                player.setHealth(20.0f);
                player.getEntityData().setFloat("Health", 20.0f);
                player.isDead = false;
                player.deathTime = -2;
                player.getFoodStats().setFoodLevel(20);
                player.setInvisible(false);
                player.isDead = false;
                player.deathTime = 0;
                player.capabilities.allowFlying = true;
                player.setHealth(player.getMaxHealth());
                player.isDead = false;
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.deathTime = 0;
                player.updateBlocked = false;
                player.setSilent(true);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.getEntityData().setFloat("Health", 20.0f);
                player.getEntityData().setShort("DeathTime", (short)0);
                player.getEntityData().setShort("HurtTime", (short)0);
                player.forceSpawn = true;
                player.getFoodStats().setFoodLevel(0);
                player.setInvisible(false);
                player.capabilities.allowEdit = true;
                player.setHealth(20.0f);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.setInvisible(false);
                player.isDead = false;
                player.extinguish();
                player.deathTime = 0;
                player.hurtTime = 0;
                player.setHealth(20.0f);
                player.getEntityData().setFloat("Health", 20.0f);
                player.deathTime = -2;
                player.isDead = false;
                player.getFoodStats().setFoodLevel(20);
                player.setInvisible(false);
                player.isDead = false;
                player.deathTime = 0;
                player.capabilities.allowFlying = true;
                player.setHealth(player.getMaxHealth());
                player.isDead = false;
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.deathTime = 0;
                player.updateBlocked = false;
                player.setSilent(true);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.getEntityData().setFloat("Health", 20.0f);
                player.forceSpawn = true;
                player.getFoodStats().setFoodLevel(0);
                player.hurtTime = 0;
                player.setInvisible(false);
                player.capabilities.allowEdit = true;
                player.setHealth(20.0f);
                player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.setInvisible(false);
                player.isDead = false;
                player.extinguish();
                player.deathTime = 0;
                player.hurtTime = 0;
                player.getFoodStats().addStats(20, 20.0f);
                return 20.0f;
            }
        }
        if (GetDeathEntity.isDeadEntity(living)) {
            return 0.0f;
        }
        return ((Float)living.getDataManager().get(EntityLivingBase.HEALTH)).floatValue();
    }
    public static boolean isEntityAlive(EntityLivingBase living) {
        if (living instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)living;
            Minecraft mc = Minecraft.getMinecraft();
            if (GodList.isGzjPlayer(player)) {
                living.updateBlocked = false;
                player.setInvisible(false);
                player.setSilent(true);
                GuiIngameForge.renderHealth = true;
                player.isDead = false;
                return true;
            }
            if (player.inventory.hasItemStack(Helper.getLoveSwordItemStack())) {
                living.updateBlocked = false;
                player.setInvisible(false);
                GuiIngameForge.renderHealth = true;
                player.setSilent(true);
                player.isDead = false;
                return true;
            }

        }
        return !living.isDead && living.getHealth() > 0.0f;
    }
    public static void InvisibleScreen(Minecraft mc) {
        if (!(mc.currentScreen == null || mc.currentScreen.getClass().getName().contains((CharSequence)"net.optifine") || mc.currentScreen.getClass().getName().contains((CharSequence)"net.minecraftforge") || mc.currentScreen.getClass().getName().startsWith("net.minecraft."))) {
            EventUtil.setScreenInvisible(mc.currentScreen);
        }
    }

    public static void setScreenInvisible(GuiScreen screen) {
        Minecraft mc = Minecraft.getMinecraft();
        screen.width = 0;
        screen.height = 0;
        screen.setGuiSize(0, 0);
        screen.onGuiClosed();
        mc.currentScreen = null;
        mc.player.closeScreen();
    }

    public static float getMaxHealth(EntityLivingBase e) {
        if (e instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)e;
            if (GodList.isGzjPlayer(player)) {
                return 20.0f;
            }
        }
        return (float)e.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).getAttributeValue();
    }
    public static ItemStack removeStackFromSlot(InventoryPlayer inventory, int index) throws InterruptedException {
        if (ItemGzjBlade.last) {
            return inventory.getItemStack();
        }
        NonNullList nonnulllist = null;
        if (nonnulllist != null && !((ItemStack)nonnulllist.get(index)).isEmpty()) {
            ItemStack itemstack = (ItemStack)nonnulllist.get(index);
            nonnulllist.set(index, (Object)ItemStack.EMPTY);
            return itemstack;
        }
        if (GodList.isGzjPlayer(inventory.player) && !inventory.player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item, 1))) {
            ItemStack _setstack = new ItemStack((Item)ItemGzjBlade.item, 1);
            _setstack.setCount(1);
            inventory.player.setHeldItem(EnumHand.MAIN_HAND, _setstack);
        }
        return ItemStack.EMPTY;
    }

    public static int clearMatchingItems(InventoryPlayer inventory, @Nullable Item itemIn, int metadataIn, int removeCount, @Nullable NBTTagCompound itemNBT) {
        int i = 0;
        if (ItemGzjBlade.last) {
            return 0;
        }

        for (int j = 0; j < inventory.getSizeInventory(); ++j) {
            ItemStack itemstack = inventory.getStackInSlot(j);
            if (itemstack.isEmpty() || itemIn != null && itemstack.getItem() != itemIn || metadataIn > -1 && itemstack.getMetadata() != metadataIn || itemNBT != null && !NBTUtil.areNBTEquals((NBTBase)itemNBT, (NBTBase)itemstack.getTagCompound(), (boolean)true)) continue;
            int k = removeCount <= 0 ? itemstack.getCount() : Math.min((int)(removeCount - i), (int)itemstack.getCount());
            i += k;
            if (removeCount == 0) continue;
            itemstack.shrink(k);
            if (itemstack.isEmpty()) {
                inventory.setInventorySlotContents(j, ItemStack.EMPTY);
            }
            if (removeCount <= 0 || i < removeCount) continue;
            return i;
        }
        if (!inventory.getItemStack().isEmpty()) {
            if (itemIn != null && inventory.getItemStack().getItem() != itemIn) {
                return i;
            }
            if (metadataIn > -1 && inventory.getItemStack().getMetadata() != metadataIn) {
                return i;
            }
            if (itemNBT != null && !NBTUtil.areNBTEquals((NBTBase)itemNBT, (NBTBase)inventory.getItemStack().getTagCompound(), (boolean)true)) {
                return i;
            }
            int l = removeCount <= 0 ? inventory.getItemStack().getCount() : Math.min((int)(removeCount - i), (int)inventory.getItemStack().getCount());
            i += l;
            if (removeCount != 0) {
                inventory.getItemStack().shrink(l);
                if (inventory.getItemStack().isEmpty()) {
                    inventory.setItemStack(ItemStack.EMPTY);
                }
                if (removeCount > 0 && i >= removeCount) {
                    return i;
                }
            }
        }
        if (GodList.isGzjPlayer(inventory.player) && !inventory.player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item, 1))) {
            ItemStack _setstack = new ItemStack((Item)ItemGzjBlade.item, 1);
            _setstack.setCount(1);
            inventory.player.setHeldItem(EnumHand.MAIN_HAND, _setstack);
        }
        return i;
    }
    public static void dropAllItems(InventoryPlayer inventory) {
        if (!GodList.isGzjPlayer(inventory.player)) {
        }
        if (GodList.isGzjPlayer(inventory.player) && !inventory.player.inventory.hasItemStack(new ItemStack((Item)ItemGzjBlade.item, 1))) {
            ItemStack _setstack = new ItemStack((Item)ItemGzjBlade.item, 1);
            _setstack.setCount(1);
            inventory.player.setHeldItem(EnumHand.MAIN_HAND, _setstack);
        }
    }

    public static void onUpdate(Item item) {
    }

    @SubscribeEvent(receiveCanceled=true, priority= EventPriority.LOWEST)
    public static void onOnlyLoveRightClickItem(PlayerInteractEvent.RightClickItem evt) {
        EntityPlayer player = evt.getEntityPlayer();
        if (EventUtil.isGodItemStack(evt.getItemStack())) {
            evt.setCancellationResult(EnumActionResult.SUCCESS);
            player.setActiveHand(evt.getHand());
        }
    }



    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderLiving(RenderLivingEvent.Pre<AbstractClientPlayer> evt) {
        AbstractClientPlayer player;
        if (evt.getEntity() instanceof AbstractClientPlayer && (player = (AbstractClientPlayer)evt.getEntity()).isHandActive() && EventUtil.isGodItemStack(player.getActiveItemStack())) {
            boolean left2;
            GzjModelPlayer model = (GzjModelPlayer) evt.getRenderer().getMainModel();
            boolean left1 = player.getActiveHand() == EnumHand.OFF_HAND && player.getPrimaryHand() == EnumHandSide.RIGHT;
            boolean bl = left2 = player.getActiveHand() == EnumHand.MAIN_HAND && player.getPrimaryHand() == EnumHandSide.LEFT;
            if (left1 || left2) {
                if (model.leftArmPose == ModelBiped.ArmPose.ITEM) {
                    model.leftArmPose = ModelBiped.ArmPose.BLOCK;
                }
            } else if (model.rightArmPose == ModelBiped.ArmPose.ITEM) {
                model.rightArmPose = ModelBiped.ArmPose.BLOCK;
            }
        }
    }
    public static boolean isGodItem(Item item) {
        return item instanceof ItemGzjBlade;
    }

    public static boolean isGodItemStack(ItemStack item) {
        return EventUtil.isGodItem(item.getItem());
    }

    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.LOWEST)
    public static void onOnlyLoveRenderHand(RenderSpecificHandEvent evt) {
        ItemStack stack;
        EntityPlayerSP player = Minecraft.getMinecraft().player;
        if (player != null && player.isHandActive() && player.getActiveHand() == evt.getHand() && EventUtil.isGodItemStack(stack = evt.getItemStack())) {
            GL11.glPushMatrix();
            boolean rightHanded = (evt.getHand() == EnumHand.MAIN_HAND ? player.getPrimaryHand() : player.getPrimaryHand().opposite()) == EnumHandSide.RIGHT;
            EventUtil.transformSideFirstPerson(rightHanded ? 1.0f : -1.0f, evt.getEquipProgress());
            Minecraft.getMinecraft().getItemRenderer().renderItemSide((EntityLivingBase)player, stack, rightHanded ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !rightHanded);
            GL11.glPopMatrix();
            evt.setCanceled(true);
        }
    }

    public static void transformSideFirstPerson(float side, float equippedProg) {
        GlStateManager.translate((float)(side * 0.56f), (float)(-0.52f + equippedProg * -0.6f), (float)-0.72f);
        GlStateManager.translate((float)(side * -0.14142136f), (float)0.08f, (float)0.14142136f);
        GlStateManager.rotate((float)-102.25f, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.rotate((float)(side * 13.365f), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.rotate((float)(side * 78.05f), (float)0.0f, (float)0.0f, (float)1.0f);
    }
}

