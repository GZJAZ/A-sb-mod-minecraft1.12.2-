package com.example.examplemod.core.interfaces;

import net.minecraft.entity.Entity;

public interface IMixinWorld {
    public void fastRemove(Entity e);
}
