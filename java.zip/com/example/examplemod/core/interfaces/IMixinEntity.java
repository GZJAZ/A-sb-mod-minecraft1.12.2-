package com.example.examplemod.core.interfaces;

public interface IMixinEntity {
    public int getDeathTime();

    public void setDeathTime(int time);

    public boolean isUltimateDead();

    public void setUltimateDead();
}
