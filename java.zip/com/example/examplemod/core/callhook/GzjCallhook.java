/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.Map
 *  net.minecraftforge.fml.relauncher.IFMLCallHook
 */
package com.example.examplemod.core.callhook;

import java.util.Map;
import net.minecraftforge.fml.relauncher.IFMLCallHook;

public class GzjCallhook
implements IFMLCallHook {
    public Void call() throws Exception {
        return null;
    }

    public void injectData(Map<String, Object> data) {
    }
}

