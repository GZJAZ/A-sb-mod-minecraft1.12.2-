/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  net.minecraft.launchwrapper.IClassTransformer
 */
package com.example.examplemod.core;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InnerClassNode;
import org.objectweb.asm.tree.MethodNode;

import java.util.ArrayList;
import java.util.List;

public class GzjAccessTransformer
implements IClassTransformer {
    private Multimap<String, Modifier> modifiers = ArrayListMultimap.create();

    public GzjAccessTransformer() {
        Modifier m = new Modifier();
        m.modifyClassVisibility = true;
        m.changeFinal = true;
        m.targetAccess = 1;
        this.modifiers.put("net.minecraft.item.ItemStack", m);
        Modifier mm = new Modifier();
        mm.changeFinal = true;
        mm.targetAccess = 1;
        mm.name = "EVENT_BUS";
        this.modifiers.put("net.minecraftforge.common.MinecraftForge", mm);
        Modifier mmm = new Modifier();
        mmm.targetAccess = 1;
        mmm.name = "*";
        this.modifiers.put("net.minecraft.client.Minecraft", mmm);
        Modifier mmmm = new Modifier();
        mmmm.targetAccess = 1;
        mmmm.changeFinal = true;
        mmmm.name = "getHealth";
        mmmm.desc = "()F";
        Modifier mmmmm = new Modifier();
        mmmmm.targetAccess = 1;
        mmmmm.changeFinal = true;
        mmmmm.name = "getMaxHealth";
        mmmmm.desc = "()F";
        this.modifiers.put("net.minecraft.entity.EntityLivingBase", mmmm);
        this.modifiers.put("net.minecraft.entity.EntityLivingBase", mmmmm);
    }

    public byte[] transform(String name, String transformedName, byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        if (!this.modifiers.containsKey(transformedName)) {
            return bytes;
        }
        System.err.println(transformedName);
        ClassNode classNode = new ClassNode();
        ClassReader classReader = new ClassReader(bytes);
        classReader.accept(classNode, 0);
        for (Modifier m : this.modifiers.get(transformedName)) {
            for (InnerClassNode innerClass : classNode.innerClasses) {
                if (!m.modifyClassVisibility) continue;
                classNode.access = this.getFixedAccess(classNode.access, m);
                if (!innerClass.name.equals((Object)classNode.name)) continue;
                innerClass.access = this.getFixedAccess(innerClass.access, m);
                break;
            }
            if (m.desc.isEmpty()) {
                for (Object n : classNode.fields) {
                }
                continue;
            }
            ArrayList nowOverrideable = Lists.newArrayList();
            for (MethodNode n : classNode.methods) {
                if ((!n.name.equals((Object)m.name) || !n.desc.equals((Object)m.desc)) && !m.name.equals((Object)"*")) continue;
                n.access = this.getFixedAccess(n.access, m);
                System.err.println(n.name + n.desc);
                if (!n.name.equals((Object)"<init>")) {
                    boolean isNowPrivate;
                    boolean wasPrivate = (m.oldAccess & 2) == 2;
                    boolean bl = isNowPrivate = (m.newAccess & 2) == 2;
                    if (wasPrivate && !isNowPrivate) {
                        nowOverrideable.add((Object)n);
                    }
                }
                if (m.name.equals((Object)"*")) continue;
                break;
            }
            if (nowOverrideable.isEmpty()) continue;
            this.replaceInvokeSpecial(classNode, (List<MethodNode>)nowOverrideable);
        }
        ClassWriter writer = new ClassWriter(1);
        classNode.accept(writer);
        return writer.toByteArray();
    }

    private void replaceInvokeSpecial(ClassNode clazz, List<MethodNode> toReplace) {
        for (MethodNode method : clazz.methods) {
        }
    }

    private int getFixedAccess(int access, Modifier target) {
        target.oldAccess = access;
        int t = target.targetAccess;
        int ret = access & -8;
        switch (access & 7) {
            case 2: {
                ret |= t;
                break;
            }
            case 0: {
                ret |= t != 2 ? t : 0;
                break;
            }
            case 4: {
                ret |= t != 2 && t != 0 ? t : 4;
                break;
            }
            case 1: {
                ret |= t != 2 && t != 0 && t != 4 ? t : 1;
                break;
            }
            default: {
                throw new RuntimeException("The fuck?");
            }
        }
        if (target.changeFinal) {
            ret = target.markFinal ? (ret |= 16) : (ret &= -17);
        }
        target.newAccess = ret;
        return ret;
    }

    class Modifier {
        public String name = "";
        public String desc = "";
        public int oldAccess = 0;
        public int newAccess = 0;
        public int targetAccess = 0;
        public boolean changeFinal = false;
        public boolean markFinal = false;
        protected boolean modifyClassVisibility;

        Modifier() {
        }
    }

}

