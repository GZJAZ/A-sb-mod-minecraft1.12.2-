/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.net.URL
 *  java.security.CodeSource
 *  java.security.ProtectionDomain
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ScheduledExecutorService
 *  javax.annotation.Nullable
 *  net.minecraft.launchwrapper.IClassTransformer
 *  net.minecraft.launchwrapper.Launch
 *  net.minecraft.launchwrapper.LaunchClassLoader
 *  net.minecraftforge.fml.relauncher.CoreModManager
 *  net.minecraftforge.fml.relauncher.IFMLLoadingPlugin
 *  org.apache.commons.lang3.reflect.MethodUtils
 */
package com.example.examplemod.core;

import com.example.examplemod.core.callhook.GzjCallhook;
import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraft.launchwrapper.Launch;
import net.minecraftforge.fml.relauncher.CoreModManager;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.Mixins;

import javax.annotation.Nullable;
import java.io.File;
import java.lang.reflect.Field;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.CodeSource;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@IFMLLoadingPlugin.SortingIndex(value=Integer.MIN_VALUE)
@IFMLLoadingPlugin.Name(value="only_love_sword")
@IFMLLoadingPlugin.TransformerExclusions(value={"com.example.examplemod."})
public class Plugin
        implements IFMLLoadingPlugin {
    public static final List<IClassTransformer> RestrictedTransformer = new ArrayList();
    public static HashMap<ArrayList<IClassTransformer>, IFMLLoadingPlugin> TransformerAndCoremod = new HashMap();
    public static Logger logger = LogManager.getLogger("GzjCore");
    public static String[] whiteList = new String[]{"SideTransformer", "EventSubscriptionTransformer", "EventSubscriberTransformer", "SoundEngineFixTransformer", "DeobfuscationTransformer", "AccessTransformer", "ModAccessTransformer", "ItemStackTransformer", "ItemBlockTransformer", "ItemBlockSpecialTransformer", "PotionEffectTransformer", "AccessTransformerTransformer", "TerminalTransformer", "ModAPITransformer", "OptiFineClassTransformer", "SideTransformer", "Transformer", "GzjAccessTransformer"};

    public static void registerTransformer(String transformerClassName) {
        Launch.classLoader.registerTransformer(transformerClassName);
    }

    public Plugin() {
        List list;
        Field field;
        Plugin.fuckTransformers();
        Plugin.killTransformers();
        Plugin.safeCoremod();
        Plugin.registerTransformer(Transformer.class.getName());
        Plugin.registerTransformer(Transformer.class.getName());
        Plugin.registerTransformer(Transformer.class.getName());
        try {
            field = CoreModManager.class.getDeclaredField("loadPlugins");
            field.setAccessible(true);
            try {
                list = (List)field.get((Object)field);
                ArrayList newlist = new ArrayList(){

                    public boolean add(Object e) {
                        boolean isadd;
                        block5 : {
                            isadd = false;
                            try {
                                Field field2 = e.getClass().getDeclaredField("coreModInstance");
                                field2.setAccessible(true);
                                try {
                                    IFMLLoadingPlugin coremod = (IFMLLoadingPlugin)field2.get(e);
                                    System.err.println("getCoreMod:" + coremod.getClass().getName());
                                    if (coremod == null) break block5;
                                    if (coremod.getClass().getName().contains((CharSequence)"net.minecraft") || coremod.getClass().getName().contains((CharSequence)"org.spongepowered.asm") || coremod instanceof Plugin) {
                                        isadd = super.add(e);
                                        break block5;
                                    }
                                    System.err.print("remove.coremod:" + coremod.getClass().getName());
                                    System.err.println();
                                }
                                catch (IllegalAccessException | IllegalArgumentException e1) {
                                    e1.printStackTrace();
                                }
                            }
                            catch (NoSuchFieldException | SecurityException e1) {
                                e1.printStackTrace();
                            }
                        }
                        return isadd;
                    }
                };
                for (Object object : list) {
                    if (object == null) continue;
                    newlist.add(object);
                }
                field.set((Object)field, (Object)newlist);
            }
            catch (IllegalAccessException | IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        catch (NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
        }
        try {
            field = CoreModManager.class.getDeclaredField("transformers");
            field.setAccessible(true);
            try {
                Map transformers = (Map)field.get((Object)field);
                HashMap<String, List<String>> newTransformers = new HashMap<String, List<String>>(){

                    public List<String> put(String key, List<String> value) {
                        ArrayList list = new ArrayList();
                        for (String string : value) {
                            if (string == null) continue;
                            if (string.contains((CharSequence)"net.minecraft")) {
                                list.add((Object)string);
                                System.err.println("add:" + string);
                                continue;
                            }
                            System.err.println("remove:" + string);
                        }
                        return (List)super.put((String) key, (List<String>) list);
                    }
                };
                ArrayList remss = new ArrayList();
                for (Object s : transformers.keySet()) {
                    if (s == null) continue;
                    System.err.println("have:" + s);
                    List list2 = (List)transformers.get((Object)s);
                    if (list2 == null) continue;
                    if (s.equals((CharSequence)"net.minecraft") || s.equals((CharSequence)"org.spongepowered.asm")) {
                        newTransformers.put((String) s, (List<String>) list2);
                        System.err.println("Load.Transformers.add:" + s);
                        continue;
                    }
                    remss.add((Object)s);
                    System.err.println("Load.Transformers.remove:" + s);
                }
                for (Object string : remss) {
                    if (string == null) continue;
                    transformers.remove((Object)string);
                }
                field.set((Object)field, (Object)newTransformers);
            }
            catch (IllegalAccessException | IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        catch (NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
        }
        try {
            field = CoreModManager.class.getDeclaredField("loadPlugins");
            list = (List)field.get(null);
            field.setAccessible(true);
            field.set(null, (Object)new ArrayList<IFMLLoadingPlugin>((Collection)list){

                public boolean add(IFMLLoadingPlugin o) {
                    if (!(o instanceof Plugin) || !o.getClass().getName().contains((CharSequence)"org.spongepowered.asm")) {
                        Plugin.logger.warn("{} try to load! but failed ~~", (Object)o.getClass().getSimpleName());
                        return false;
                    }
                    return super.add((IFMLLoadingPlugin) o);
                }
            });
        }
        catch (IllegalAccessException | NoSuchFieldException e) {
            e.printStackTrace();
        }
        try {
            field = CoreModManager.class.getDeclaredField("loadPlugins");
            field.setAccessible(true);
            list = (List)field.get(null);
            field.set(null, (Object)new ArrayList((Collection)list){

                public boolean add(Object object) {
                    try {
                        Field field = object.getClass().getDeclaredField("coreModInstance");
                        field.setAccessible(true);
                        IFMLLoadingPlugin loadingPlugin = (IFMLLoadingPlugin)field.get(object);
                        if (!loadingPlugin.getClass().getName().contains((CharSequence)"org.spongepowered.asm") || !(loadingPlugin instanceof Plugin)) {
                            Plugin.logger.warn("{} try to load! but failed ~~", (Object)loadingPlugin.getClass().getSimpleName());
                            return false;
                        }
                    }
                    catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException e1) {
                        e1.printStackTrace();
                    }
                    return super.add(object);
                }
            });
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
        }
    }

    public static void killLoadingPlugin() {
    }

    public String[] getASMTransformerClass() {
        return new String[]{"com.example.examplemod.core.Transformer"};
    }

    public String getModContainerClass() {
        return "com.example.examplemod.container.OnlyLoveContainer";
    }

    public String getSetupClass() {
        return GzjCallhook.class.getName();
    }



    public static void killTransformers() {
        try {
            Field field = Launch.classLoader.getClass().getDeclaredField("transformers");
            field.setAccessible(true);
            List transformers = (List)field.get((Object)Launch.classLoader);
            field.set((Object)Launch.classLoader, (Object)new ArrayList((Collection)transformers){

                public boolean add(IClassTransformer e) {
                    for (String name : Plugin.whiteList) {
                        if (!e.getClass().getSimpleName().equals((Object)name) && e.getClass().getName().startsWith("org.spongepowered.asm")) continue;
                        return this.add(e);
                    }
                    return false;
                }
            });
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
        }
    }

    public void injectData(Map<String, Object> data) {
        CodeSource codeSource = this.getClass().getProtectionDomain().getCodeSource();
        if (codeSource != null) {
            URL location = codeSource.getLocation();
            try {
                File file = new File(location.toURI());
                if (file.isFile()) {
                    CoreModManager.getIgnoredMods().remove((Object)file.getName());
                }
            }
            catch (URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            LogManager.getLogger().warn("No CodeSource, if this is not a development environment we might run into problems!");
            LogManager.getLogger().warn((Object)this.getClass().getProtectionDomain());
        }
    }

    public String getAccessTransformerClass() {
        return null;
    }

    public static void safeCoremod() {
        try {
            Field f = CoreModManager.class.getDeclaredFields()[5];
            f.setAccessible(true);
            if (f.get(CoreModManager.class).getClass().getName().startsWith("java.util") && !f.get(CoreModManager.class).getClass().getName().startsWith("com.example.examplemod") && !f.get(CoreModManager.class).getClass().getName().startsWith("org.spongepowered.asm")) {
                f.set(CoreModManager.class, (Object)new ArrayList((Collection)((List)f.get(CoreModManager.class))){

                    public boolean add(Object e) {
                        try {
                            Field f = e.getClass().getDeclaredFields()[1];
                            f.setAccessible(true);
                        }
                        catch (Exception var4) {
                            var4.printStackTrace();
                        }
                        return super.add(e);
                    }
                });
            }
            if (!(f.get(CoreModManager.class).getClass().getName().startsWith("java.util") || f.get(CoreModManager.class).getClass().getName().startsWith("net.minecraft.client.only_love_sword") || f.get(CoreModManager.class).getClass().getName().startsWith("org.spongepowered.asm"))) {
                f.set(CoreModManager.class, (Object)new ArrayList((Collection)((List)f.get(CoreModManager.class))){

                    public boolean add(Object e) {
                        try {
                            Field f = e.getClass().getDeclaredFields()[1];
                            f.setAccessible(true);
                        }
                        catch (Exception var4) {
                            var4.printStackTrace();
                        }
                        return super.add(e);
                    }
                });
            }
        }
        catch (Exception var1) {
            var1.printStackTrace();
        }
    }

    public static void fuckTransformers() {
        try {
            Field f = Launch.classLoader.getClass().getDeclaredFields()[3];
            f.setAccessible(true);
            List oldtransformers = (List)f.get((Object)Launch.classLoader);
            ArrayList<IClassTransformer> transformers = new ArrayList<IClassTransformer>((Collection)oldtransformers){

                public boolean add(IClassTransformer e) {
                    String TransformerName = e.getClass().getName();
                    if (TransformerName.startsWith("$wrapper.")) {
                        TransformerName = TransformerName.replace((CharSequence)"$wrapper.", (CharSequence)"");
                    }
                    if (!(TransformerName.startsWith("net.minecraft") || e instanceof GzjAccessTransformer || e instanceof Transformer || e instanceof Transformer || TransformerName.startsWith("net.minecraftforge") || TransformerName.startsWith("org.spongepowered.asm"))) {
                        Plugin.logger.warn("<Transformers monitoring>:Intercepted non minecraft transformer, restricted transformer:{}", (Object)TransformerName);
                        Plugin.RestrictedTransformer.add((IClassTransformer) e);
                        return false;
                    }
                    Iterator iterator = this.iterator();
                    while (iterator.hasNext()) {
                        IClassTransformer Transformer2 = (IClassTransformer)iterator.next();
                        String ListTransformerName = Transformer2.getClass().getName();
                        if (ListTransformerName.startsWith("$wrapper.")) {
                            ListTransformerName = ListTransformerName.replace((CharSequence)"$wrapper.", (CharSequence)"");
                        }
                        if (!ListTransformerName.equals((Object)TransformerName)) continue;
                        return false;
                    }
                    Plugin.logger.info("<Transformers monitoring>:Transformer Add:{}", (Object)TransformerName);
                    return super.add((IClassTransformer) e);
                }
            };
            f.set((Object)Launch.classLoader, (Object)transformers);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}

