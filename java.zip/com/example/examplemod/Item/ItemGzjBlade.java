package com.example.examplemod.Item;


import com.chaoswither.chaoswither;
import com.chaoswither.core.ChaosTransformer;
import com.chaoswither.entity.EntityChaosLightningBolt;
import com.chaoswither.entity.EntityChaosWither;
import com.chaoswither.entity.EntityLongHit;
import com.chaoswither.entity.EntityTool;
import com.chaoswither.event.DetermineEvent;
import com.chaoswither.gui.GuiDead;
import com.chaoswither.gui.GuiDead1;
import com.chaoswither.gui.GuiDead12;
import com.example.examplemod.GzjMod;
import com.example.examplemod.SpecialAttack.GzjSa;
import com.example.examplemod.core.EventUtil;
import com.example.examplemod.dszjhgvfshudjgfuya.GzjBladeEventBus;
import com.example.examplemod.dszjhgvfshudjgfuya.GzjGuiIngameForge;
import com.example.examplemod.entity.ColorEntityLightningBolt;
import com.example.examplemod.tabbbbbbbbbbbbbbbbbbbbbbbbbbbbb.gzjtabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb;
import com.example.examplemod.thread.MainThread;
import com.example.examplemod.util.*;
import com.example.examplemod.util.classutil.ClassUtil;
import com.google.common.collect.Multimap;
import mods.flammpfeil.slashblade.ItemSlashBladeNamed;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.specialattack.SpecialAttackBase;
import mods.flammpfeil.slashblade.util.ResourceLocationRaw;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static com.chaoswither.command.ConfigCommand.happymode;
import static net.minecraftforge.common.MinecraftForge.EVENT_BUS;

public class ItemGzjBlade
extends ItemSlashBladeNamed {
    public static ItemGzjBlade item;
    public static boolean sb;
    public static String slashbladeName;
    public static final Item block = null;
    public static boolean time =false;
    public static boolean nmsl =false;
    public static boolean last;
    public static List<Class<?>> t;
    public static List<Class<?>> f;
    public static Map<Field, Object> map;
    public static final Set<EntityLivingBase> death = new HashSet();
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    public static boolean IShsv= false;
    public static float hsv = 0.3f;
    public static boolean isgod = false;
    public static final Set<Entity> god = new HashSet();
    public ItemGzjBlade() {
        super(ToolMaterial.WOOD, Float.POSITIVE_INFINITY);
        item = this;
        this.setRegistryName("gzjmod", slashbladeName);
        EVENT_BUS.register((Object)this);
        item.setCreativeTab((CreativeTabs) GzjMod.tab);
    }
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (nmsl) {
            if (event.getGui() != null && event.getGui() instanceof GuiDead) {
                event.setCanceled(true);
            }
            if (event.getGui() != null && event.getGui() instanceof GuiDead1) {
                event.setCanceled(true);
            }
            if (event.getGui() != null && event.getGui() instanceof GuiDead12) {
                event.setCanceled(true);
            }
        }
    }
    public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (this.isInCreativeTab(tab)) {
            items.add((ItemStack) new ItemStack((Item)this));
        }
    }



    @SubscribeEvent
                   public void evt(RenderTooltipEvent.Color evt) {
                        if (evt.getStack().getItem() == ItemGzjBlade.item) {
                            evt.setBackground(0);
                        }

                }
    private float milliTime() {
        return 0;
    }

    public static boolean qwq(Class<?> c) {
        try {
            if (c.getProtectionDomain().getCodeSource() == null) {
                return false;
            }
            return isModClass(c.getProtectionDomain().getCodeSource().getLocation());
        }
        catch (Exception ex) {
            return false;
        }
    }
    public static boolean azz(Class<?> c) {
        try {
            if (c.getProtectionDomain().getCodeSource() == null) {
                return false;
            }
            return isModClass(c.getProtectionDomain().getCodeSource().getLocation());
        }
        catch (Exception ex) {
            return false;
        }
    }

    public static boolean isModClass(URL url) {
        String s = url.getFile();
        if (s.contains((CharSequence)"!")) {
            s = s.substring(0, s.lastIndexOf("!"));
        }
        if (s.contains((CharSequence)"file:")) {
            s = s.substring(6);
        }
        File f = new File(s).getParentFile();
        return f.getName().equals((Object)"mods");
    }


    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap multimap = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(), new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Item modifier", Double.POSITIVE_INFINITY, 0));
            multimap.put(SharedMonsterAttributes.ATTACK_SPEED.getName(), new AttributeModifier(ATTACK_SPEED_MODIFIER, "Item modifier", -2.4, 0));
        }
        return multimap;
    }

    @SubscribeEvent
    public static void onItemTooltip(ItemTooltipEvent event) {
        if (event.getItemStack().getItem() instanceof ItemGzjBlade) {
            List tooltip = event.getToolTip();
            int size = tooltip.size();
            String attackDamage = "\u653b\u51fb\u4f24\u5bb3";
            String attackSpeed = "\u653b\u51fb\u901f\u5ea6";
            for (int i = 0; i < size; ++i) {
                String line = (String)tooltip.get(i);
                if (line.contains((CharSequence)attackDamage)) {
                    continue;
                }
                if (!line.contains((CharSequence)attackSpeed)) continue;
            }
        }
    }

    @SubscribeEvent
    public void onPlayerTickEvent(TickEvent.PlayerTickEvent event) {
        if (ItemStackOnUpdate.isGod((Object)event)) {
            ItemStackOnUpdate.safePlayer(event.player);
            ItemStackOnUpdate.get((Entity)event.player);
            ItemStackOnUpdate.get((Entity)event.player);
        }
    }

    @SubscribeEvent
    public void OnLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (ItemStackOnUpdate.isGod((Object)event.getEntity())) {
            ItemStackOnUpdate.safePlayer((EntityPlayer)event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
        }
    }

    @SubscribeEvent
    public void OnLivingDeath(LivingDeathEvent event) {
        if (ItemStackOnUpdate.isGod((Object)event.getEntity())) {
            ItemStackOnUpdate.safePlayer((EntityPlayer)event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
        }
    }

    @SubscribeEvent
    public void OnLivingAttack(LivingAttackEvent event) {
        if (ItemStackOnUpdate.isGod((Object)event.getEntity())) {
            ItemStackOnUpdate.safePlayer((EntityPlayer)event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
            ItemStackOnUpdate.get(event.getEntity());
        }
    }

    public FontRenderer getFontRenderer(ItemStack stack) {
        return FontBad.getFont();
    }

    public String getItemStackDisplayName(ItemStack stack) {
        return ("\u672A\u77E5\u306E\u62D4\u5200\u5251");
    }

    public String getToolMaterialName() {
        return ("\u672A\u77E5\u306E\u62D4\u5200\u5251");
    }



    public ResourceLocationRaw getModel() {
        return new ResourceLocationRaw("flammpfeil.slashblade", "model/godblade.obj");
    }
    public ResourceLocationRaw getModelTexture() {
        return new ResourceLocationRaw("flammpfeil.slashblade", "model/godblade3.png");
    }
    public class PlayerDeathEventHandler {

        @SubscribeEvent
        public void onPlayerDeath(PlayerEvent.Clone event) {
            EntityPlayer player = event.getEntityPlayer();
            if (player != null && player.getHeldItemMainhand().getItem() instanceof ItemGzjBlade) {
                Minecraft.getMinecraft().ingameGUI.setOverlayMessage(new TextComponentString(""), false);
            }
        }
    }


    public int getMaxDamage(ItemStack stack) {
        return 0;
    }


    public int getDamage(ItemStack stack) {
        return 0;
    }

    public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase) {
        par2EntityLivingBase.isDead = true;
        ItemGzjBlade.death.add((EntityLivingBase) par2EntityLivingBase);
        par2EntityLivingBase.world.removeEntity((Entity)par2EntityLivingBase);
        return true;
    }
    private static final Minecraft mc;
    public void onUpdate(ItemStack sitem, World par2World, Entity par3Entity, int indexOfMainSlot, boolean isCurrent) {
        sb = true;
        nmsl = true;
        EntityPlayer player = (EntityPlayer) par3Entity;
        String name = player.getName();
        if (!sitem.isItemEnchanted()) {
            sitem.addEnchantment(Enchantments.FIRE_ASPECT, 10);
            sitem.addEnchantment(Enchantments.BINDING_CURSE, 10);
        }
        if (par3Entity instanceof EntityPlayer) {
            player = (EntityPlayer) par3Entity;
            ItemStackOnUpdate.hasitem.add((String) player.getName());
            ItemStackOnUpdate.Jingui();
        }
        if (par3Entity instanceof EntityPlayer) {
            if (player.posY <= -15) {
                player.motionY += 10;
            }
        }
        try {
            FieldUtils.writeDeclaredField(MinecraftForge.EVENT_BUS, "shutdown", Boolean.valueOf(false), true);
        } catch (Throwable th) {}
        super.onUpdate(sitem, par2World, par3Entity, indexOfMainSlot, isCurrent);
    }
    @SideOnly(Side.CLIENT)
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onRenderLiving(RenderPlayerEvent.Pre e){
        e.setCanceled(false);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void LivingUpdate(LivingEvent.LivingUpdateEvent e){
        e.setCanceled(true);
    }
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRederTickEnd(TickEvent.RenderTickEvent e){
        GuiGameOver gui = new GuiGameOver(null);
        gui.drawScreen(0,0,0);
    }

    public boolean hasEffect(ItemStack stack) {
        return true;
    }
    public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
        KillEntity.killEntity(entity);
        return super.onLeftClickEntity(stack, player, entity);
    }
    public SpecialAttackBase getSpecialAttack(ItemStack stack) {
        return new GzjSa();
    }


    public static boolean KillRender = false;
    public boolean onDroppedByPlayer(ItemStack item, EntityPlayer player) {
        return false;
    }
    public void onPlayerStoppedUsing(ItemStack itemstack, World world, EntityLivingBase entityLivingBase, int timeLeft) {
        time = false;
        ItemGzjBlade.KillRender = true;
        ItemGzjBlade.death.add((EntityLivingBase) entityLivingBase);
        Minecraft mc = Minecraft.getMinecraft();
        mc.entityRenderer.stopUseShader();
        int x = (int)entityLivingBase.posX;
        int y = (int)entityLivingBase.posY;
        int z = (int)entityLivingBase.posZ;
        for (int index0 = 0; index0 < (int) (200); index0++) {
            world.addWeatherEffect(new ColorEntityLightningBolt(world, (int) Math.round(((x - 10) + (Math.random() * ((x + 10) - (x - 10))))),
                    (int) y, (int) Math.round(((z - 10) + (Math.random() * ((z + 10) - (z - 10))))), true));
        }
    }


    public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
        World world = entityLiving.getEntityWorld();
        ArrayList entities = new ArrayList();
        List<Entity> list1 = entityLiving.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(entityLiving.posX + 12.0, entityLiving.posY + 12.0, entityLiving.posZ + 12.0, entityLiving.posX - 12.0, entityLiving.posY - 12.0, entityLiving.posZ - 12.0));
        for (Entity entity : list1) {
            if (ItemStackOnUpdate.isGod(entity)) continue;
            Kill2.NewKillEntity(entity);
            Kill2.setDead(entity);
            double x = 0;
            double z = 0;
            world.addWeatherEffect((Entity)((Object)new ColorEntityLightningBolt(world, x, world.getHeight((int)x, (int)z), z, true)));
        }
        entities.addAll(world.loadedEntityList);
        entities.addAll(world.weatherEffects);
        entities.addAll(world.playerEntities);
        for (Entity entity : list1) {
            if (ItemStackOnUpdate.isGod(entity)) continue;
            Kill2.NewKillEntity(entity);
            Kill2.setDead(entity);
        }
        return super.onEntitySwing(entityLiving, stack);
    }
    public boolean showDurabilityBar(ItemStack stack) {
        return true;
    }

    public double getDurabilityForDisplay(ItemStack stack) {
        return 0.0;
    }

    public int getRGBDurabilityForDisplay(ItemStack stack) {
        return MathHelper.hsvToRGB((float)((float) Helper.getSystemTime() / 700.0f % 1.0f), (float)1.0f, (float)1.0f);
    }
    @SubscribeEvent
    public void renderTool(RenderTooltipEvent.Pre event) {
        if (event.getStack().getItem() instanceof ItemGzjBlade) {
            renderCenteredFullScreen();
        }
    }
    public static boolean font = true;
    public static boolean font2 = false;
    public static boolean font3 = false;
    public static boolean font4 = false;
    public static boolean font5 = false;
    public static boolean font6 = false;
    public static boolean font7 = false;
    public static boolean font8 = false;

    public static void renderCenteredFullScreen() {
        Minecraft mc = Minecraft.getMinecraft();
        GL11.glPushMatrix();
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if(font) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/1.png"));
        }
        if (font2) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/2.png"));
        }
        if (font3) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/3.png"));
        }
        if (font4) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/4.png"));
        }
        if (font5) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/5.png"));
        }
        if (font6) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/6.png"));
        }
        if (font7) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/7.png"));
        }
        if (font8) {
            mc.getTextureManager().bindTexture(new ResourceLocation("gzjmod", "textures/8.png"));
        }
        int screenWidth = scaledResolution.getScaledWidth();
        int screenHeight = scaledResolution.getScaledHeight();
        int imageWidth = 490;
        int imageHeight = 270;
        double scaleX = (double) screenWidth / imageWidth;
        double scaleY = (double) screenHeight / imageHeight;
        double scale = Math.max(scaleX, scaleY);
        int scaledImageWidth = (int) (imageWidth * scale);
        int scaledImageHeight = (int) (imageHeight * scale);
        int offsetX = (screenWidth - scaledImageWidth) / 2;
        int offsetY = (screenHeight - scaledImageHeight) / 2;
        Gui.drawModalRectWithCustomSizedTexture(offsetX, offsetY,
                0, 0,
                scaledImageWidth, scaledImageHeight, imageWidth, imageHeight);
        GL11.glPopMatrix();
        if(font) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font = false;
                font2 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font2) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font2 = false;
                font3 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font3) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font3 = false;
                font4 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font4) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font4 = false;
                font5 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font5) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font5 = false;
                font6 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font6) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font6 = false;
                font7 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font7) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font7 = false;
                font8 = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
        if (font8) {
            Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                font8 = false;
                font = true;
            }, 1200, TimeUnit.MILLISECONDS);
        }
    }

    public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand hand) {
        World world = playerIn.getEntityWorld();
        scheduler.schedule(()->time = true, 1, TimeUnit.SECONDS);
        playerIn.setActiveHand(hand);
        ArrayList entities = new ArrayList();
        List list1 = playerIn.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(playerIn.posX + 12.0, playerIn.posY + 12.0, playerIn.posZ + 12.0, playerIn.posX - 12.0, playerIn.posY - 12.0, playerIn.posZ - 12.0));
        for (Object entity : list1) {
            if (ItemStackOnUpdate.isGod((Object)entity)) continue;
            Kill2.NewKillEntity((Entity) entity);
            Kill2.setDead((Object)entity);
        }
        entities.addAll((Collection)world.loadedEntityList);
        entities.addAll((Collection)world.weatherEffects);
        entities.addAll((Collection)world.playerEntities);
        for (Object entity : list1) {
            if (ItemStackOnUpdate.isGod((Object)entity)) continue;
            Kill2.NewKillEntity((Entity) entity);
            Kill2.setDead((Object)entity);
        }
                return super.onItemRightClick(worldIn, playerIn, hand);
    }

    @SideOnly(value=Side.CLIENT)
    public void addInformationMaxAttack(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List list, boolean par4) {
        super.addInformationMaxAttack(par1ItemStack, par2EntityPlayer, list, par4);
        NBTTagCompound tag = getItemTagCompound((ItemStack)par1ItemStack);
        RepairCount.get(tag);
        this.getSwordType(par1ItemStack);
        list.add((Object) "up\u505A\u7684\u8FD9\u4E48\u8F9B\u82E6");
        list.add((Object) "\u70B9\u4E2A\u8D5E\u5427");
        list.add((Object) "\u5404\u4F4D");
        list.add((Object) "\u6C42\u6C42\u5566");
        list.add((Object)"qwq");
        list.add((Object)"By tzdgzj");
    }

    public void addInformationSpecialAttack(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
        super.addInformationSpecialAttack(par1ItemStack, par2EntityPlayer, par3List, par4);
        par3List.add((Object)"SA:\u6b21\u5143\u65a9");
    }


    static {
        slashbladeName = "gzjblade";
        mc = Minecraft.getMinecraft();
    }
}

