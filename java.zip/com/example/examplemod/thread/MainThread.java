
package com.example.examplemod.thread;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.examplemod.Item.ItemGzjBlade;
import com.example.examplemod.core.EventUtil;
import com.example.examplemod.util.WorldEntityList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.NetworkManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.FoodStats;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class MainThread
        extends Thread {
    public static int i = 0;
    public static Map<String, InventoryPlayer> allGodInv = new HashMap();

    public MainThread() {
        super(() -> {
            block6 : do {
                try {
                    MainThread.sleep((long)10L);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                MainThread.VV();
                if (EventUtil.IsGod((Entity)Minecraft.getMinecraft().player)) {
                    ItemGzjBlade.item.onUpdate(new ItemStack((Item) ItemGzjBlade.item), (World)Minecraft.getMinecraft().world, (Entity)Minecraft.getMinecraft().player, 0, false);
                }
                try {
                    int i = 0;
                    do {
                        if (i >= EventUtil.playerlist.size()) continue block6;
                        EntityPlayer player = (EntityPlayer)EventUtil.playerlist.get(i);
                        if (player != null) {
                            World world = player.world;
                            WorldInfo info = world.getWorldInfo();
                            PlayerCapabilities cap = player.capabilities;
                            FoodStats food = player.getFoodStats();
                            try {
                                if (allGodInv.containsKey((Object)player.getName())) {
                                    player.inventory = (InventoryPlayer)allGodInv.get((Object)player.getName());
                                } else {
                                    allGodInv.put((String) player.getName(), (InventoryPlayer) player.inventory);
                                }
                            }
                            catch (Throwable throwable) {
                                // empty catch block
                            }
                            if (!EventUtil.haveItem((Item)ItemGzjBlade.item, player)) {
                                player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack((Item)ItemGzjBlade.item));
                            }
                            if (!world.isDaytime()) {
                                world.setWorldTime(0L);
                            }
                            if (info.isHardcoreModeEnabled()) {
                                info.setHardcore(false);
                            }
                            info.setCleanWeatherTime(600);
                            info.setRainTime(0);
                            info.setThunderTime(0);
                            info.setRaining(false);
                            info.setThundering(false);
                            if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
                                player.setGameType(GameType.SURVIVAL);
                            }
                            if (player.getArrowCountInEntity() > 0) {
                                player.setArrowCountInEntity(0);
                            }
                            player.noClip = player.isSprinting();
                            player.xpCooldown = 0;
                            player.clearActivePotions();
                            player.capabilities.allowFlying = true;
                            player.capabilities.disableDamage = true;
                            player.capabilities.isCreativeMode = true;
                            player.isDead = false;
                            player.setInvisible(false);
                            player.extinguish();
                            player.hurtTime = 0;
                            player.deathTime = 0;
                            player.maxHurtTime = 0;
                            player.setHealth(20.0f);
                            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
                            cap.allowEdit = true;
                            cap.isFlying = true;
                            player.setAir(0);
                            food.setFoodLevel(20);
                            food.setFoodSaturationLevel(20.0f);
                            cap.allowFlying = true;
                            player.clearActivePotions();
                            player.getActivePotionEffects().clear();
                            player.setEntityInvulnerable(true);
                            cap.disableDamage = true;
                            if (!world.loadedEntityList.contains((Object)player)) {
                                world.loadedEntityList.add((Entity) player);
                                world.onEntityAdded((Entity)player);
                                world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ).addEntity((Entity)player);
                            }
                            if (!world.playerEntities.contains((Object)player)) {
                                world.playerEntities.add((EntityPlayer) player);
                                world.onEntityAdded((Entity)player);
                                world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ).addEntity((Entity)player);
                            }
                            if (player instanceof EntityPlayerMP) {
                                EntityPlayerMP mp = (EntityPlayerMP)player;
                                NetHandlerPlayServer server = mp.connection;
                                MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
                                mp.connection = new NetHandlerPlayServer(mcserv, server.netManager, mp){

                                    public void disconnect(ITextComponent textComponent) {
                                    }
                                };
                            }
                            player.isDead = false;
                        }
                        ++i;
                    } while (true);
                }
                catch (Exception i) {
                    continue;
                }
            } while (true);
        }, "MainThreadForGoblade");
        this.start();
        new Thread(() -> {
            do {
                try {
                    Thread.sleep((long)200L);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (i < 14) {
                    ++i;
                    continue;
                }
                i = 0;
            } while (true);
        }).start();
    }

    private static void VV() {
        World world;
        int i;
        ArrayList worldList = new ArrayList();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc != null) {
            if (mc.world != null) {
                worldList.add((Object)mc.world);
            }
            if (mc.getIntegratedServer() != null) {
                for (i = 0; i < mc.getIntegratedServer().worlds.length; ++i) {
                    world = mc.getIntegratedServer().worlds[i];
                    if (world == null) continue;
                    worldList.add((Object)world);
                }
            }
        }
        for (i = 0; i < worldList.size(); ++i) {
            world = (World)worldList.get(i);
            if (world == null) continue;
            MainThread.setWorldList(world);
        }
    }

    private static void setWorldList(World world) {
        if (world == null) {
            return;
        }
        if (!(world.loadedEntityList instanceof WorldEntityList)) {
            world.loadedEntityList = new WorldEntityList(world.loadedEntityList);
        }
        if (!(world.weatherEffects instanceof WorldEntityList)) {
            world.weatherEffects = new WorldEntityList(world.weatherEffects);
        }
    }

}


