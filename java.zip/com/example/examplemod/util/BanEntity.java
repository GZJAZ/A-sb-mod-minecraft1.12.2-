/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Set
 */
package com.example.examplemod.util;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.entity.Entity;

public class BanEntity {
    public static Set<String> ban = new HashSet();

    public static boolean is(Entity entity) {
        if (entity == null) {
            return false;
        }
        return ban.contains((Object)entity.getClass().getName());
    }

    public static void add(Entity entity) {
        ban.add((String) entity.getClass().getName());
    }
}

