/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.List
 *  java.util.stream.Collector
 *  java.util.stream.Collectors
 *  java.util.stream.Stream
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.EntityTracker
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.WorldServer
 *  net.minecraft.world.chunk.Chunk
 *  net.minecraft.world.chunk.IChunkProvider
 *  net.minecraftforge.client.GuiIngameForge
 */
package com.example.examplemod.util;

import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.client.GuiIngameForge;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Kill2 {
    private static Kill2 Instance;
    public static double Infinity;
    public static List<String> entityId;

    public Kill2(Entity entity) {
        Instance = this;
    }

    public static Kill2 getEntity() {
        return Instance;
    }

    public static void NewKillEntity(Entity entity) {
        if (entity != null) {
            World world = entity.getEntityWorld();
            Fuck.setEntityDead(entity);
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase livingBase = (EntityLivingBase)entity;
                livingBase.deathTime = 20;
                livingBase.hurtTime = 20;
                livingBase.maxHurtTime = 20;
                livingBase.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0);
                livingBase.setHealth(0.0f);
            }
            ((List)entity.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(entity.posX - 50.0, entity.posY - 50.0, entity.posZ - 50.0, entity.posX + 50.0, entity.posY + 50.0, entity.posZ + 50.0), null).stream().sorted(new Object(){

                Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
                    return Comparator.comparing(_entcnd -> _entcnd.getDistanceSq(_x, _y, _z));
                }
            }.compareDistOf(entity.posX, entity.posY, entity.posZ)).collect(Collectors.toList())).remove((Object)entity);
            entity.onRemovedFromWorld();
            entity.addedToChunk = false;
            entity.isDead = true;
            entity.preventEntitySpawning = false;
            entity.width = 0.0f;
            entity.height = 0.0f;
            entity.ignoreFrustumCheck = true;
            entity.setEntityBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0));
            entity.removePassengers();
            entity.noClip = true;
            entity.setInvisible(true);
            entity.ticksExisted = 0;
            entity.world.setBlockState(new BlockPos(entity.posX, entity.posY, entity.posZ), Blocks.AIR.getDefaultState(), 3);
            entity.setEntityBoundingBox(Ax.badAxisAlignedBB);
            Kill2.setDead(entity);
            Kill2.isDead(entity);
            world.setEntityState(entity, (byte)3);
            Chunk chunk = world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
            chunk.removeEntity(entity);
            chunk.setHasEntities(false);
            world.getChunkProvider().getLoadedChunk(chunk.x, chunk.z);
            world.loadedEntityList.remove((Object)entity);
            if (world.isRemote) {
                WorldClient worldClient = (WorldClient)world;
                worldClient.removeEntity(entity);
            } else {
                WorldServer worldServer = (WorldServer)world;
                worldServer.getEntityTracker().untrack(entity);
            }
        }
    }

    public static void setDead(Object o) {
        if (!entityId.contains((Object)((Entity)o).getName())) {
            entityId.add((String) ((Entity)o).getName());
        }
    }

    public static boolean isDead(Object o) {
        Entity entity;
        if (o instanceof Entity && entityId.contains((Object)(entity = (Entity)o).getName())) {
            entity.world.removeEntity(entity);
            entity.world.loadedEntityList.remove((Object)entity);
            entity.world.weatherEffects.remove((Object)entity);
        }
        if (!(o instanceof Entity)) {
            return false;
        }
        return entityId.contains((Object)((Entity)o).getName());
    }

    public static void kill(Entity ent) {
        try {
            if (ent instanceof EntityLivingBase) {
                EntityLivingBase living = (EntityLivingBase)ent;
                living.deathTime = 20;
                living.hurtTime = 20;
                living.maxHurtTime = 20;
                living.clearActivePotions();
                living.getActivePotionEffects().clear();
                living.setAir(0);
                living.setAIMoveSpeed(0.0f);
                living.setHealth(0.0f);
                living.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0);
                living.onRemovedFromWorld();
                GuiIngameForge.renderBossHealth = false;
                if (living instanceof EntityPlayer) {
                    EntityPlayer player = (EntityPlayer)ent;
                    player.inventory.clear();
                    player.cameraPitch = -990.0f;
                    player.cameraYaw = -999.0f;
                }
            }
            Kill2.ke(ent);
        }
        catch (Exception living) {
            // empty catch block
        }
    }

    private static void ke(Entity ent) {
        ent.addTag("isUltimateDead");
        ent.addedToChunk = false;
        ent.onRemovedFromWorld();
        ent.posX = 0.0;
        ent.posY = 1000.0;
        ent.posZ = 0.0;
        ent.setEntityId(-2);
        ent.setDead();
        ent.ticksExisted = -1;
        ent.motionX = 0.0;
        ent.motionY = 0.0;
        ent.motionZ = 0.0;
        ent.width = 0.0f;
        ent.height = 0.0f;
        World world = ent.world;
        world.loadedEntityList.remove((Object)ent);
        world.weatherEffects.remove((Object)ent);
        GuiIngameForge.renderBossHealth = false;
        if (ent instanceof EntityPlayer) {
            world.playerEntities.remove((Object)ent);
        }
    }

    public static void killEntity(Entity entity) {
    }

    public static void kill(World world, EntityLivingBase entity, EntityPlayer player) {
    }

    static {
        Infinity = Double.POSITIVE_INFINITY;
        entityId = new ArrayList();
    }

}

