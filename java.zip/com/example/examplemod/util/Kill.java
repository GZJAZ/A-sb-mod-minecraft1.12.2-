/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.boss.EntityDragon
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.stats.StatBase
 *  net.minecraft.stats.StatList
 *  net.minecraft.util.CombatTracker
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EntityDamageSource
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.chunk.Chunk
 *  net.minecraftforge.fml.common.Loader
 */
package com.example.examplemod.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Loader;

import java.util.ArrayList;
import java.util.Collection;

public class Kill {
    public static void kill(World world, EntityLivingBase entityLivingBase, EntityPlayer entityPlayer) {
        if (entityLivingBase instanceof EntityPlayer) {
            Kill.kill2((EntityPlayer)entityLivingBase);
            entityLivingBase.getCombatTracker().trackDamage(DamageSource.OUT_OF_WORLD, entityLivingBase.getHealth(), entityLivingBase.getHealth());
            Kill.AttackEntityPlayer(world, entityLivingBase, (EntityPlayer)entityLivingBase);
        }
        if (!(entityLivingBase instanceof EntityPlayer)) {
            Event.killloli = true;
            Kill.AttackSimpleEntity(world, entityLivingBase, entityPlayer);
            Kill.AttackSlyEntity(world, entityLivingBase, entityPlayer);
        }
        Kill.KillAllPlayer(entityLivingBase);
        Kill.KillAttackEntity1(entityLivingBase);
        Kill.KillAttackEntity2(entityLivingBase);
    }

    public static void killEntity(Entity entity) {
        entity.setDead();
    }

    public static void kill2(EntityPlayer entityPlayer) {
        entityPlayer.inventory.clear();
    }

    public static void AttackSlyEntity(World world, EntityLivingBase entityLivingBase, EntityPlayer entityPlayer) {
        if (!(world.isRemote || entityLivingBase.isDead || entityLivingBase instanceof EntityPlayer)) {
            entityLivingBase.hurtResistantTime = 0;
            entityLivingBase.onDeath((DamageSource)new EntityDamageSource("xianyu", (Entity)entityPlayer));
            entityLivingBase.setLastAttackedEntity(entityPlayer);
            entityLivingBase.setHealth(0.0f);
            entityLivingBase.attackEntityFrom(DamageSource.OUT_OF_WORLD, 300000.0f);
            entityLivingBase.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0);
        }
    }

    public static void AttackEntityPlayer(World world, Entity entity22, EntityPlayer entityPlayer) {
        if (!world.isRemote && !entity22.isDead && entity22 instanceof EntityPlayer) {
            EntityPlayer entity23 = (EntityPlayer)entity22;
            if (!entity23.isDead) {
                if (entity23.getHealth() <= 0.0f) {
                    entity23.setDead();
                }
                entity23.onDeath((DamageSource)new EntityDamageSource("gzj", (Entity)entityPlayer));
                entity23.setLastAttackedEntity(entityPlayer);
                entity23.getCombatTracker().trackDamage((DamageSource)new EntityDamageSource("gzj", (Entity)entityPlayer), entity23.getHealth(), entity23.getHealth());
                entity23.setHealth(-10.0f);
                entityPlayer.onKillEntity(entity23);
                entity23.world.setEntityState(entity23, (byte)2);
                entity23.handleStatusUpdate((byte)3);
                entity23.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(-10.0);
                entity23.addStat(StatList.DEATHS, 1);
                entity23.setLastAttackedEntity(entityPlayer);
                entity23.closeScreen();
                entity23.velocityChanged = true;
                entity23.addStat(StatList.DAMAGE_TAKEN, Math.round((float)20.0f));
                if (entity23 != entityPlayer) {
                    // empty if block
                }
                entity23.motionY = 0.10000000149011612;
                entity23.width = 0.2f;
                entity23.height = 0.2f;
                entity23.motionX = -MathHelper.cos((float)((entity23.attackedAtYaw + entity23.rotationYaw) * 3.1415927f / 180.0f)) * 0.1f;
                entity23.motionZ = -MathHelper.sin((float)((entity23.attackedAtYaw + entity23.rotationYaw) * 3.1415927f / 180.0f)) * 0.1f;
            }
            if (entity23.deathTime >= 10) {
                entity23.inventory.dropAllItems();
                entity23.clearActivePotions();
                entity23.setHealth(0.0f);
            }
        }
    }

    public static void AttackSpecialEntity(World world, Entity entity, EntityPlayer entityPlayer) {
        if (!world.isRemote) {
            if (entity != null && !(entity instanceof EntityItem) && !(entity instanceof EntityLivingBase)) {
                entity.isDead = true;
            }
            if (!(entity instanceof EntityPlayer) && entity instanceof EntityLivingBase && (entity.isDead || ((EntityLivingBase)entity).getHealth() <= 0.0f)) {
                entity.isDead = true;
                ArrayList entityList = new ArrayList();
                entityList.add((Object)entity);
                entity.world.unloadEntities((Collection<Entity>)entityList);
                entity.world.onEntityRemoved(entity);
                entity.world.loadedEntityList.remove((Object)entity);
                entity.world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ).removeEntity(entity);
                entity.world.setEntityState(entity, (byte)3);
            }
        }
    }

    public static void AttackSimpleEntity(World world, EntityLivingBase entityLivingBase, EntityLivingBase entityPlayer) {
        if (!(world.isRemote || entityLivingBase.isDead || entityLivingBase instanceof EntityPlayer)) {
            if (entityLivingBase.getHealth() <= 0.0f) {
                entityLivingBase.setDead();
            }
            entityLivingBase.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0);
            entityLivingBase.setAIMoveSpeed(0.0f);
            entityLivingBase.hurtResistantTime = 0;
            entityLivingBase.velocityChanged = true;
            entityLivingBase.addVelocity(-MathHelper.sin((float)(entityLivingBase.rotationYaw * 3.1415927f / 180.0f)) * 1.0f * 0.5f, 0.1, MathHelper.cos((float)(entityLivingBase.rotationYaw * 3.1415927f / 180.0f)) * 1.0f * 0.5f);
            entityLivingBase.motionX *= 0.6;
            entityLivingBase.motionZ *= 0.6;
            entityLivingBase.onDeath((DamageSource)new EntityDamageSource("gzj", (Entity)entityPlayer));
            entityLivingBase.setLastAttackedEntity(entityPlayer);
            entityLivingBase.setHealth(-1111.0f);
            entityLivingBase.attackEntityFrom(DamageSource.OUT_OF_WORLD, 300000.0f);
            entityLivingBase.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(-1111110.0);
            entityLivingBase.setHealth(0.0f);
        }
    }

    public static void KillAllPlayer(EntityLivingBase Entity2) {
        if (!Entity2.isDead || !(Entity2.getHealth() <= 0.0f)) {
            if (Entity2 instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer)Entity2;
                player.clearActivePotions();
                player.hurtResistantTime = 0;
                player.attackEntityFrom(DamageSource.OUT_OF_WORLD.setMagicDamage().setDamageBypassesArmor().setDamageAllowedInCreativeMode().setDamageIsAbsolute(), Float.MAX_VALUE);
                player.setHealth(0.0f);
                player.onDeath(DamageSource.OUT_OF_WORLD);
                player.experienceLevel = 0;
                player.experience = 0.0f;
                player.experienceTotal = 0;
                if (player.getHealth() <= 0.0f) {
                    player.isDead = true;
                }
            } else {
                Entity2.hurtResistantTime = 0;
                Entity2.attackEntityFrom(DamageSource.OUT_OF_WORLD.setMagicDamage().setDamageBypassesArmor().setDamageAllowedInCreativeMode().setDamageIsAbsolute(), Float.MAX_VALUE);
                Entity2.setHealth(0.0f);
                Entity2.onDeath(DamageSource.OUT_OF_WORLD);
                Entity2.isDead = true;
            }
        }
    }

    public static void KillAttackEntity1(EntityLivingBase par2EntityLivingBase) {
        if (!(par2EntityLivingBase.isDead && !(par2EntityLivingBase.getHealth() >= 0.0f) || Loader.isModLoaded((String)"thetitans") || par2EntityLivingBase instanceof EntityPlayer)) {
            par2EntityLivingBase.hurtResistantTime = 0;
            par2EntityLivingBase.onDeath(DamageSource.OUT_OF_WORLD);
            par2EntityLivingBase.setHealth(0.0f);
            if (par2EntityLivingBase instanceof EntityDragon || !(par2EntityLivingBase instanceof EntityPlayer)) {
                // empty if block
            }
            par2EntityLivingBase.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0);
        }
    }

    public static void KillAttackEntity2(EntityLivingBase par2EntityLivingBase) {
        if ((!par2EntityLivingBase.isDead || par2EntityLivingBase.getHealth() >= 0.0f) && Loader.isModLoaded((String)"thetitans") && !(par2EntityLivingBase instanceof EntityPlayer)) {
            par2EntityLivingBase.hurtResistantTime = 0;
            par2EntityLivingBase.onDeath(DamageSource.OUT_OF_WORLD);
            par2EntityLivingBase.setHealth(0.0f);
            if (!(par2EntityLivingBase instanceof EntityDragon) && !(par2EntityLivingBase instanceof EntityPlayer)) {
                par2EntityLivingBase.world.removeEntity(par2EntityLivingBase);
                par2EntityLivingBase.setDead();
            }
        }
    }

    public static void KillLiving(EntityLivingBase e) {
    }
}

