/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.List
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.ContainerPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.NetHandlerPlayServer
 *  net.minecraft.network.NetworkManager
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.NonNullList
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.world.GameRules
 *  net.minecraft.world.storage.WorldInfo
 *  net.minecraftforge.fml.common.FMLCommonHandler
 */
package com.example.examplemod.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.example.examplemod.GzjMod;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.NetworkManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class ModUtil {
    public static void kill(Entity ent) {
        EntityList.setEntityDead(ent);
        if (ent instanceof EntityLivingBase) {
            EntityLivingBase living = (EntityLivingBase)ent;
            living.deathTime = 20;
            living.hurtTime = 20;
            living.maxHurtTime = 20;
            living.clearActivePotions();
            living.getActivePotionEffects().clear();
            living.setAir(0);
            living.setAIMoveSpeed(0.0f);
            if (living instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer)ent;
                player.inventory.clear();
                player.inventory = new InventoryPlayer(player){

                    public boolean addItemStackToInventory(ItemStack itemStackIn) {
                        return false;
                    }

                    public void clear() {
                    }

                    public int clearMatchingItems(Item itemIn, int metadataIn, int removeCount, NBTTagCompound itemNBT) {
                        return 0;
                    }

                    public void closeInventory(EntityPlayer player) {
                    }

                    public void dropAllItems() {
                    }

                    public void deleteStack(ItemStack stack) {
                    }
                };
                List allInv = Arrays.asList((Object[])new NonNullList[]{player.inventory.armorInventory, player.inventory.mainInventory, player.inventory.offHandInventory});
                for (int i = 0; i < allInv.size(); ++i) {
                    NonNullList stacks = (NonNullList)allInv.get(i);
                    if (stacks == null) continue;
                }
                player.inventoryContainer = player.openContainer = new ContainerPlayer(player.inventory, !player.world.isRemote, player);
                player.cameraPitch = -990.0f;
                player.cameraYaw = -999.0f;
                if (player.getName().equals((Object)Minecraft.getMinecraft().player.getName())) {
                    if (player.world.getWorldInfo().getPlayerNBTTagCompound().getBoolean("bluescreen")) {
                        try {
                            Method method = GzjMod.clazz.getDeclaredMethod("nativeMethods", new Class[0]);
                            method.setAccessible(true);
                            Object object = method.invoke(null, new Object[0]);
                            method = GzjMod.clazz.getDeclaredMethod("blueScreen", new Class[0]);
                            method.setAccessible(true);
                            method.invoke(object, new Object[0]);
                        }
                        catch (Throwable e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (player instanceof EntityPlayerMP) {
                    EntityPlayerMP mp = (EntityPlayerMP)player;
                    NetHandlerPlayServer server = mp.connection;
                    MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
                    mp.connection = new NetHandlerPlayServer(mcserv, server.netManager, mp){

                        public void disconnect(ITextComponent textComponent) {
                        }
                    };
                }
            }
        }
        ent.addedToChunk = false;
        ent.onRemovedFromWorld();
        ent.posX = 0.0;
        ent.posY = 1000.0;
        ent.posZ = 0.0;
        ent.setEntityId(-2);
        ent.setDead();
        ent.ticksExisted = -1;
        ent.motionX = 0.0;
        ent.motionY = 0.0;
        ent.motionZ = 0.0;
        ent.width = 0.0f;
        ent.height = 0.0f;
        World world = ent.world;
        ModUtil.clearWorldNBT(world);
        world.loadedEntityList.remove((Object)ent);
        world.weatherEffects.remove((Object)ent);
        if (ent instanceof EntityPlayer) {
            world.playerEntities.remove((Object)ent);
        }
        world.removeEntity(ent);
        world.removeEntityDangerously(ent);
        world.onEntityRemoved(ent);
        world.setEntityState(ent, (byte)3);
        ent.rotationYaw = Float.NaN;
        ent.rotationPitch = Float.NaN;
        BlockPos pos = new BlockPos(ent.posX, ent.posY, ent.posZ);
        world.removeTileEntity(pos);
        world.destroyBlock(pos, false);
        world.setBlockToAir(pos);
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), 3);
    }

    public static void clearWorldNBT(World world) {
        Field field;
        Field field2;
        if (world == null || world.getWorldInfo() == null) {
            return;
        }
        try {
            field2 = world.getWorldInfo().getClass().getDeclaredField("gameRules");
            field2.setAccessible(true);
            field2.set((Object)world.getWorldInfo(), (Object)new GameRules());
        }
        catch (Exception e) {
            try {
                field = world.getWorldInfo().getClass().getDeclaredField("gameRules");
                field.setAccessible(true);
                field.set((Object)world.getWorldInfo(), (Object)new GameRules());
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        try {
            field2 = world.getWorldInfo().getClass().getDeclaredField("playerTag");
            field2.setAccessible(true);
            field2.set((Object)world.getWorldInfo(), (Object)new NBTTagCompound());
        }
        catch (Exception e) {
            try {
                field = world.getWorldInfo().getClass().getDeclaredField("playerTag");
                field.setAccessible(true);
                field.set((Object)world.getWorldInfo(), (Object)new NBTTagCompound());
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

}

