package com.example.examplemod.util;

import com.example.examplemod.GzjMod;
import com.example.examplemod.Item.ItemGzjBlade;
import com.example.examplemod.core.interfaces.IMixinEntity;
import com.example.examplemod.network.PacketHandler;
import com.example.examplemod.network.PacketRemoveObject;
import com.example.examplemod.network.PacketSyncUltimatePlayer;
import com.google.common.collect.Sets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.annotation.Nullable;
import java.util.Set;

public final class GzjUtil {

    private static final Set<String> ULTIMATE_PLAYERS = Sets.newHashSet();

    private GzjUtil() {
    }

    public static int getUltimateDeathTime(@Nullable Entity entity) {
        if (entity == null) {
            return 0;
        }

        return ((IMixinEntity) entity).getDeathTime();
    }

    public static int increaseUltimateDeathTime(@Nullable Entity entity) {
        if (entity == null) {
            return 0;
        }

        IMixinEntity mixinEntity = ((IMixinEntity) entity);
        int deathTime = mixinEntity.getDeathTime();
        mixinEntity.setDeathTime(++deathTime);
        return deathTime;
    }

    public static void kill(Entity entity) {
        if (entity == null) {
            return;
        }

        killInternal(entity);
        if (entity instanceof IEntityMultiPart) {
            Entity[] parts = entity.getParts();
            for (Entity part : parts) {
                killInternal(part);
            }
        }
    }

    private static void killInternal(Entity entity) {
        ((IMixinEntity) entity).setUltimateDead();
        if (entity instanceof EntityPlayerMP) {
            EntityPlayerMP serverPlayer = (EntityPlayerMP) entity;
            PacketHandler.sendTo(new PacketRemoveObject.MessageRemoveObject(), serverPlayer);
        }
    }

    public static boolean isUltimateDead(@Nullable Entity entity) {
        if (entity == null) {
            return false;
        }

        return ((IMixinEntity) entity).isUltimateDead();
    }

    public static boolean isGPlayer(Object object) {
        if (object instanceof EntityPlayer) {
            return isGPlayer((EntityPlayer) object);
        } else if (object instanceof String) {
            return isGPlayer((String) object);
        }

        return false;
    }

    private static boolean isGPlayer(String string) {
        return ULTIMATE_PLAYERS.contains(string) || GzjMod.proxy.isGPlayer(string);
    }

    public static boolean isGPlayer(Entity entity) {
        if (entity instanceof EntityPlayer) {
            return isGPlayer((EntityPlayer) entity);
        }

        return false;
    }

    public static boolean isGPlayer(EntityPlayer player) {
        try {
            if (isGPlayer(player.getGameProfile().getName())) {
                return true;
            } else if (inventoryHasUltimate(player)) {
                addUltimatePlayer(player);
                return true;
            }
        } catch (Exception e) {
        }

        return false;
    }

    public static boolean inventoryHasUltimate(@Nullable EntityPlayer player) {
        if (player == null) {
            return false;
        }

        if (player.getHeldItemMainhand().getItem() instanceof ItemGzjBlade
                || player.getHeldItemOffhand().getItem() instanceof ItemGzjBlade) {
            return true;
        }

        if (player.inventory.hasItemStack(new ItemStack(ItemGzjBlade.item))) {
            return true;
        }

        return false;
    }

    public static void addUltimatePlayer(EntityPlayer player) {
        String name = player.getName();
        addUltimatePlayer(name);
        if (FMLCommonHandler.instance().getEffectiveSide().isServer()) {
            PacketHandler.sendToAll(new PacketSyncUltimatePlayer.MessageSyncUltimatePlayer(name));
        }
    }

    public static void addUltimatePlayer(String player) {
        ULTIMATE_PLAYERS.add(player);
    }
}
