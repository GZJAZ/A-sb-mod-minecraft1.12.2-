/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.event.entity.living.LivingEvent
 *  net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package com.example.examplemod.util;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ListenerTimeStop {
    protected static boolean enabletimestop = false;

    public static void EnableTimeStop() {
        enabletimestop = true;
    }

    public static boolean isTimeStopping() {
        return enabletimestop;
    }

    public static void disableTimeStop() {
        enabletimestop = false;
    }

    @SubscribeEvent(priority=EventPriority.HIGHEST)
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (ListenerTimeStop.isTimeStopping()) {
            try {
                if (event.getEntity() instanceof EntityPlayer && NoStopEntity.contains(((EntityPlayer)event.getEntity()).getName())) {
                    if (NoStopEntity.contains(Minecraft.getMinecraft().player.getName())) {
                        Minecraft.getMinecraft().skipRenderWorld = false;
                    }
                    return;
                }
                event.setCanceled(true);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }
}

