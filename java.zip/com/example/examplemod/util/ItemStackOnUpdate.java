/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  net.minecraft.client.gui.GuiGameOver
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.entity.player.PlayerCapabilities
 *  net.minecraft.item.Item
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.NetHandlerPlayServer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.SPacketUpdateHealth
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.ClassInheritanceMultiMap
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.FoodStats
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.GameRules
 *  net.minecraft.world.GameType
 *  net.minecraft.world.chunk.Chunk
 *  net.minecraft.world.storage.WorldInfo
 *  net.minecraftforge.fml.common.eventhandler.EventBus
 */
package com.example.examplemod.util;

import com.example.examplemod.Item.ItemGzjBlade;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.util.EnumHand;
import net.minecraft.util.FoodStats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.common.MinecraftForge;

import java.util.ArrayList;
import java.util.List;

public class ItemStackOnUpdate {
    public static List<String> hasitem = new ArrayList();

    public ItemStackOnUpdate() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    public static boolean isGod(Object o) {
        if (!(o instanceof EntityPlayer)) {
            return false;
        }
        return hasitem.contains((Object)((EntityPlayer)o).getName());
    }

    public static void get(Entity entity) {
        EntityPlayer player = (EntityPlayer)entity;
        World world = player.world;
        WorldInfo info = world.getWorldInfo();
        PlayerCapabilities cap = player.capabilities;
        FoodStats food = player.getFoodStats();
        Minecraft mc = Minecraft.getMinecraft();
        if (info.getGameType().equals((Object)GameType.ADVENTURE)) {
            player.setGameType(GameType.SURVIVAL);
        }
        if (player.getArrowCountInEntity() > 0) {
            player.setArrowCountInEntity(0);
        }
        world.getGameRules().setOrCreateGameRule("keepInventory", "true");
        player.setInvisible(false);
        player.updateBlocked = false;
        player.xpCooldown = 0;
        cap.allowEdit = true;
        player.setSpawnPoint(new BlockPos(player.posX, player.posY, player.posZ), true);
        player.setAir(0);
        food.setFoodLevel(20);
        food.setFoodSaturationLevel(20.0f);
        player.clearActivePotions();
        player.getActivePotionEffects().clear();
        player.setEntityInvulnerable(true);
        cap.disableDamage = true;
        player.setHealth(20.0f);
        player.getEntityData().setFloat("Health", 20.0f);
        if (player instanceof EntityPlayerMP) {
            EntityPlayerMP playerMP = (EntityPlayerMP)player;
            playerMP.connection.sendPacket((Packet)new SPacketUpdateHealth(20.0f, 20, 20.0f));
        }
        player.isDead = false;
        player.deathTime = -2;
        if (mc.currentScreen instanceof GuiGameOver) {
            mc.currentScreen = null;
        }
    }

    public static void safePlayer(EntityPlayer player) {
        World world = player.world;
        if (!world.loadedEntityList.contains((Object)player)) {
            world.loadedEntityList.add((Entity) player);
        }
        if (!world.playerEntities.contains((Object)player)) {
            world.playerEntities.add((EntityPlayer) player);
        }
        world.setEntityState(player, (byte)0);
        boolean isInChunk = false;
        Chunk chunk = world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ);
        for (ClassInheritanceMultiMap entities : chunk.getEntityLists()) {
            for (Object entity : entities) {
                if (!entity.equals((Object)player)) continue;
                isInChunk = true;
            }
        }
        if (!isInChunk) {
            chunk.addEntity((Entity)player);
        }
        player.deathTime = 0;
        player.hurtTime = 0;
        player.isDead = false;
        player.addedToChunk = true;
        player.updateBlocked = false;
        player.setHealth(20.0f);
        player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
        if (!player.inventory.hasItemStack(new ItemStack((Item) ItemGzjBlade.item))) {
            ItemStack stack = new ItemStack((Item) ItemGzjBlade.item);
            stack.setCount(1);
            player.setHeldItem(EnumHand.MAIN_HAND, stack);
        }
    }

    public static void Jingui() {
        Minecraft mc = Minecraft.getMinecraft();
        if (!(mc.currentScreen == null || mc.currentScreen.getClass().getName().startsWith("net.minecraft.") || mc.currentScreen.getClass().getName().contains((CharSequence)"net.minecraftforge") || mc.currentScreen.getClass().getName().contains((CharSequence)"net.optifine"))) {
            mc.currentScreen = null;
        }
    }

    public static void executeProcedure(EntityPlayer player) {
    }
}

