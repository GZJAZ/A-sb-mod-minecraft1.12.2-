/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  java.lang.Object
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Set
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraftforge.event.entity.EntityJoinWorldEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package com.example.examplemod.util;

import com.google.common.collect.Sets;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Set;

public class Event {
    public static boolean killloli;
    public static boolean killwither;
    public static Set<Entity> antiEntity;

    public static void hanhan(EntityLivingBase entity) {
        if (entity.getHealth() > 0.0f) {
            entity.setHealth(entity.getMaxHealth());
        } else {
            entity.setHealth(20.0f);
        }
        entity.isDead = false;
    }

    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        Entity entity = event.getEntity();
        if (antiEntity.contains((Object)entity)) {
            event.setCanceled(true);
            Minecraft.getMinecraft().world.removeEntity(entity);
            Minecraft.getMinecraft().world.loadedEntityList.remove((Object)entity);
            Minecraft.getMinecraft().world.getLoadedEntityList().add((Entity) entity);
            event.setCanceled(false);
            event.setCanceled(true);
            entity.isDead = true;
            Minecraft.getMinecraft().world.getLoadedEntityList().remove((Object)entity);
            Minecraft.getMinecraft().world.loadedEntityList.remove((Object)entity);
        }
        if (killloli) {
            if (event.getEntity() instanceof EntityPlayer) {
                return;
            }
            event.setCanceled(true);
        }
    }

    static {
        antiEntity = Sets.newHashSet();
    }
}

