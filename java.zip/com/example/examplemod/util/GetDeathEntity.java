/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 */
package com.example.examplemod.util;

import net.minecraft.entity.Entity;

import java.util.*;

public class GetDeathEntity {
    private static final List<Entity> entityList = new ArrayList();
    private static final Set<UUID> entityUuid = new HashSet();
    private static final Map<Entity, Integer> entityId = new HashMap();

    public static boolean isDeadEntity(Object entity) {
        if (!(entity instanceof Entity)) {
            return false;
        }
        return entityList.contains((Object)((Entity)entity)) || entityId.containsValue((Object)((Entity)entity).getEntityId()) || entityUuid.contains((Object)((Entity)entity).getUniqueID());
    }

    public static void setDeadEntity(Entity entity) {
        entityId.put((Entity) entity, (Integer) entity.getEntityId());
        entityUuid.add((UUID) entity.getUniqueID());
        entityList.add((Entity) entity);
    }
}

