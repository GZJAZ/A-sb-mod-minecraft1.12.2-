package com.example.examplemod.util;

import net.minecraft.entity.Entity;

import java.util.Collection;
import java.util.HashSet;

public final class GzjEntitySet extends HashSet<Entity> {
    public GzjEntitySet(Collection<Entity> c) {
        super(c);
    }

    @Override
    public boolean add(Entity e) {
        if (GzjUtil.isUltimateDead(e)) {
            return false;
        }

        return super.add(e);
    }

    @Override
    public boolean addAll(Collection<? extends Entity> c) {
        c.removeIf(GzjUtil::isUltimateDead);
        return super.addAll(c);
    }

    @Override
    public boolean remove(Object o) {
        if (o instanceof Entity) {
            if (GzjUtil.isGPlayer((Entity) o)) {
                return false;
            }
        }
        return super.remove(o);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        c.removeIf(GzjUtil::isGPlayer);
        return super.removeAll(c);
    }
}
