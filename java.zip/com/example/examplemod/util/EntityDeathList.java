/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.example.examplemod.util;

import java.util.ArrayList;
import java.util.Collection;

public class EntityDeathList
extends ArrayList<String> {
    private static EntityDeathList deathlist = null;

    public static EntityDeathList list() {
        if (deathlist == null) {
            deathlist = new EntityDeathList();
        }
        return deathlist;
    }

    public String remove(int index) {
        return "";
    }

    public boolean removeAll(Collection<?> c) {
        return false;
    }

    public boolean remove(Object o) {
        return false;
    }

    public boolean add(String e) {
        if (this.contains((Object)e)) {
            return false;
        }
        return super.add((String) e);
    }
}

