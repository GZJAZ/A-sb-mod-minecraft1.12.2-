/*
 * Decompiled with CFR 0.0.
 *
 * Could nang.String
 *  java.lang.System
 *  java.util.Random
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.texture.TextureManager
 *  net.minecraft.client.resources.LanguageManager
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.text.TextFormatting
 */
package com.example.examplemod.util;

import com.example.examplemod.Item.ItemGzjBlade;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;

import java.util.Random;

public class FontColor
        extends FontRenderer {
    private static FontColor font;

    public static FontColor getFont() {
        if (font == null) {
            Minecraft mc = Minecraft.getMinecraft();
            font = new FontColor(mc.gameSettings, new ResourceLocation("textures/font/ascii.png"), mc.renderEngine, false);
            if (mc.gameSettings.language != null) {
                font.setUnicodeFlag(mc.isUnicode());
                font.setBidiFlag(mc.getLanguageManager().isCurrentLanguageBidirectional());
            }
        }
        return font;
    }

    private FontColor(GameSettings gameSettingsIn, ResourceLocation location, TextureManager textureManagerIn, boolean unicode) {
        super(gameSettingsIn, location, textureManagerIn, unicode);
    }

    public static long milliTime() {
        return System.nanoTime() / 2000000L;
    }

    public int next(String string, float x, float y, int color) {
        float hue = (float)FontColor.milliTime() / 1000.0f % 1.0f;
        float hueStep = 0.03f;
        float speed = 0.015f;
        float size = 3.0f;
        float posX = x;
        String drawText = TextFormatting.getTextWithoutFormattingCodes((String)string);
        for (int i2 = 0; i2 < drawText.length(); ++i2) {
            int c2 = color & -16777216 | MathHelper.hsvToRGB((float)hue, (float)ItemGzjBlade.hsv, (float)1.0f);
            float xOffset = size * (float)Math.cos((double)((float)FontColor.milliTime() / 300.0f + (float)i2 * 0.2f));
            float yOffset = size * (float)Math.sin((double)((float)FontColor.milliTime() / 300.0f + (float)i2 * 0.2f));
            posX = super.drawStringWithShadow(String.valueOf((char)drawText.charAt(i2)), posX + xOffset, y + yOffset, c2);
            hue += hueStep;
            hue %= 1.0f;
            if (i2 % 5 != 0) continue;
            speed = 0.02f + 0.05f * (float)(i2 % 10);
            if (i2 % 10 == 0) {
                hueStep = 5.0E-4f;
            }
            size = 1.5f + 0.5f * MathHelper.sin((float)((float)FontColor.milliTime() / 500.0f + (float)i2 * 0.5f));
        }
        return (int)posX;
    }

    public int drawStringWithShadow(String string, float x, float y, int color) {
        float time = (float)FontColor.milliTime() / 3000.0f;
        float radius = 20.0f + 5.0f * MathHelper.sin((float)(time * 3.0f));
        int steps = 50;
        float angleStep = 3.1415927f / (float)steps;
        float hueStep = 0.03f;
        float hue = time % 1.0f;
        Random random = new Random();
        for (int i2 = 0; i2 < string.length(); ++i2) {
            char c2 = string.charAt(i2);
            String drawText = String.valueOf((char)c2);
            float xOffset = radius * (float)Math.cos((double)((float)i2 * angleStep + time * 5.0f));
            float yOffset = radius * (float)Math.sin((double)((float)i2 * angleStep + time * 5.0f));
            float scale = 1.0f + 0.2f * MathHelper.sin((float)(time * 2.0f + (float)i2 * 0.5f));
            int cColor = color & -16777216 | MathHelper.hsvToRGB((float)hue, (float)ItemGzjBlade.hsv, (float)1.0f);
            int textWidth = this.getStringWidth(drawText) / 2;
            int posx = (int)(x + xOffset - (float)textWidth * scale);
            int posy = (int)(y + yOffset - 4.0f * scale);
            int rposx = random.nextInt(600);
            int rposy = (int)(y + yOffset - 4.0f * (float)random.nextInt(100));
            float sinHue = MathHelper.sin((float)(hue * 3.1415927f));
            int shadowColor = MathHelper.hsvToRGB((float)hue, (float) ItemGzjBlade.hsv, (float)(0.7f + sinHue * 0.3f));
            this.next(string, x, y, color);
            hue += hueStep;
            hue %= 1.0f;
        }
        return (int)x;
    }

    private static double rangeRemap(double value, double low1, double high1, double low2, double high2) {
        return low2 + (value - low1) * (high2 - low2) / (high1 - low1);
    }

    private void drawStringWithShadow(String text, int x, int y, int color, int shadowColor, float scale) {
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)x, (float)y, (float)0.0f);
        GlStateManager.scale((float)scale, (float)scale, (float)1.0f);
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRenderer;
        fontRenderer.drawString(text, 0.0f, 0.0f, shadowColor, true);
        fontRenderer.drawString(text, -1.0f, -1.0f, color, true);
        GlStateManager.popMatrix();
    }
}
