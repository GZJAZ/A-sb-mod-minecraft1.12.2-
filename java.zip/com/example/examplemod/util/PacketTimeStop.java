/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  net.minecraft.client.shader.ShaderGroup
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.example.examplemod.util;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(value=Side.CLIENT)
public class PacketTimeStop
implements IMessage {
    public boolean isStop;

    public PacketTimeStop() {
    }

    public PacketTimeStop(boolean isStop) {
        this.isStop = isStop;
    }

    public void fromBytes(ByteBuf buf) {
        this.isStop = buf.readBoolean();
    }

    public void toBytes(ByteBuf buf) {
        buf.writeBoolean(this.isStop);
    }

    public static class Handler
    implements IMessageHandler<PacketTimeStop, IMessage> {
        public IMessage onMessage(PacketTimeStop pkt, MessageContext ctx) {
            if (pkt.isStop) {
                ResourceLocation r = new ResourceLocation("shaders/post/desaturate.json");
                try {
                    if (Minecraft.getMinecraft().entityRenderer.getShaderGroup() == null) {
                        Minecraft.getMinecraft().entityRenderer.stopUseShader();
                        Minecraft.getMinecraft().entityRenderer.loadShader(r);
                    }
                    ListenerTimeStop.EnableTimeStop();
                }
                catch (Exception exception) {}
            } else {
                ListenerTimeStop.disableTimeStop();
                Minecraft.getMinecraft().skipRenderWorld = false;
                if (Minecraft.getMinecraft().entityRenderer.itemRenderer != null) {
                }
            }
            return null;
        }
    }

}

