/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.network.datasync.EntityDataManager$DataEntry
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.ClassInheritanceMultiMap
 *  net.minecraft.util.CombatTracker
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.chunk.IChunkProvider
 *  net.minecraftforge.fml.relauncher.ReflectionHelper
 */
package com.example.examplemod.util;

import com.example.examplemod.dszjhgvfshudjgfuya.GzjDamageSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.UUID;

public class KillEntity {
    public static void killEntity(Entity entity) {
        World world = entity.world;
        Chunk chunk = world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
        Chunk ca = world.getChunkProvider().getLoadedChunk(entity.chunkCoordX, entity.chunkCoordZ);
        Minecraft mc = Minecraft.getMinecraft();
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            player.inventory = new InventoryPlayer(player);
            world.playerEntities.remove((Object)player);
        }
        entity.setDead();
        entity.setPosition(Double.NaN, Double.NaN, Double.NaN);
        entity.getEntityData().tagMap.clear();
        world.loadedEntityList.remove((Object)entity);
        world.removeEntity(entity);
        world.onEntityRemoved(entity);
        world.setEntityState(entity, (byte)3);
        chunk.removeEntity(entity);
        entity.resetEntityId();
        entity.onRemovedFromWorld();
        entity.setEntityId(11);
        entity.setEntityBoundingBox(new AxisAlignedBB(new BlockPos(0.0, 0.0, 0.0)));
        entity.setUniqueId(UUID.randomUUID());
        if (ca != null && !ca.isEmpty()) {
            KillEntity.c(chunk, entity);
            ca.removeEntity(entity);
            ca.setHasEntities(false);
            ca.setHasEntities(false);
        }
        GzjKillEntity.killEntity(entity);
        GetDeathEntity.setDeadEntity(entity);
        entity.forceSpawn = false;
        entity.preventEntitySpawning = true;
        entity.isDead = true;
        entity.updateBlocked = true;
        entity.noClip = true;
        entity.ticksExisted = -2147483647;
        entity.onRemovedFromWorld();
        entity.addedToChunk = false;
        entity.posX = -999.0;
        entity.posY = -4096.0;
        entity.posZ = -999.0;
        world.removeEntity(entity);
        world.loadedEntityList.remove((Object)entity);
        world.weatherEffects.remove((Object)entity);
        entity.world.removeEntity(entity);
        entity.setDead();
        entity.isDead = true;
        entity.addedToChunk = false;
        entity.setSilent(false);
        entity.setInvisible(true);
        entity.forceSpawn = false;
        entity.resetEntityId();
        entity.preventEntitySpawning = true;
        entity.ticksExisted = -1;
        entity.updateBlocked = true;
        entity.noClip = true;
        entity.onRemovedFromWorld();
        entity.posX = 0.0;
        entity.posY = 1000.0;
        entity.posZ = 0.0;
        entity.setDead();
        entity.ticksExisted = -1;
        entity.motionX = 0.0;
        entity.motionY = 0.0;
        entity.motionZ = 0.0;
        entity.width = 0.0f;
        entity.height = 0.0f;
        if (entity instanceof EntityLivingBase) {
            KillEntity.KillLiving((EntityLivingBase)entity);
        }
        world.loadedEntityList.remove((Object)entity);
        world.weatherEffects.remove((Object)entity);
        world.loadedEntityList.add((Entity) entity);
        world.setEntityState(entity, (byte)3);
        chunk.removeEntity(entity);
        chunk.setHasEntities(false);
        RenderManager manager = mc.getRenderManager();
        HashMap classRenderHashMap = new HashMap();
        classRenderHashMap.putAll(manager.entityRenderMap);
        manager.entityRenderMap.clear();
        if (world.isRemote) {
            WorldClient worldClient = (WorldClient)world;
        } else {
            WorldServer worldServer = (WorldServer)world;
            Entity remove;
            worldServer.getEntityTracker().untrack(entity);
        }
    }

    public static void c(Chunk chunk, Entity entityIn) {
        int index = entityIn.chunkCoordY;
        if (index < 0) {
            index = 0;
        }
        if (index >= chunk.getEntityLists().length) {
            index = chunk.getEntityLists().length - 1;
        }
        chunk.getEntityLists()[index].remove((Object)entityIn);
        chunk.markDirty();
    }

    public static void KillLiving(EntityLivingBase living) {
        Minecraft mc = Minecraft.getMinecraft();
        World world = living.world;
        MinecraftServer server = world.getMinecraftServer();
        Chunk c = living.world.getChunkFromChunkCoords(living.chunkCoordX, living.chunkCoordZ);
        ArrayList entitylist = new ArrayList();
        ArrayList unloads = new ArrayList();
        if (living instanceof EntityLivingBase) {
            living.onKillCommand();
            living.setHealth(Float.NEGATIVE_INFINITY);
            living.onKillEntity(living);
            living.setDropItemsWhenDead(true);
            entitylist.add((Object)living);
            unloads.add((Object)living);
            living.attackEntityFrom(new GzjDamageSource(), Float.POSITIVE_INFINITY);
            living.getEntityData().setFloat("Health", Float.NEGATIVE_INFINITY);
            living.setLastAttackedEntity(living);
            try {
                ReflectionHelper.findField((Class)living.getClass(), (String[])new String[]{"hurt_timer"}).setInt((Object)living, 0);
                ReflectionHelper.findField(EntityLivingBase.class, (String[])new String[]{"recentlyHit", "recentlyHit"}).setInt((Object)living, 60);
            }
            catch (Exception e) {
                living.hurtResistantTime = 0;
            }
            living.getCombatTracker().trackDamage((DamageSource)new GzjDamageSource(), Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
            living.world.setEntityState(living, (byte)3);
            living.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(Double.NEGATIVE_INFINITY);
            living.getDataManager().set(((EntityDataManager.DataEntry)living.getDataManager().getAll().get(7)).getKey(), (Object)Float.valueOf((float)Float.NEGATIVE_INFINITY));
            living.ticksExisted = Integer.MIN_VALUE;
            if (living.world.isRemote && living.isEntityAlive()) {
                mc.renderGlobal.onEntityRemoved(living);
                world.unloadEntities((Collection<Entity>)unloads);
                world.unloadEntities((Collection<Entity>)entitylist);
                mc.world.removeEntity(living);
                mc.world.onEntityRemoved(living);
                mc.world.removeEntityFromWorld(living.getEntityId());
            }
            MinecraftForge.EVENT_BUS.unregister(living);
        }
    }
}

