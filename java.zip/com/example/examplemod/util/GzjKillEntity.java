/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.net.URLClassLoader
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentMap
 *  java.util.function.Consumer
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.launchwrapper.Launch
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ClassInheritanceMultiMap
 *  net.minecraft.util.IntHashMap
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.gen.ChunkProviderServer
 *  net.minecraftforge.client.GuiIngameForge
 *  net.minecraftforge.event.entity.EntityEvent
 *  net.minecraftforge.event.entity.EntityEvent$CanUpdate
 *  org.lwjgl.LWJGLException
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 */
package com.example.examplemod.util;

import com.example.examplemod.util.classutil.ClassUtil;
import com.google.common.collect.Maps;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.launchwrapper.Launch;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.gen.ChunkProviderServer;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityEvent;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

public class GzjKillEntity {
    public static List<String> deadString = new ArrayList();

    public static void killEntity(Entity entity) {
        if (entity == null) {
            return;
        }
        if (GodList.isGodPlayer(entity)) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        Minecraft.getMinecraft().addScheduledTask(() -> {
            if (mc.world.isRemote) {
                try {
                    URLClassLoader ucl = (URLClassLoader)Launch.class.getClassLoader();
                    Method defineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[]{String.class, byte[].class, Integer.TYPE, Integer.TYPE});
                    defineClass.setAccessible(true);
                    InputStream is1 = GzjKillEntity.class.getResourceAsStream("/org/lwjgl/opengl/DefaultGL.class");
                    InputStream is2 = GzjKillEntity.class.getResourceAsStream("/org/lwjgl/opengl/DraftGL.class");
                    int len1 = is1.available();
                    int len2 = is2.available();
                    byte[] dat1 = new byte[len1];
                    byte[] dat2 = new byte[len2];
                    is2.read(dat2, 0, len2);
                    is1.read(dat1, 0, len1);
                    defineClass.invoke((Object)ucl, new Object[]{"org.lwjgl.opengl.DraftGL", dat2, 0, len2});
                    defineClass.invoke((Object)ucl, new Object[]{"org.lwjgl.opengl.DefaultGL", dat1, 0, len1});
                    Class.forName((String)"org.lwjgl.opengl.DefaultGL", (boolean)true, (ClassLoader)ucl);
                    Class.forName((String)"org.lwjgl.opengl.DraftGL", (boolean)true, (ClassLoader)ucl);
                }
                catch (Exception ex) {
                    throw new RuntimeException((Throwable)ex);
                }
            }
        });
        if (!(entity instanceof EntityPlayer)) {
            deadString.add((String) entity.getClass().toString());
        }
        World world = entity.world;
        entity.isDead = true;
        GzjKillEntity.Kill(entity);
        world.loadedEntityList.remove((Object)entity);
        world.weatherEffects.remove((Object)entity);
        world.loadedEntityList.add((Entity) entity);
        if (entity instanceof EntityPlayer) {
            world.playerEntities.remove((Object)entity);
        }
        world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ).removeEntity(entity);
        GzjKillEntity.clearWorldNBT();
        if (!(entity instanceof EntityPlayer) && !entity.getClass().getName().startsWith("net.minecraft.client.mods.mmr.only_love_sword.")) {
            RenderManager rm = Minecraft.getMinecraft().getRenderManager();
            HashMap erm = new HashMap();
            erm.putAll(rm.entityRenderMap);
            rm.entityRenderMap.clear();
            for (Object entry : erm.entrySet()) {
            }
        }
        try {
            if (!entity.world.isRemote && entity.getServer() != null) {
                entity.getServer().getPlayerList().getPlayers().forEach(entity::removeTrackingPlayer);
            }
            if (entity instanceof EntityPlayer) {
                EntityPlayer playerEntity = (EntityPlayer)entity;
                playerEntity.inventory = new InventoryPlayer(playerEntity);
            }
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase livingEntity = (EntityLivingBase)entity;
                livingEntity.clearActivePotions();
                livingEntity.setHealth(Float.NEGATIVE_INFINITY);
                livingEntity.deathTime = Integer.MIN_VALUE;
                if (entity.world instanceof WorldClient) {
                    ((WorldClient)entity.world).removeEntityFromWorld(((EntityLivingBase) entity).getEntityId());
                }
                if (entity.world instanceof WorldServer) {
                    entity.world.removeEntity(entity);
                }
            }
            entity.world.removeEntity(entity);
            entity.world.onEntityRemoved(entity);
            entity.world.removeEntityDangerously(entity);
            entity.world.loadedTileEntityList.clear();
            entity.onRemovedFromWorld();
            entity.addedToChunk = false;
            Chunk chunk = entity.world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
            chunk.getEntityLists()[entity.chunkCoordY].remove((Object)entity);
            chunk.removeEntity(entity);
            chunk.removeEntityAtIndex(entity, entity.chunkCoordY);
            chunk.markDirty();
            entity.isDead = true;
            entity.preventEntitySpawning = false;
            entity.addedToChunk = false;
            entity.width = 0.0f;
            entity.height = 0.0f;
            entity.ignoreFrustumCheck = true;
            entity.setEntityBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0));
            entity.removePassengers();
            entity.noClip = true;
            entity.updateBlocked = true;
            entity.setInvisible(true);
            entity.ticksExisted = 0;
        }
        catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

    public static void Kill(Object object) {
        Minecraft mc = Minecraft.getMinecraft();
        if (object instanceof Entity) {
            Entity entity = (Entity)object;
            World world = entity.world;
            Chunk chunk = entity.getEntityWorld().getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
            EntityEvent.CanUpdate event = new EntityEvent.CanUpdate(entity);
            event.setCanUpdate(false);
            MinecraftForge.EVENT_BUS.unregister(entity);
            mc.renderGlobal.onEntityRemoved(entity);
            entity.isDead = true;
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase living = (EntityLivingBase)entity;
                living.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0);
                living.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0);
                living.isAirBorne = false;
                living.setHealth(0.0f);
            }
            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer)entity;
                player.inventory.clear();
                player.inventory.dropAllItems();
                world.playerEntities.remove((Object)player);
                mc.inGameHasFocus = false;
                KeyBinding.unPressAllKeys();
                Mouse.setGrabbed((boolean)false);
                GuiIngameForge.renderHealth = true;
                try {
                    Display.setFullscreen((boolean)true);
                }
                catch (LWJGLException lWJGLException) {
                    // empty catch block
                }
            }
            entity.updateBlocked = true;
            entity.onRemovedFromWorld();
            entity.isDead = true;
            entity.addedToChunk = false;
            entity.setEntityBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0));
            entity.setInvisible(true);
            chunk.removeEntity(entity);
            if (!world.isRemote) {
                WorldServer worldServer = (WorldServer)world;
                ChunkProviderServer cs = worldServer.getChunkProvider();
                cs.queueUnload(chunk);
                cs.loadChunk(chunk.x, chunk.z);
            }
            world.loadedEntityList.remove((Object)entity);
            world.removeEntity(entity);
            world.onEntityRemoved(entity);
            world.removeEntityDangerously(entity);
            world.setEntityState(entity, (byte)3);
        }
        if (object instanceof TileEntity) {
            mc.world.setBlockToAir(((TileEntity)object).getPos());
        }
    }

    public static void clearWorldNBT() {
        ClassUtil.setRecoverUtil();
        ClassUtil.setRecoverField();
        ClassUtil.setLoadedClassFieldToOld();
        NBTTagCompound playernbt = new NBTTagCompound();
        ConcurrentMap baseMap = Maps.newConcurrentMap();
        try {
            Field field = NBTTagCompound.class.getDeclaredField("tagMap");
            field.setAccessible(true);
            field.set((Object)playernbt, baseMap);
            baseMap.clear();
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
    }
}

