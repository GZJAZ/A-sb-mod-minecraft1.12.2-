/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.example.examplemod.util;

import java.util.ArrayList;
import java.util.Collection;

public class Fuck2
extends ArrayList<String> {
    private static Fuck2 deathlist = null;

    public static Fuck2 list() {
        if (deathlist == null) {
            deathlist = new Fuck2();
        }
        return deathlist;
    }

    public String remove(int index) {
        return "";
    }

    public boolean removeAll(Collection<?> c) {
        return false;
    }

    public boolean remove(Object o) {
        return false;
    }

    public boolean add(String e) {
        if (this.contains((Object)e)) {
            return false;
        }
        return super.add((String) e);
    }
}

