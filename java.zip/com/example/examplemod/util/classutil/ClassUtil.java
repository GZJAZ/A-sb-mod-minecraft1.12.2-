/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.Modifier
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 */
package com.example.examplemod.util.classutil;

import com.google.common.collect.Maps;
import com.google.common.eventbus.EventBus;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

public class ClassUtil {
    private static final Map<String, ClassUtil> cu = Maps.newConcurrentMap();
    public static Map<String, Object> stringField = new HashMap();
    private static Map<Class<?>, HashMap<String, Object>> recordClassesField = new HashMap();
    private static Field field;
    private static final Map<String, Object> cs;
    public static Map<String, ClassUtil> cf;
    public Map<String, Object> staticStringField = new HashMap();

    public static void setRecoverField() {
        for (Field field : stringField.getClass().getDeclaredFields()) {
            if (field == null) continue;
            field.setAccessible(true);
            if (ClassUtil.field != field) continue;
            ClassUtil.field.setAccessible(true);
            if (!Modifier.isStatic((int)ClassUtil.getField().getModifiers()) || Modifier.isFinal((int)ClassUtil.getField().getModifiers())) continue;
            try {
                if (ClassUtil.getField().get((Object)field) != null) {
                    ClassUtil.getField().set(null, null);
                    if (ClassUtil.getField().get((Object)field) instanceof Boolean) {
                        ClassUtil.getField().setBoolean((Object)field.getName(), field.getBoolean((Object)false));
                    }
                    if (ClassUtil.getField().getBoolean((Object)field)) {
                        ClassUtil.getField().setBoolean((Object)field.getName(), field.getBoolean((Object)false));
                    }
                }
            }
            catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            try {
                ((HashMap)recordClassesField.get((Object)field.getDeclaringClass())).replace((Object)field.getName(), field.get(null));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        for (Field field : stringField.getClass().getFields()) {
            if (field == null) continue;
            field.setAccessible(true);
            if (ClassUtil.field != field) continue;
            ClassUtil.field.setAccessible(true);
            if (Modifier.isStatic((int)ClassUtil.getField().getModifiers()) || !Modifier.isFinal((int)ClassUtil.getField().getModifiers())) continue;
            try {
                if (ClassUtil.getField().get((Object)field) != null) {
                    ClassUtil.getField().set((Object)field.getName(), field.get(null));
                    if (ClassUtil.getField().get((Object)field) instanceof Boolean) {
                        ClassUtil.getField().setBoolean((Object)field.getName(), field.getBoolean((Object)false));
                    }
                    if (ClassUtil.getField().getBoolean((Object)field)) {
                        ClassUtil.getField().setBoolean((Object)field.getName(), field.getBoolean((Object)false));
                    }
                }
            }
            catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            try {
                ((HashMap)recordClassesField.get((Object)field.getDeclaringClass())).replace((Object)field.getName(), field.get(null));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Field getField() {
        return field;
    }

    public static void setField(Field field) {
        ClassUtil.field = field;
    }

    public static void setRecoverUtil() {
        for (int i = 0; i < cs.keySet().size(); ++i) {
            Object o = cs.keySet().toArray()[i];
            if (o == null) continue;
            try {
                for (Field field : o.getClass().getDeclaredFields()) {
                    if (!Modifier.isStatic((int)field.getModifiers()) || Modifier.isFinal((int)field.getModifiers()) || !(field.get(o) instanceof Boolean) && !(field.get(o) instanceof List) && !(field.get(o) instanceof Map) && !(field.get(o) instanceof Set) && !(field.get(o) instanceof UUID) && !(field.get(o) instanceof Integer)) continue;
                    field.setAccessible(true);
                    field.set(null, field.get(null));
                }
            }
            catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            if (o instanceof List) {
                ((List)o).clear();
            }
            if (o instanceof Map) {
                ((Map)o).clear();
            }
            if (!(o instanceof Set)) continue;
            ((Set)o).clear();
        }
    }

    public static void setLoadedClassFieldToOld() {
        for (int i = 0; i < cf.keySet().size(); ++i) {
            ClassUtil cd;
            String string = (String)cf.keySet().toArray()[i];
            if (string == null || !cf.containsKey((Object)string) || (cd = (ClassUtil)cf.get((Object)string)) == null) continue;
            try {
                for (Field f : cd.getClass().getDeclaredFields()) {
                    if (f == null || Modifier.isFinal((int)f.getModifiers()) || !Modifier.isStatic((int)f.getModifiers())) continue;
                    f.setAccessible(true);
                    if ((!cd.staticStringField.containsKey((Object)f.getName()) || !(f.get(null) instanceof String) && !(f.get(null) instanceof Boolean) && !(f.get(null) instanceof Float) && !(f.get(null) instanceof Integer) && !(f.get(null) instanceof Double) && !(f.get(null) instanceof Long) && !(f.get(null) instanceof UUID) && !(f.get(null) instanceof List) && !(f.get(null) instanceof Set) && !(f.get(null) instanceof Map)) && !(f.get(null) instanceof EventBus)) continue;
                    f.set(null, cd.staticStringField.get((Object)f.getName()));
                    Object object = f.get(null);
                    if (object == null) continue;
                    if (object instanceof List) {
                        ((List)object).clear();
                    }
                    if (object instanceof Set) {
                        ((Set)object).clear();
                    }
                    if (!(object instanceof Map)) continue;
                    ((Map)object).clear();
                }
                continue;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    static {
        cs = new HashMap();
        cf = new HashMap();
    }
}

