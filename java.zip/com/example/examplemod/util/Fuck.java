/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.ListIterator
 */
package com.example.examplemod.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public abstract class Fuck
implements List<Entity> {
    private final List<Entity> list;

    public static void setEntityDead(Entity entity) {
        if (entity != null) {
            if (entity instanceof EntityPlayer) {
                Fuck2.list().add(entity.getName());
            } else {
                Fuck2.list().add(entity.getClass().getName());
            }
        }
    }

    public static boolean getEntityDead(Entity entity) {
        return entity != null && (Fuck2.list().contains((Object)entity.getName()) || Fuck2.list().contains((Object)entity.getClass().getName()));
    }

    public Fuck(List<Entity> list) {
        this.list = list;
        System.err.println(">>>>------|SetList|------<<<<");
    }

    public int size() {
        return this.list.size();
    }

    public boolean isEmpty() {
        return this.list.isEmpty();
    }

    public boolean contains(Object o) {
        return this.list.contains(o);
    }

    public Iterator<Entity> iterator() {
        return this.list.iterator();
    }

    public Object[] toArray() {
        return this.list.toArray();
    }

    public <T> T[] toArray(T[] a) {
        return (T[]) this.list.toArray((Object[])a);
    }

    public boolean add(Entity e) {
        return this.list.add((Entity) e);
    }

    public boolean remove(Object o) {
        return this.list.remove(o);
    }

    public boolean containsAll(Collection<?> c) {
        return this.list.containsAll(c);
    }

    public boolean addAll(Collection<? extends Entity> c) {
        return this.list.addAll(c);
    }

    public boolean addAll(int index, Collection<? extends Entity> c) {
        return this.list.addAll(index, c);
    }

    public boolean removeAll(Collection<?> c) {
        return this.list.removeAll(c);
    }

    public boolean retainAll(Collection<?> c) {
        return this.list.retainAll(c);
    }

    public void clear() {
        this.list.clear();
    }

    public Entity get(int index) {
        return (Entity)this.list.get(index);
    }

    public Entity set(int index, Entity element) {
        return (Entity)this.list.set(index, (Entity) element);
    }

    public void add(int index, Entity element) {
        this.list.add(index, (Entity) element);
    }

    public Entity remove(int index) {
        return (Entity)this.list.remove(index);
    }

    public int indexOf(Object o) {
        return this.list.indexOf(o);
    }

    public int lastIndexOf(Object o) {
        return this.list.lastIndexOf(o);
    }

    public ListIterator<Entity> listIterator() {
        return this.list.listIterator();
    }

    public ListIterator<Entity> listIterator(int index) {
        return this.list.listIterator(index);
    }

    public List<Entity> subList(int fromIndex, int toIndex) {
        return this.list.subList(fromIndex, toIndex);
    }

    public void put(Object uniqueID, Object entityplayermp) {
    }
}

