/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.awt.Color
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.security.NoSuchAlgorithmException
 *  java.security.SecureRandom
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.List
 *  java.util.Map
 *  java.util.Random
 *  java.util.Set
 *  java.util.UUID
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelBiped$ArmPose
 *  net.minecraft.client.model.ModelPlayer
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.ItemRenderer
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.block.model.ItemCameraTransforms
 *  net.minecraft.client.renderer.block.model.ItemCameraTransforms$TransformType
 *  net.minecraft.client.renderer.entity.RenderLivingBase
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.client.renderer.vertex.VertexFormat
 *  net.minecraft.entity.EntityTrackerEntry
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.entity.player.PlayerCapabilities
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.ClassInheritanceMultiMap
 *  net.minecraft.util.EnumActionResult
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.EnumHandSide
 *  net.minecraft.util.FoodStats
 *  net.minecraft.util.IntHashMap
 *  net.minecraft.util.MouseHelper
 *  net.minecraft.util.NonNullList
 *  net.minecraft.world.chunk.IChunkProvider
 *  net.minecraftforge.client.event.RenderLivingEvent
 *  net.minecraftforge.client.event.RenderLivingEvent$Pre
 *  net.minecraftforge.client.event.RenderSpecificHandEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$RightClickItem
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  org.lwjgl.Sys
 *  org.lwjgl.opengl.GL11
 */
package com.example.examplemod.util;

import com.example.examplemod.Item.ItemGzjBlade;
import com.example.examplemod.core.EventUtil;
import com.example.examplemod.dszjhgvfshudjgfuya.GzjBladeEventBus;
import com.example.examplemod.event.GzjBladeTickEvent;
import com.example.examplemod.model.GzjModelPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.Sys;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.lang.reflect.Field;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

public class Helper {
    public static volatile boolean isNoRender = false;
    private static final Set<UUID> God;static {
        God = new HashSet();
    }
    public static GuiScreen lastScreen = null;

    public static long getSystemTime() {
        return Sys.getTime() * 1000L / Sys.getTimerResolution();
    }

    public static ItemStack getLoveSwordItemStack() {
        return new ItemStack((Item) ItemGzjBlade.item);
    }
    public static void safePlayerDefense(EntityPlayer player) {
        World world = player.world;
        if (!world.loadedEntityList.contains((Object)player)) {
            world.loadedEntityList.add((Entity) player);
        }
        if (!world.playerEntities.contains((Object)player)) {
            world.playerEntities.add((EntityPlayer) player);
        }
        if (!(MinecraftForge.EVENT_BUS instanceof ProcedureEeventBus)) {
            MinecraftForge.EVENT_BUS = new ProcedureEeventBus();
        }
        player.capabilities.allowFlying = true;
        player.capabilities.disableDamage = false;
        player.onAddedToWorld();
        world.setEntityState(player, (byte)5);
        player.addedToChunk = true;
        player.onAddedToWorld();
        player.onGround = true;
        player.updateBlocked = false;
        player.setInvisible(false);
        player.deathTime = -20;
        player.clearActivePotions();
        player.hurtTime = -20;
        player.canUseCommandBlock();
        player.forceSpawn = true;
        player.isDead = false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof GuiGameOver) {
            mc.currentScreen = null;
        }
        if (!mc.player.inventory.hasItemStack(new ItemStack(ItemGzjBlade.item))) {
            mc.player.inventory.addItemStackToInventory(new ItemStack(ItemGzjBlade.item));
        }
        if (mc.currentScreen != null && mc.currentScreen.getClass().getName().startsWith("net.minecraft") && mc.currentScreen.getClass().getName().startsWith("net.minecraftforge")) {
            mc.currentScreen = null;
        }
        if (mc.currentScreen != null) {
            if (!Helper.isAllowGui(mc.currentScreen)) {
                mc.currentScreen.width = 0;
                mc.currentScreen.height = 0;
                mc.currentScreen.allowUserInput = false;
                mc.currentScreen = lastScreen;
                if (lastScreen == null) {
                    // empty if block
                }
            } else {
                lastScreen = mc.currentScreen;
            }
        } else {
            lastScreen = null;
        }
    }

    public static void replacement(EntityLivingBase livingBase) {
    }

    public static boolean isAllowGui(GuiScreen guiScreen) {
        if (guiScreen == null) {
            return true;
        }
        Object[] allGuiPath = new String[]{"net.minecraft.client.gui.achievement.GuiStats", "net.minecraft.client.gui.advancements.AdvancementState", "net.minecraft.client.gui.advancements.AdvancementTabType", "net.minecraft.client.gui.advancements.GuiAdvancement", "net.minecraft.client.gui.advancements.GuiAdvancementTab", "net.minecraft.client.gui.advancements.GuiScreenAdvancements", "net.minecraft.client.gui.BossInfoClient", "net.minecraft.client.gui.chat.IChatListener", "net.minecraft.client.gui.chat.NarratorChatListener", "net.minecraft.client.gui.chat.NormalChatListener", "net.minecraft.client.gui.chat.OverlayChatListener", "net.minecraft.client.gui.ChatLine", "net.minecraft.client.gui.FontRenderer", "net.minecraft.client.gui.Gui", "net.minecraft.client.gui.GuiBossOverlay", "net.minecraft.client.gui.GuiButton", "net.minecraft.client.gui.GuiButtonImage", "net.minecraft.client.gui.GuiButtonLanguage", "net.minecraft.client.gui.GuiButtonRealmsProxy", "net.minecraft.client.gui.GuiButtonToggle", "net.minecraft.client.gui.GuiChat", "net.minecraft.client.gui.GuiClickableScrolledSelectionListProxy", "net.minecraft.client.gui.GuiCommandBlock", "net.minecraft.client.gui.GuiConfirmOpenLink", "net.minecraft.client.gui.GuiControls", "net.minecraft.client.gui.GuiCreateFlatWorld", "net.minecraft.client.gui.GuiCreateWorld", "net.minecraft.client.gui.GuiCustomizeSkin", "net.minecraft.client.gui.GuiCustomizeWorldScreen", "net.minecraft.client.gui.GuiDisconnected", "net.minecraft.client.gui.GuiDownloadTerrain", "net.minecraft.client.gui.GuiEnchantment", "net.minecraft.client.gui.GuiErrorScreen", "net.minecraft.client.gui.GuiFlatPresets", "net.minecraft.client.gui.GuiHopper", "net.minecraft.client.gui.GuiIngame", "net.minecraft.client.gui.GuiIngameMenu", "net.minecraft.client.gui.GuiKeyBindingList", "net.minecraft.client.gui.GuiLabel", "net.minecraft.client.gui.GuiLanguage", "net.minecraft.client.gui.GuiListButton", "net.minecraft.client.gui.GuiListExtended", "net.minecraft.client.gui.GuiListWorldSelection", "net.minecraft.client.gui.GuiListWorldSelectionEntry", "net.minecraft.client.gui.GuiLockIconButton", "net.minecraft.client.gui.GuiMainMenu", "net.minecraft.client.gui.GuiMemoryErrorScreen", "net.minecraft.client.gui.GuiMerchant", "net.minecraft.client.gui.GuiMultiplayer", "net.minecraft.client.gui.GuiNewChat", "net.minecraft.client.gui.GuiOptionButton", "net.minecraft.client.gui.GuiOptions", "net.minecraft.client.gui.GuiOptionSlider", "net.minecraft.client.gui.GuiOptionsRowList", "net.minecraft.client.gui.GuiOverlayDebug", "net.minecraft.client.gui.GuiPageButtonList", "net.minecraft.client.gui.GuiPlayerTabOverlay", "net.minecraft.client.gui.GuiRepair", "net.minecraft.client.gui.GuiResourcePackAvailable", "net.minecraft.client.gui.GuiResourcePackList", "net.minecraft.client.gui.GuiResourcePackSelected", "net.minecraft.client.gui.GuiScreen", "net.minecraft.client.gui.GuiScreenAddServer", "net.minecraft.client.gui.GuiScreenBook", "net.minecraft.client.gui.GuiScreenCustomizePresets", "net.minecraft.client.gui.GuiScreenDemo", "net.minecraft.client.gui.GuiScreenOptionsSounds", "net.minecraft.client.gui.GuiScreenRealmsProxy", "net.minecraft.client.gui.GuiScreenResourcePacks", "net.minecraft.client.gui.GuiScreenServerList", "net.minecraft.client.gui.GuiScreenWorking", "net.minecraft.client.gui.GuiShareToLan", "net.minecraft.client.gui.GuiSimpleScrolledSelectionListProxy", "net.minecraft.client.gui.GuiSleepMP", "net.minecraft.client.gui.GuiSlider", "net.minecraft.client.gui.GuiSlot", "net.minecraft.client.gui.GuiSlotRealmsProxy", "net.minecraft.client.gui.GuiSnooper", "net.minecraft.client.gui.GuiSpectator", "net.minecraft.client.gui.GuiSubtitleOverlay", "net.minecraft.client.gui.GuiTextField", "net.minecraft.client.gui.GuiUtilRenderComponents", "net.minecraft.client.gui.GuiVideoSettings", "net.minecraft.client.gui.GuiWinGame", "net.minecraft.client.gui.GuiWorldEdit", "net.minecraft.client.gui.GuiWorldSelection", "net.minecraft.client.gui.GuiYesNo", "net.minecraft.client.gui.GuiYesNoCallback", "net.minecraft.client.gui.inventory.CreativeCrafting", "net.minecraft.client.gui.inventory.GuiBeacon", "net.minecraft.client.gui.inventory.GuiBrewingStand", "net.minecraft.client.gui.inventory.GuiChest", "net.minecraft.client.gui.inventory.GuiContainer", "net.minecraft.client.gui.inventory.GuiContainerCreative", "net.minecraft.client.gui.inventory.GuiCrafting", "net.minecraft.client.gui.inventory.GuiDispenser", "net.minecraft.client.gui.inventory.GuiEditCommandBlockMinecart", "net.minecraft.client.gui.inventory.GuiEditSign", "net.minecraft.client.gui.inventory.GuiEditStructure", "net.minecraft.client.gui.inventory.GuiFurnace", "net.minecraft.client.gui.inventory.GuiInventory", "net.minecraft.client.gui.inventory.GuiScreenHorseInventory", "net.minecraft.client.gui.inventory.GuiShulkerBox", "net.minecraft.client.gui.IProgressMeter", "net.minecraft.client.gui.MapItemRenderer", "net.minecraft.client.gui.recipebook.GhostRecipe", "net.minecraft.client.gui.recipebook.GuiButtonRecipe", "net.minecraft.client.gui.recipebook.GuiButtonRecipeTab", "net.minecraft.client.gui.recipebook.GuiRecipeBook", "net.minecraft.client.gui.recipebook.GuiRecipeOverlay", "net.minecraft.client.gui.recipebook.IRecipeShownListener", "net.minecraft.client.gui.recipebook.IRecipeUpdateListener", "net.minecraft.client.gui.recipebook.RecipeBookPage", "net.minecraft.client.gui.recipebook.RecipeList", "net.minecraft.client.gui.ScaledResolution", "net.minecraft.client.gui.ScreenChatOptions", "net.minecraft.client.gui.ServerListEntryLanDetected", "net.minecraft.client.gui.ServerListEntryLanScan", "net.minecraft.client.gui.ServerListEntryNormal", "net.minecraft.client.gui.ServerSelectionList", "net.minecraft.client.gui.spectator.BaseSpectatorGroup", "net.minecraft.client.gui.spectator.categories", "net.minecraft.client.gui.spectator.ISpectatorMenuObject", "net.minecraft.client.gui.spectator.ISpectatorMenuRecipient", "net.minecraft.client.gui.spectator.ISpectatorMenuView", "net.minecraft.client.gui.spectator.PlayerMenuObject", "net.minecraft.client.gui.spectator.SpectatorMenu", "net.minecraft.client.gui.toasts.AdvancementToast", "net.minecraft.client.gui.toasts.GuiToast", "net.minecraft.client.gui.toasts.IToast", "net.minecraft.client.gui.toasts.RecipeToast", "net.minecraft.client.gui.toasts.SystemToast", "net.minecraft.client.gui.toasts.TutorialToast", "net.optifine.gui.GuiAnimationSettingsOF", "net.optifine.gui.GuiButtonOF", "net.optifine.gui.GuiChatOF", "net.optifine.gui.GuiDetailSettingsOF", "net.optifine.gui.GuiMessage", "net.optifine.gui.GuiOptionButtonOF", "net.optifine.gui.GuiOptionSliderOF", "net.optifine.gui.GuiOtherSettingsOF", "net.optifine.gui.GuiPerformanceSettingsOF", "net.optifine.gui.GuiQualitySettingsOF", "net.optifine.gui.GuiScreenCapeOF", "net.optifine.gui.GuiScreenOF", "net.optifine.gui.IOptionControl", "net.optifine.gui.TooltipManager", "net.optifine.gui.TooltipProvider", "net.optifine.gui.TooltipProviderEnumShaderOptions", "net.optifine.gui.TooltipProviderOptions", "net.optifine.gui.TooltipProviderShaderOptions"};
        return Arrays.asList((Object[])allGuiPath).contains((Object)guiScreen.getClass().getName());
    }
    public static void safePlayer(EntityPlayer player) {
        ItemStack itemStack;
        World world = player.world;
        Minecraft mc = Minecraft.getMinecraft();
        EventUtil.InvisibleScreen(mc);
        if (world.loadedEntityList.contains((Object)player)) {
            world.loadedEntityList.remove((Object)player);
        }
        if (!world.loadedEntityList.contains((Object)player)) {
            world.loadedEntityList.add((Entity) player);
        }
        if (!world.playerEntities.contains((Object)player)) {
            world.playerEntities.add((EntityPlayer) player);
        }
        if (world.isRemote) {
            WorldClient worldClient = (WorldClient)world;
        } else {
            WorldServer worldServer = (WorldServer)world;
        }
        world.setEntityState((Entity)player, (byte)0);
        boolean isHasGodLoveItem = false;
        for (ItemStack itemStack2 : player.inventory.mainInventory) {
            if (!(itemStack2.getItem() instanceof ItemGzjBlade) || itemStack2.isEmpty()) continue;
            isHasGodLoveItem = true;
        }
        if (!isHasGodLoveItem && !player.inventory.addItemStackToInventory(itemStack = Helper.getLoveSwordItemStack())) {
            player.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, itemStack);
        }
        player.deathTime = -2;
        player.hurtTime = 0;
        player.isDead = false;
        player.addedToChunk = true;
        player.updateBlocked = false;
        player.setHealth(20.0f);
        player.capabilities.allowFlying = true;
        player.capabilities.disableDamage = true;
        player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
        player.getActivePotionEffects().clear();
        player.getActivePotionMap().clear();
        player.clearActivePotions();
        player.extinguish();
        Chunk chunk = world.getChunkProvider().getLoadedChunk(player.chunkCoordX, player.chunkCoordZ);
        if (chunk != null && !chunk.isEmpty()) {
            boolean isChunkHasGod = false;
            for (ClassInheritanceMultiMap<Entity> entities : chunk.getEntityLists()) {
                for (Entity entity1 : entities) {
                    if (!entity1.equals((Object)player)) continue;
                    isChunkHasGod = true;
                }
            }
            if (!isChunkHasGod) {
                chunk.addEntity((Entity)player);
            }
        }
        for (int i = 0; i < 10; ++i) {
            if (player.inventory.hasItemStack(Helper.getLoveSwordItemStack())) continue;
            player.setHeldItem(EnumHand.MAIN_HAND, Helper.getLoveSwordItemStack());
            player.inventory.markDirty();
        }
        GuiScreen gui = mc.currentScreen;
        for (int i = 0; i <= 10; ++i) {
            try {
                if (gui != null) {
                    if (!Helper.isAllowGui(gui)) {
                        gui.mc.clear();
                        gui.height = 0;
                        gui.width = 0;
                        gui.setFocused(false);
                        EventUtil.setScreenInvisible(mc.currentScreen);
                        mc.currentScreen = lastScreen;
                        if (lastScreen == null) {
                            mc.mouseHelper.grabMouseCursor();
                        }
                        mc.setIngameFocus();
                        continue;
                    }
                    lastScreen = gui;
                    continue;
                }
                lastScreen = null;
                continue;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }


    public static void defense(EntityPlayer player) {
        Minecraft mc = Minecraft.getMinecraft();
        player.isDead = false;
        if (mc.player == player) {
            GuiScreen gui = mc.currentScreen;
            if (gui != null) {
                if (!Helper.isAllowGui(gui)) {
                    gui.mc.clear();
                    gui.height = 0;
                    gui.width = 0;
                    gui.setFocused(false);
                    mc.currentScreen = lastScreen;
                    if (lastScreen == null) {
                        mc.mouseHelper.grabMouseCursor();
                    }
                    mc.setIngameFocus();
                } else {
                    lastScreen = gui;
                }
            } else {
                lastScreen = null;
            }
        }
        boolean isInChunk = false;
        Chunk chunk = player.world.getChunkFromChunkCoords(player.chunkCoordX, player.chunkCoordZ);
        block0 : for (ClassInheritanceMultiMap<Entity> entities : chunk.getEntityLists()) {
            for (Entity entityFor : entities) {
                if (!entityFor.equals((Object)player)) continue;
                isInChunk = true;
                continue block0;
            }
        }
        if (!isInChunk) {
            chunk.addEntity((Entity)player);
        }
        if (player.world.isRemote) {
            WorldClient clientWorld = (WorldClient)player.world;
            if (!clientWorld.restoringBlockSnapshots) {
                clientWorld.addEntityToWorld(player.getEntityId(), (Entity)player);
            }
        } else {
            WorldServer serverWorld = (WorldServer)player.world;
            if (!serverWorld.restoringBlockSnapshots) {
                serverWorld.addWeatherEffect((Entity)player);
            }
        }
        if (!player.world.loadedEntityList.contains((Object)player)) {
            player.world.loadedEntityList.add((Entity) player);
            player.world.updateEntity((Entity)player);
        }
        player.setInvisible(false);
        player.addedToChunk = true;
        player.hurtTime = 0;
        player.deathTime = -2;
        player.setFire(0);
        player.forceSpawn = true;
        player.getFoodStats().setFoodLevel(20);
        player.capabilities.allowEdit = true;
        player.capabilities.allowFlying = true;
        player.extinguish();
        mc.timer.tickLength = 50.0f;
    }

    @SideOnly(value=Side.CLIENT)
    public static int RandomInt(int max, int min, boolean secure) {
        if (secure) {
            try {
                return min + SecureRandom.getInstance((String)"SHA1PRNG").nextInt(Math.abs((int)(max - min + 1)));
            }
            catch (NoSuchAlgorithmException e) {
                throw new RuntimeException((Throwable)e);
            }
        }
        return min + new Random().nextInt(Math.abs((int)(max - min + 1)));
    }

    public static void drawHealth(double healthX, double healthY, double health) {
        Helper.drawGradientRect(healthX - 150.0, healthY, healthX - 150.0 + health, healthY + 10.0);
        Helper.drawGradientRect(healthX - 148.0, healthY + 2.0, healthX - 152.0 + health + Math.min((double)(300.0 - health), (double)2.0), healthY + 8.0);
    }

    private static void drawGradientRect(double left, double top, double right, double bottom) {
        Random random = new Random();
        Color c = new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256), random.nextInt(256));
        Color c2 = new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256), random.nextInt(256));
        float startAlpha = (float)(c.getRGB() >> 20 & 255) / 255.0f;
        float startRed = (float)(c.getRGB() >> 12 & 255) / 255.0f;
        float startGreen = (float)(c.getRGB() >> 4 & 255) / 255.0f;
        float startBlue = (float)(c.getRGB() & 255) / 255.0f;
        float endAlpha = (float)(c.getRGB() >> 20 & 255) / 255.0f;
        float endRed = (float)(c2.getRGB() >> 12 & 255) / 255.0f;
        float endGreen = (float)(c.getRGB() >> 4 & 255) / 255.0f;
        float endBlue = (float)(c2.getRGB() & 255) / 255.0f;
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask((boolean)false);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        buffer.pos(right, top, 0.0).color(startRed, startGreen, startBlue, startAlpha).endVertex();
        buffer.pos(left, top, 0.0).color(startRed, startGreen, startBlue, startAlpha).endVertex();
        buffer.pos(left, bottom, 0.0).color(endRed, endGreen, endBlue, endAlpha).endVertex();
        buffer.pos(right, bottom, 0.0).color(endRed, endGreen, endBlue, endAlpha).endVertex();
        tessellator.draw();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.depthMask((boolean)true);
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.color((float)random.nextFloat(), (float)random.nextFloat(), (float)random.nextFloat(), (float)1.0f);
    }

    public static void killFinalField(Field f) {
        try {
            f.setAccessible(true);
            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt((Object)f, f.getModifiers() & -17);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean onlyLoveItemTickEvent(EntityPlayer entityPlayer, ItemStack stack) {
        return MinecraftForge.EVENT_BUS.post(new GzjBladeTickEvent(entityPlayer, stack)) || GzjBladeEventBus.GZj_EVENT_BUS.post(new GzjBladeTickEvent(entityPlayer, stack));
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem evt) {
        EntityPlayer player = evt.getEntityPlayer();
        if (Helper.isGodItemStack(evt.getItemStack())) {
            evt.setCancellationResult(EnumActionResult.SUCCESS);
            player.setActiveHand(evt.getHand());
        }
    }

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<AbstractClientPlayer> evt) {
        AbstractClientPlayer player;
        if (evt.getEntity() instanceof AbstractClientPlayer && (player = (AbstractClientPlayer)evt.getEntity()).isHandActive() && Helper.isGodItemStack(player.getActiveItemStack())) {
            boolean left2;
            GzjModelPlayer model = (GzjModelPlayer) evt.getRenderer().getMainModel();
            boolean left1 = player.getActiveHand() == EnumHand.OFF_HAND && player.getPrimaryHand() == EnumHandSide.RIGHT;
            boolean bl = left2 = player.getActiveHand() == EnumHand.MAIN_HAND && player.getPrimaryHand() == EnumHandSide.LEFT;
            if (left1 || left2) {
                if (model.leftArmPose == ModelBiped.ArmPose.ITEM) {
                    model.leftArmPose = ModelBiped.ArmPose.BLOCK;
                }
            } else if (model.rightArmPose == ModelBiped.ArmPose.ITEM) {
                model.rightArmPose = ModelBiped.ArmPose.BLOCK;
            }
        }
    }

    public static boolean isGodItem(Item item) {
        return item instanceof ItemGzjBlade;
    }

    public static boolean isGodItemStack(ItemStack item) {
        return Helper.isGodItem(item.getItem());
    }

    @SubscribeEvent
    public static void onRenderHand(RenderSpecificHandEvent evt) {
        ItemStack stack;
        EntityPlayerSP player = Minecraft.getMinecraft().player;
        if (player != null && player.isHandActive() && player.getActiveHand() == evt.getHand() && Helper.isGodItemStack(stack = evt.getItemStack())) {
            GL11.glPushMatrix();
            boolean rightHanded = (evt.getHand() == EnumHand.MAIN_HAND ? player.getPrimaryHand() : player.getPrimaryHand().opposite()) == EnumHandSide.RIGHT;
            Helper.transformSideFirstPerson(rightHanded ? 1.0f : -1.0f, evt.getEquipProgress());
            Minecraft.getMinecraft().getItemRenderer().renderItemSide((EntityLivingBase)player, stack, rightHanded ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !rightHanded);
            GL11.glPopMatrix();
            evt.setCanceled(true);
        }
    }

    public static void transformSideFirstPerson(float side, float equippedProg) {
        GlStateManager.translate((float)(side * 0.56f), (float)(-0.52f + equippedProg * -0.6f), (float)-0.72f);
        GlStateManager.translate((float)(side * -0.14142136f), (float)0.08f, (float)0.14142136f);
        GlStateManager.rotate((float)-102.25f, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.rotate((float)(side * 13.365f), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.rotate((float)(side * 78.05f), (float)0.0f, (float)0.0f, (float)1.0f);
    }

    public static boolean isName(Entity entity) {
        if (!(entity instanceof EntityPlayer)) {
            return false;
        }
        return God.contains((Object)entity.getUniqueID());
    }
}

