/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Random
 *  net.minecraft.util.text.TextFormatting
 */
package com.example.examplemod.util;

import net.minecraft.util.text.TextFormatting;

import java.util.Random;

public final class TextUtil {
    public static final TextFormatting[] Rainbow = new TextFormatting[]{TextFormatting.RED, TextFormatting.GOLD, TextFormatting.YELLOW, TextFormatting.GREEN, TextFormatting.AQUA, TextFormatting.BLUE, TextFormatting.LIGHT_PURPLE};
    public static final TextFormatting[] Golden = new TextFormatting[]{TextFormatting.GOLD, TextFormatting.GOLD, TextFormatting.GOLD, TextFormatting.GOLD, TextFormatting.GOLD, TextFormatting.YELLOW, TextFormatting.WHITE, TextFormatting.YELLOW};
    public static final TextFormatting[] Ice = new TextFormatting[]{TextFormatting.AQUA, TextFormatting.AQUA, TextFormatting.AQUA, TextFormatting.AQUA, TextFormatting.AQUA, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.BLUE};
    private static final TextFormatting[] colour = new TextFormatting[]{TextFormatting.AQUA, TextFormatting.BLUE, TextFormatting.DARK_AQUA, TextFormatting.DARK_BLUE, TextFormatting.DARK_GRAY, TextFormatting.DARK_PURPLE, TextFormatting.LIGHT_PURPLE};
    private static final TextFormatting[] sanic = new TextFormatting[]{TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.WHITE, TextFormatting.WHITE, TextFormatting.BLUE, TextFormatting.RED, TextFormatting.WHITE, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY, TextFormatting.GRAY};
    public static final TextFormatting[] Purple = new TextFormatting[]{TextFormatting.LIGHT_PURPLE, TextFormatting.DARK_PURPLE, TextFormatting.DARK_PURPLE, TextFormatting.DARK_PURPLE, TextFormatting.LIGHT_PURPLE, TextFormatting.LIGHT_PURPLE, TextFormatting.WHITE, TextFormatting.LIGHT_PURPLE};

    public static String formatting(String input, TextFormatting[] colours, double delay) {
        StringBuilder sb = new StringBuilder(input.length() * 3);
        if (delay <= 0.0) {
            delay = 0.001;
        }
        int offset = (int)Math.floor((double)((double)(System.currentTimeMillis() & 16383L) / delay)) % colours.length;
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            int col = (i + colours.length - offset) % colours.length;
            sb.append(colours[col].toString());
            sb.append(c);
        }
        return sb.toString();
    }

    public static String dataError(int length) {
        String str = "01";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; ++i) {
            int number = random.nextInt(2);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=,./;'[]<>?:~";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; ++i) {
            int number = random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static String Rainbow(String Input) {
        return TextUtil.formatting(Input, Rainbow, 80.0);
    }

    public static String Golden(String Input) {
        return TextUtil.formatting(Input, Golden, 80.0);
    }

    public static String Ice(String Input) {
        return TextUtil.formatting(Input, Ice, 80.0);
    }

    public static String makeColour(String input) {
        return TextUtil.formatting(input, colour, 80.0);
    }

    public static String makeSANIC(String input) {
        return TextUtil.formatting(input, sanic, 50.0);
    }

    public static String Purple(String input) {
        return TextUtil.formatting(input, Purple, 80.0);
    }
}

