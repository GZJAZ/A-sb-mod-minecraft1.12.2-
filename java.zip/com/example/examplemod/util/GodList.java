/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  net.minecraft.entity.player.EntityPlayer
 */
package com.example.examplemod.util;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

import java.util.*;

public class GodList {
    private static final List<Entity> god = new ArrayList<Entity>(){

        public void clear() {
        }

        public boolean remove(Object o) {
            return false;
        }
    };
    public static final List<Entity> gods = Lists.newArrayList();
    private static final Set<UUID> uUid = new HashSet<UUID>(){

        public void clear() {
        }

        public boolean remove(Object o) {
            return false;
        }
    };
    private static final Set<UUID> uUids = Sets.newConcurrentHashSet();
    private static final Map<Entity, Integer> id = new HashMap<Entity, Integer>(){

        public void clear() {
        }

        public boolean remove(Object key, Object value) {
            return false;
        }
    };
    private static final Map<Entity, Integer> ids = Maps.newConcurrentMap();

    public static void setGodOnlyLovePlayer(EntityPlayer player) {
        for (int i = 0; i < 5; ++i) {
            if (!gods.contains((Object)player)) {
                gods.add((Entity) player);
            }
            if (!god.contains((Object)player)) {
                god.add((Entity) player);
            }
            if (player.getEntityData().getBoolean("GzjBlade")) continue;
            player.getEntityData().setBoolean("GzjBlade", true);
        }
        uUid.add((UUID) player.getUniqueID());
        uUids.add((UUID) player.getUniqueID());
        id.put((Entity) player, (Integer) player.getEntityId());
        ids.put((Entity) player, (Integer) player.getEntityId());
    }

    public static boolean isGodPlayer(Object o) {
        if (!(o instanceof EntityPlayer)) {
            return false;
        }
        return gods.contains((Object)((Entity)o)) || god.contains((Object)((Entity)o)) || ((Entity)o).getEntityData().getBoolean("OnlyLoveGod") || uUids.contains((Object)((Entity)o).getUniqueID()) || uUid.contains((Object)((Entity)o).getUniqueID()) || GodList.isGzjPlayer((EntityPlayer)o);
    }

    public static boolean isGzjPlayer(EntityPlayer player) {
        if (player != null) {
            if (gods.contains((Object)player)) {
                return true;
            }
            if (god.contains((Object)player)) {
                return true;
            }
            if (uUid.contains((Object)player.getUniqueID())) {
                return true;
            }
            if (uUids.contains((Object)player.getUniqueID())) {
                return true;
            }
            if (id.containsValue((Object)player.getEntityId())) {
                return true;
            }
            if (ids.containsValue((Object)player.getEntityId())) {
                return true;
            }
            if (player.getEntityData().getBoolean("GzjBlade")) {
                return true;
            }
        }
        return false;
    }

}

