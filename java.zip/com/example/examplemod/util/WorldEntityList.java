/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  net.minecraft.entity.Entity
 */
package com.example.examplemod.util;

import java.util.List;
import net.minecraft.entity.Entity;

public class WorldEntityList
extends EntityList {
    public WorldEntityList(List<Entity> list) {
        super();
    }

    @Override
    public boolean add(Entity e) {
        if (EntityDeathList.list().contains((Object)e.getClass().getName())) {
            ModUtil.kill(e);
            return false;
        }
        return super.add(e);
    }

    @Override
    public boolean contains(Object o) {
        if (EntityDeathList.list().contains((Object)o.getClass().getName())) {
            ModUtil.kill((Entity)o);
            return false;
        }
        return super.contains(o);
    }

    @Override
    public Entity remove(int index) {
        Entity entity = null;
        try {
            entity = super.remove(index);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return entity;
    }

    @Override
    public boolean remove(Object o) {
        boolean bool = false;
        try {
            bool = super.remove(o);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return bool;
    }
}

