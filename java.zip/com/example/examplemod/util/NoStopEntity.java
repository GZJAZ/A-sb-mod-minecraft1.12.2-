/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 */
package com.example.examplemod.util;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class NoStopEntity {
    private static final Set<Integer> NoStopEntity = Collections.synchronizedSet((Set)new HashSet());

    public static boolean contains(String name) {
        return NoStopEntity.contains((Object)name.hashCode());
    }

    public static void append(String name) {
        NoStopEntity.add((Integer) name.hashCode());
    }
}

