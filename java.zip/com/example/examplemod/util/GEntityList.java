package com.example.examplemod.util;

import com.example.examplemod.entity.GzjFakePlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.*;

public final class GEntityList extends ArrayList<Entity> {
    public GEntityList(Collection<Entity> c) {
        super(c);
    }

    @Override
    public boolean remove(Object o) {
        if (o instanceof Entity) {
            if (GzjUtil.isGPlayer((Entity) o)) {
                return false;
            }
        }
        return super.remove(o);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        c.removeIf(GzjUtil::isGPlayer);
        return super.removeAll(c);
    }

    @Override
    public Entity remove(int index) {
        Entity entity = super.get(index);
        if (GzjUtil.isGPlayer(entity)) {
            return entity;
        }

        return super.remove(index);
    }

    @Override
    public boolean add(Entity e) {
        if (GzjUtil.isUltimateDead(e)) {
            return false;
        }

        return super.add(e);
    }

    @Override
    public void add(int index, Entity element) {
        if (GzjUtil.isUltimateDead(element)) {
            return;
        }

        super.add(index, element);
    }

    @Override
    public boolean addAll(Collection<? extends Entity> c) {
        c.removeIf(GzjUtil::isUltimateDead);
        return super.addAll(c);
    }

    @Override
    public boolean addAll(int index, Collection<? extends Entity> c) {
        c.removeIf(GzjUtil::isUltimateDead);
        return super.addAll(index, c);
    }

    @Override
    public Entity get(int index) {
        Entity entity = super.get(index);
        if (GzjUtil.isGPlayer(entity)) {
            Class<?> callerClass = StackLocatorUtil.getCallerClass(4);
            if (callerClass != World.class) {
                if (entity.world instanceof WorldServer) {
                    return GzjFakePlayer.getFakePlayer((EntityPlayerMP) entity);
                }
            }
        }
        return entity;
    }

    @Override
    public Iterator<Entity> iterator() {
        return new Itr();
    }

    @Override
    public ListIterator<Entity> listIterator() {
        return new ListItr(0);
    }

    @Override
    public ListIterator<Entity> listIterator(int index) {
        return new ListItr(index);
    }

    private class Itr implements Iterator<Entity> {
        int cursor; // index of next element to return
        int lastRet = -1; // index of last element returned; -1 if no such
        int expectedModCount = modCount;

        Itr() {
        }

        public boolean hasNext() {
            return cursor != size();
        }

        public Entity next() {
            checkForComodification();
            int i = cursor;
            cursor = i + 1;
            return GEntityList.this.get(lastRet = i);
        }

        public void remove() {
            if (lastRet < 0)
                throw new IllegalStateException();
            checkForComodification();

            try {
                GEntityList.this.remove(lastRet);
                cursor = lastRet;
                lastRet = -1;
                expectedModCount = modCount;
            } catch (IndexOutOfBoundsException ex) {
                throw new ConcurrentModificationException();
            }
        }

        final void checkForComodification() {
            if (modCount != expectedModCount)
                throw new ConcurrentModificationException();
        }
    }

    /**
     * An optimized version of AbstractList.ListItr
     */
    private class ListItr extends Itr implements ListIterator<Entity> {
        ListItr(int index) {
            super();
            cursor = index;
        }

        public boolean hasPrevious() {
            return cursor != 0;
        }

        public int nextIndex() {
            return cursor;
        }

        public int previousIndex() {
            return cursor - 1;
        }

        public Entity previous() {
            checkForComodification();
            int i = cursor - 1;
            cursor = i;
            return GEntityList.this.get(lastRet = i);
        }

        public void set(Entity e) {
            if (lastRet < 0)
                throw new IllegalStateException();
            checkForComodification();

            try {
                GEntityList.this.set(lastRet, e);
            } catch (IndexOutOfBoundsException ex) {
                throw new ConcurrentModificationException();
            }
        }

        public void add(Entity e) {
            checkForComodification();

            try {
                int i = cursor;
                GEntityList.this.add(i, e);
                cursor = i + 1;
                lastRet = -1;
                expectedModCount = modCount;
            } catch (IndexOutOfBoundsException ex) {
                throw new ConcurrentModificationException();
            }
        }
    }
}
