/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  net.minecraft.util.text.TextFormatting
 */
package com.example.examplemod.util;

import net.minecraft.util.text.TextFormatting;

public class ColorText {
    private static final TextFormatting[] colour = new TextFormatting[]{TextFormatting.RED, TextFormatting.GOLD, TextFormatting.YELLOW, TextFormatting.GREEN, TextFormatting.AQUA, TextFormatting.BLUE, TextFormatting.LIGHT_PURPLE};

    public static String formatting(String input, TextFormatting[] colours, double delay) {
        StringBuilder sb = new StringBuilder(input.length() * 3);
        if (delay <= 0.0) {
            delay = 0.001;
        }
        int offset = (int)Math.floor((double)((double)(System.currentTimeMillis() & 16383L) / delay)) % colours.length;
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            sb.append(colours[(colours.length + i - offset) % colours.length].toString());
            sb.append(c);
        }
        return sb.toString();
    }

    public static String setColour(String input) {
        return ColorText.formatting(input, colour, 70.0);
    }
}

