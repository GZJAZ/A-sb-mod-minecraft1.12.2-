package com.chaoswither.event;

public class OtherItemUpdateEvent {
}
