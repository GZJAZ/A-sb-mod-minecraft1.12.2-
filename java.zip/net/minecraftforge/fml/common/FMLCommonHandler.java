/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  io.netty.channel.Channel
 *  io.netty.util.Attribute
 *  io.netty.util.AttributeKey
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.ThreadGroup
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.nio.charset.Charset
 *  java.nio.charset.StandardCharsets
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Properties
 *  java.util.Set
 *  java.util.concurrent.ConcurrentMap
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.FutureTask
 *  java.util.concurrent.TimeUnit
 *  javax.annotation.Nullable
 *  net.minecraft.crash.CrashReport
 *  net.minecraft.crash.CrashReportCategory
 *  net.minecraft.crash.ICrashReportDetail
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.network.EnumConnectionState
 *  net.minecraft.network.INetHandler
 *  net.minecraft.network.NetworkManager
 *  net.minecraft.network.Packet
 *  net.minecraft.network.handshake.client.C00Handshake
 *  net.minecraft.network.login.server.SPacketDisconnect
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.IThreadListener
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentString
 *  net.minecraft.world.storage.SaveHandler
 *  net.minecraft.world.storage.WorldInfo
 *  net.minecraftforge.client.model.animation.Animation
 *  net.minecraftforge.common.ForgeVersion
 *  net.minecraftforge.common.util.CompoundDataFixer
 *  net.minecraftforge.fml.common.FMLLog
 *  net.minecraftforge.fml.common.ICrashCallable
 *  net.minecraftforge.fml.common.IFMLSidedHandler
 *  net.minecraftforge.fml.common.InjectedModContainer
 *  net.minecraftforge.fml.common.Loader
 *  net.minecraftforge.fml.common.ModContainer
 *  net.minecraftforge.fml.common.ObfuscationReflectionHelper
 *  net.minecraftforge.fml.common.StartupQuery
 *  net.minecraftforge.fml.common.WorldAccessContainer
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  net.minecraftforge.fml.common.gameevent.InputEvent
 *  net.minecraftforge.fml.common.gameevent.InputEvent$KeyInputEvent
 *  net.minecraftforge.fml.common.gameevent.InputEvent$MouseInputEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemCraftedEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemPickupEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemSmeltedEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$PlayerChangedDimensionEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$PlayerLoggedInEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$PlayerLoggedOutEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$PlayerRespawnEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$Phase
 *  net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$RenderTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ServerTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$WorldTickEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent$ServerConnectionFromClientEvent
 *  net.minecraftforge.fml.common.network.NetworkRegistry
 *  net.minecraftforge.fml.common.thread.SidedThreadGroup
 *  net.minecraftforge.fml.relauncher.CoreModManager
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.server.FMLServerHandler
 *  org.apache.commons.io.IOUtils
 */
package net.minecraftforge.fml.common;

import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.MapMaker;
import com.google.common.collect.Maps;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.ref.WeakReference;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.INetHandler;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.server.SPacketDisconnect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.storage.SaveHandler;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.client.model.animation.Animation;
import net.minecraftforge.common.ForgeVersion;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.CompoundDataFixer;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.thread.SidedThreadGroup;
import net.minecraftforge.fml.relauncher.CoreModManager;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.server.FMLServerHandler;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;

public class FMLCommonHandler {
    private static final FMLCommonHandler INSTANCE = new FMLCommonHandler();
    private IFMLSidedHandler sidedDelegate;
    private boolean noForge;
    private List<String> brandings;
    private List<String> brandingsNoMC;
    private List<ICrashCallable> crashCallables = Lists.newArrayList(new ICrashCallable[]{Loader.instance().getCallableCrashInformation()});
    private Set<SaveHandler> handlerSet = Collections.newSetFromMap(new MapMaker().weakKeys().makeMap());
    private WeakReference<SaveHandler> handlerToCheck;
    public EventBus eventBus = MinecraftForge.EVENT_BUS;
    private volatile CountDownLatch exitLatch = null;

    private FMLCommonHandler() {
        this.registerCrashCallable(new ICrashCallable(){

            public String call() throws Exception {
                StringBuilder builder = new StringBuilder();
                Joiner joiner = Joiner.on("\n  ");
                for (String coreMod : CoreModManager.getTransformers().keySet()) {
                    builder.append("\n" + coreMod + "\n  ").append(joiner.join((Iterable)CoreModManager.getTransformers().get((Object)coreMod)));
                }
                return builder.toString();
            }

            public String getLabel() {
                return "Loaded coremods (and transformers)";
            }
        });
    }

    @Deprecated
    public EventBus bus() {
        return this.eventBus;
    }

    public List<String> beginLoading(IFMLSidedHandler handler) {
        this.sidedDelegate = handler;
        MinecraftForge.initialize();
        return ImmutableList.of();
    }

    public static FMLCommonHandler instance() {
        return INSTANCE;
    }

    public ModContainer findContainerFor(Object mod) {
        if (mod instanceof String) {
            return (ModContainer)Loader.instance().getIndexedModList().get(mod);
        }
        return (ModContainer)Loader.instance().getReversedModObjectList().get(mod);
    }

    @Deprecated
    public Logger getFMLLogger() {
        return FMLLog.log;
    }

    public Side getSide() {
        return this.sidedDelegate.getSide();
    }

    public Side getEffectiveSide() {
        ThreadGroup group = Thread.currentThread().getThreadGroup();
        return group instanceof SidedThreadGroup ? ((SidedThreadGroup)group).getSide() : Side.CLIENT;
    }

    public void raiseException(Throwable exception, String message, boolean stopGame) {
        FMLLog.log.error("Something raised an exception. The message was '{}'. 'stopGame' is {}", (Object)message, (Object)stopGame, (Object)exception);
        if (stopGame) {
            this.getSidedDelegate().haltGame(message, exception);
        }
    }

    public void computeBranding() {
        if (this.brandings == null) {
            ImmutableList.Builder brd = ImmutableList.builder();
            brd.add(Loader.instance().getMCVersionString());
            brd.add(Loader.instance().getMCPVersionString());
            brd.add("Powered by Forge " + ForgeVersion.getVersion());
            if (this.sidedDelegate != null) {
                brd.addAll((Iterable)this.sidedDelegate.getAdditionalBrandingInformation());
            }
            if (Loader.instance().getFMLBrandingProperties().containsKey((Object)"fmlbranding")) {
                brd.add(Loader.instance().getFMLBrandingProperties().get((Object)"fmlbranding"));
            }
            int tModCount = Loader.instance().getModList().size();
            int aModCount = Loader.instance().getActiveModList().size();
            brd.add(String.format((String)"%d mod%s loaded, %d mod%s active", (Object[])new Object[]{tModCount, tModCount != 1 ? "s" : "", aModCount, aModCount != 1 ? "s" : ""}));
            this.brandings = brd.build();
            this.brandingsNoMC = this.brandings.subList(1, this.brandings.size());
        }
    }

    public List<String> getBrandings(boolean includeMC) {
        if (this.brandings == null) {
            this.computeBranding();
        }
        return includeMC ? ImmutableList.copyOf(this.brandings) : ImmutableList.copyOf(this.brandingsNoMC);
    }

    public IFMLSidedHandler getSidedDelegate() {
        return this.sidedDelegate;
    }

    public void onPostServerTick() {
        this.bus().post((Event)new TickEvent.ServerTickEvent(TickEvent.Phase.END));
    }

    public void onPostWorldTick(World world) {
        this.bus().post((Event)new TickEvent.WorldTickEvent(Side.SERVER, TickEvent.Phase.END, world));
    }

    public void onPreServerTick() {
        this.bus().post((Event)new TickEvent.ServerTickEvent(TickEvent.Phase.START));
    }

    public void onPreWorldTick(World world) {
        this.bus().post((Event)new TickEvent.WorldTickEvent(Side.SERVER, TickEvent.Phase.START, world));
    }

    public boolean handleServerAboutToStart(MinecraftServer server) {
        return Loader.instance().serverAboutToStart((Object)server);
    }

    public boolean handleServerStarting(MinecraftServer server) {
        return Loader.instance().serverStarting((Object)server);
    }

    public void handleServerStarted() {
        Loader.instance().serverStarted();
        this.sidedDelegate.allowLogins();
    }

    public void handleServerStopping() {
        Loader.instance().serverStopping();
    }

    public File getSavesDirectory() {
        return this.sidedDelegate.getSavesDirectory();
    }

    public MinecraftServer getMinecraftServerInstance() {
        return this.sidedDelegate.getServer();
    }

    public void showGuiScreen(Object clientGuiElement) {
        this.sidedDelegate.showGuiScreen(clientGuiElement);
    }

    public void queryUser(StartupQuery query) throws InterruptedException {
        this.sidedDelegate.queryUser(query);
    }

    public void onServerStart(MinecraftServer dedicatedServer) {
        FMLServerHandler.instance();
        this.sidedDelegate.beginServerLoading(dedicatedServer);
    }

    public void onServerStarted() {
        this.sidedDelegate.finishServerLoading();
    }

    public void onPreClientTick() {
        this.bus().post((Event)new TickEvent.ClientTickEvent(TickEvent.Phase.START));
    }

    public void onPostClientTick() {
        this.bus().post((Event)new TickEvent.ClientTickEvent(TickEvent.Phase.END));
    }

    public void onRenderTickStart(float timer) {
        Animation.setClientPartialTickTime((float)timer);
        this.bus().post((Event)new TickEvent.RenderTickEvent(TickEvent.Phase.START, timer));
    }

    public void onRenderTickEnd(float timer) {
        this.bus().post((Event)new TickEvent.RenderTickEvent(TickEvent.Phase.END, timer));
    }

    public void onPlayerPreTick(EntityPlayer player) {
        this.bus().post((Event)new TickEvent.PlayerTickEvent(TickEvent.Phase.START, player));
    }

    public void onPlayerPostTick(EntityPlayer player) {
        this.bus().post((Event)new TickEvent.PlayerTickEvent(TickEvent.Phase.END, player));
    }

    public void registerCrashCallable(ICrashCallable callable) {
        this.crashCallables.add((ICrashCallable) callable);
    }

    public void enhanceCrashReport(CrashReport crashReport, CrashReportCategory category) {
        for (ICrashCallable call : this.crashCallables) {
            category.addDetail(call.getLabel(), (ICrashReportDetail)call);
        }
    }

    public void handleWorldDataSave(SaveHandler handler, WorldInfo worldInfo, NBTTagCompound tagCompound) {
        for (ModContainer mc : Loader.instance().getModList()) {
            WorldAccessContainer wac;
            if (!(mc instanceof InjectedModContainer) || (wac = ((InjectedModContainer)mc).getWrappedWorldAccessContainer()) == null) continue;
            NBTTagCompound dataForWriting = wac.getDataForWriting(handler, worldInfo);
            tagCompound.setTag(mc.getModId(), dataForWriting);
        }
    }

    public void handleWorldDataLoad(SaveHandler handler, WorldInfo worldInfo, NBTTagCompound tagCompound) {
        if (this.getEffectiveSide() != Side.SERVER) {
            return;
        }
        if (this.handlerSet.contains((Object)handler)) {
            return;
        }
        this.handlerSet.add((SaveHandler) handler);
        this.handlerToCheck = new WeakReference((Object)handler);
        HashMap additionalProperties = Maps.newHashMap();
        worldInfo.setAdditionalProperties(additionalProperties);
        for (ModContainer mc : Loader.instance().getModList()) {
            WorldAccessContainer wac;
            if (!(mc instanceof InjectedModContainer) || (wac = ((InjectedModContainer)mc).getWrappedWorldAccessContainer()) == null) continue;
            wac.readData(handler, worldInfo, additionalProperties, tagCompound.getCompoundTag(mc.getModId()));
        }
    }

    public void confirmBackupLevelDatUse(SaveHandler handler) {
        if (this.handlerToCheck == null || this.handlerToCheck.get() != handler) {
            this.handlerToCheck = null;
            return;
        }
        String text = "Forge Mod Loader detected that the backup level.dat is being used.\n\nThis may happen due to a bug or corruption, continuing can damage\nyour world beyond repair or lose data / progress.\n\nIt's recommended to create a world backup before continuing.";
        boolean confirmed = StartupQuery.confirm((String)text);
        if (!confirmed) {
            StartupQuery.abort();
        }
    }

    public boolean isDisplayCloseRequested() {
        return this.sidedDelegate != null && this.sidedDelegate.isDisplayCloseRequested();
    }

    public boolean shouldServerBeKilledQuietly() {
        if (this.sidedDelegate == null) {
            return false;
        }
        return this.sidedDelegate.shouldServerShouldBeKilledQuietly();
    }

    public void expectServerStopped() {
        this.exitLatch = new CountDownLatch(1);
    }

    public void handleExit(int retVal) {
        CountDownLatch latch = this.exitLatch;
        if (latch != null) {
            try {
                FMLLog.log.info("Waiting for the server to terminate/save.");
                if (!latch.await(10L, TimeUnit.SECONDS)) {
                    FMLLog.log.warn("The server didn't stop within 10 seconds, exiting anyway.");
                } else {
                    FMLLog.log.info("Server terminated.");
                }
            }
            catch (InterruptedException e) {
                FMLLog.log.warn("Interrupted wait, exiting.");
            }
        }
        System.exit((int)retVal);
    }

    public void handleServerStopped() {
        CountDownLatch latch;
        this.sidedDelegate.serverStopped();
        MinecraftServer server = this.getMinecraftServerInstance();
        Loader.instance().serverStopped();
        if (server != null)
        if ((latch = this.exitLatch) != null) {
            latch.countDown();
            this.exitLatch = null;
        }
    }

    public String getModName() {
        ArrayList modNames = Lists.newArrayListWithExpectedSize(3);
        modNames.add((Object)"fml");
        if (!this.noForge) {
            modNames.add((Object)"forge");
        }
        if (Loader.instance().getFMLBrandingProperties().containsKey((Object)"snooperbranding")) {
            modNames.add(Loader.instance().getFMLBrandingProperties().get((Object)"snooperbranding"));
        }
        return Joiner.on(',').join((Iterable<?>)modNames);
    }

    public void addModToResourcePack(ModContainer container) {
        this.sidedDelegate.addModAsResource(container);
    }

    public String getCurrentLanguage() {
        return this.sidedDelegate.getCurrentLanguage();
    }

    public void bootstrap() {
    }

    public NetworkManager getClientToServerNetworkManager() {
        return this.sidedDelegate.getClientToServerNetworkManager();
    }

    public void fireMouseInput() {
        this.bus().post((Event)new InputEvent.MouseInputEvent());
    }

    public void fireKeyInput() {
        this.bus().post((Event)new InputEvent.KeyInputEvent());
    }

    public void firePlayerChangedDimensionEvent(EntityPlayer player, int fromDim, int toDim) {
        this.bus().post((Event)new PlayerEvent.PlayerChangedDimensionEvent(player, fromDim, toDim));
    }

    public void firePlayerLoggedIn(EntityPlayer player) {
        this.bus().post((Event)new PlayerEvent.PlayerLoggedInEvent(player));
    }

    public void firePlayerLoggedOut(EntityPlayer player) {
        this.bus().post((Event)new PlayerEvent.PlayerLoggedOutEvent(player));
    }

    public void firePlayerRespawnEvent(EntityPlayer player, boolean endConquered) {
        this.bus().post((Event)new PlayerEvent.PlayerRespawnEvent(player, endConquered));
    }

    public void firePlayerItemPickupEvent(EntityPlayer player, EntityItem item, ItemStack clone) {
        this.bus().post((Event)new PlayerEvent.ItemPickupEvent(player, item, clone));
    }

    public void firePlayerCraftingEvent(EntityPlayer player, ItemStack crafted, IInventory craftMatrix) {
        this.bus().post((Event)new PlayerEvent.ItemCraftedEvent(player, crafted, craftMatrix));
    }

    public void firePlayerSmeltedEvent(EntityPlayer player, ItemStack smelted) {
        this.bus().post((Event)new PlayerEvent.ItemSmeltedEvent(player, smelted));
    }

    public INetHandler getClientPlayHandler() {
        return this.sidedDelegate.getClientPlayHandler();
    }

    public void fireNetRegistrationEvent(NetworkManager manager, Set<String> channelSet, String channel, Side side) {
        this.sidedDelegate.fireNetRegistrationEvent(this.bus(), manager, channelSet, channel, side);
    }

    public boolean shouldAllowPlayerLogins() {
        return this.sidedDelegate.shouldAllowPlayerLogins();
    }

    public void fireServerConnectionEvent(NetworkManager manager) {
        this.bus().post((Event)new FMLNetworkEvent.ServerConnectionFromClientEvent(manager));
    }

    public boolean handleServerHandshake(C00Handshake packet, NetworkManager manager) {
        if (!this.shouldAllowPlayerLogins()) {
            TextComponentString text = new TextComponentString("Server is still starting! Please wait before reconnecting.");
            FMLLog.log.info("Disconnecting Player: {}", (Object)text.getUnformattedText());
            manager.sendPacket((Packet)new SPacketDisconnect((ITextComponent)text));
            manager.closeChannel((ITextComponent)text);
            return false;
        }
        if (packet.getRequestedState() == EnumConnectionState.LOGIN && !NetworkRegistry.INSTANCE.isVanillaAccepted(Side.CLIENT) && !packet.hasFMLMarker()) {
            manager.setConnectionState(EnumConnectionState.LOGIN);
            TextComponentString text = new TextComponentString("This server has mods that require FML/Forge to be installed on the client. Contact your server admin for more details.");
            Collection modNames = NetworkRegistry.INSTANCE.getRequiredMods(Side.CLIENT);
            FMLLog.log.info("Disconnecting Player: This server has mods that require FML/Forge to be installed on the client: {}", (Object)modNames);
            manager.sendPacket((Packet)new SPacketDisconnect((ITextComponent)text));
            manager.closeChannel((ITextComponent)text);
            return false;
        }
        manager.channel().attr(NetworkRegistry.FML_MARKER).set((Boolean) packet.hasFMLMarker());
        return true;
    }

    public void processWindowMessages() {
        if (this.sidedDelegate == null) {
            return;
        }
        this.sidedDelegate.processWindowMessages();
    }

    public void exitJava(int exitCode, boolean hardExit) {
        FMLLog.log.warn("Java has been asked to exit (code {})", (Object)exitCode);
        if (hardExit) {
            FMLLog.log.warn("This is an abortive exit and could cause world corruption or other things");
        }
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        FMLLog.log.warn("Exit trace:");
        for (int i = 2; i < stack.length; ++i) {
            FMLLog.log.warn("\t{}", (Object)stack[i]);
        }
        if (hardExit) {
            Runtime.getRuntime().halt(exitCode);
        } else {
            Runtime.getRuntime().exit(exitCode);
        }
    }

    public IThreadListener getWorldThread(INetHandler net) {
        return this.sidedDelegate.getWorldThread(net);
    }

    public static void callFuture(FutureTask<?> task) {
        try {
            task.run();
            task.get();
        }
        catch (InterruptedException | ExecutionException e) {
            FMLLog.log.fatal("Exception caught executing FutureTask: {}", (Object)e.toString(), (Object)e);
        }
    }

    @Nullable
    public InputStream loadLanguage(Map<String, String> table, InputStream inputstream) throws IOException {
        byte[] data = IOUtils.toByteArray((InputStream)inputstream);
        boolean isEnhanced = false;
        for (String line : IOUtils.readLines((InputStream)new ByteArrayInputStream(data), (Charset)StandardCharsets.UTF_8)) {
            if (line.isEmpty() || line.charAt(0) != '#' || !(line = line.substring(1).trim()).equals((Object)"PARSE_ESCAPES")) continue;
            isEnhanced = true;
            break;
        }
        if (!isEnhanced) {
            return new ByteArrayInputStream(data);
        }
        Properties props = new Properties();
        props.load((Reader)new InputStreamReader((InputStream)new ByteArrayInputStream(data), StandardCharsets.UTF_8));
        for (Map.Entry e : props.entrySet()) {
            table.put((String) e.getKey(), (String) e.getValue());
        }
        props.clear();
        return null;
    }

    public String stripSpecialChars(String message) {
        return this.sidedDelegate != null ? this.sidedDelegate.stripSpecialChars(message) : message;
    }

    public void reloadRenderers() {
        this.sidedDelegate.reloadRenderers();
    }

    public void fireSidedRegistryEvents() {
        this.sidedDelegate.fireSidedRegistryEvents();
    }

    public CompoundDataFixer getDataFixer() {
        return this.sidedDelegate.getDataFixer();
    }

    public boolean isDisplayVSyncForced() {
        return this.sidedDelegate.isDisplayVSyncForced();
    }

    public void resetClientRecipeBook() {
        this.sidedDelegate.resetClientRecipeBook();
    }

    public void reloadSearchTrees() {
        this.sidedDelegate.reloadSearchTrees();
    }

    public void reloadCreativeSettings() {
        this.sidedDelegate.reloadCreativeSettings();
    }

}

