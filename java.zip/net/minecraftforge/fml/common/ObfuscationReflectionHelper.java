//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package net.minecraftforge.fml.common;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.annotation.Nullable;
import net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.objectweb.asm.Type;

public class ObfuscationReflectionHelper {
    public ObfuscationReflectionHelper() {
    }

    /** @deprecated */
    @Deprecated
    public static <T, E> T getPrivateValue(Class<? super E> classToAccess, E instance, int fieldIndex) {
        try {
            return ReflectionHelper.getPrivateValue(classToAccess, instance, fieldIndex);
        } catch (ReflectionHelper.UnableToAccessFieldException var4) {
            FMLLog.log.error("There was a problem getting field index {} from {}", fieldIndex, classToAccess.getName(), var4);
            throw var4;
        }
    }

    /** @deprecated */
    @Deprecated
    public static String[] remapFieldNames(String className, String... fieldNames) {
        String internalClassName = FMLDeobfuscatingRemapper.INSTANCE.unmap(className.replace('.', '/'));
        String[] mappedNames = new String[fieldNames.length];
        int i = 0;
        String[] var5 = fieldNames;
        int var6 = fieldNames.length;

        for(int var7 = 0; var7 < var6; ++var7) {
            String fName = var5[var7];
            mappedNames[i++] = FMLDeobfuscatingRemapper.INSTANCE.mapFieldName(internalClassName, fName, (String)null);
        }

        return mappedNames;
    }

    private static String remapFieldName(Class<?> clazz, String fieldName) {
        String internalClassName = FMLDeobfuscatingRemapper.INSTANCE.unmap(Type.getInternalName(clazz));
        return FMLDeobfuscatingRemapper.INSTANCE.mapFieldName(internalClassName, fieldName, (String)null);
    }

    private static String remapMethodName(Class<?> clazz, String methodName, Class<?> returnType, Class<?>... parameterTypes) {
        String internalClassName = FMLDeobfuscatingRemapper.INSTANCE.unmap(Type.getInternalName(clazz));
        Type[] params = (Type[])Arrays.stream(parameterTypes).map(Type::getType).toArray((x$0) -> {
            return new Type[x$0];
        });
        String desc = Type.getMethodDescriptor(Type.getType(returnType), params);
        return FMLDeobfuscatingRemapper.INSTANCE.mapMethodName(internalClassName, methodName, desc);
    }

    /** @deprecated */
    @Deprecated
    public static <T, E> T getPrivateValue(Class<? super E> classToAccess, E instance, String... fieldNames) {
        try {
            return ReflectionHelper.getPrivateValue(classToAccess, instance, remapFieldNames(classToAccess.getName(), fieldNames));
        } catch (ReflectionHelper.UnableToFindFieldException var4) {
            FMLLog.log.error("Unable to locate any field {} on type {}", Arrays.toString(fieldNames), classToAccess.getName(), var4);
            throw var4;
        } catch (ReflectionHelper.UnableToAccessFieldException var5) {
            FMLLog.log.error("Unable to access any field {} on type {}", Arrays.toString(fieldNames), classToAccess.getName(), var5);
            throw var5;
        }
    }

    public static <T, E> T getPrivateValue(Class<? super E> classToAccess, @Nullable E instance, String srgName) {
        return ReflectionHelper.getPrivateValue(classToAccess, instance, remapFieldName(classToAccess, srgName), (String)null);
    }

    /** @deprecated */
    @Deprecated
    public static <T, E> void setPrivateValue(Class<? super T> classToAccess, T instance, E value, int fieldIndex) {
        try {
            ReflectionHelper.setPrivateValue(classToAccess, instance, value, fieldIndex);
        } catch (ReflectionHelper.UnableToAccessFieldException var5) {
            FMLLog.log.error("There was a problem setting field index {} on type {}", fieldIndex, classToAccess.getName(), var5);
            throw var5;
        }
    }

    /** @deprecated */
    @Deprecated
    public static <T, E> void setPrivateValue(Class<? super T> classToAccess, T instance, E value, String... fieldNames) {
        try {
            ReflectionHelper.setPrivateValue(classToAccess, instance, value, remapFieldNames(classToAccess.getName(), fieldNames));
        } catch (ReflectionHelper.UnableToFindFieldException var5) {
            FMLLog.log.error("Unable to locate any field {} on type {}", Arrays.toString(fieldNames), classToAccess.getName(), var5);
            throw var5;
        } catch (ReflectionHelper.UnableToAccessFieldException var6) {
            FMLLog.log.error("Unable to set any field {} on type {}", Arrays.toString(fieldNames), classToAccess.getName(), var6);
            throw var6;
        }
    }

    public static <T, E> void setPrivateValue(Class<? super T> classToAccess, @Nullable T instance, @Nullable E value, String srgName) {
        ReflectionHelper.setPrivateValue(classToAccess, instance, value, remapFieldName(classToAccess, srgName), (String)null);
    }

    public static Field findField(Class<?> clazz, String srgName) {
        return ReflectionHelper.findField(clazz, remapFieldName(clazz, srgName), (String)null);
    }

    public static Method findMethod(Class<?> clazz, String srgName, Class<?> returnType, Class<?>... parameterTypes) {
        String mappedName = remapMethodName(clazz, srgName, returnType, parameterTypes);
        return ReflectionHelper.findMethod(clazz, mappedName, (String)null, parameterTypes);
    }

    public static <T> Constructor<T> findConstructor(Class<T> klass, Class<?>... parameterTypes) {
        return ReflectionHelper.findConstructor(klass, parameterTypes);
    }
}
