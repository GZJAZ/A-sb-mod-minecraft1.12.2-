/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.ArrayList
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ConcurrentMap
 *  java.util.function.Function
 *  javax.annotation.Nonnull
 *  net.minecraftforge.fml.common.FMLLog
 *  net.minecraftforge.fml.common.Loader
 *  net.minecraftforge.fml.common.MinecraftDummyContainer
 *  net.minecraftforge.fml.common.ModContainer
 *  net.minecraftforge.fml.common.eventhandler.ASMEventHandler
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.IContextSetter
 *  net.minecraftforge.fml.common.eventhandler.IEventExceptionHandler
 *  net.minecraftforge.fml.common.eventhandler.IEventListener
 *  net.minecraftforge.fml.common.eventhandler.IGenericEvent
 *  net.minecraftforge.fml.common.eventhandler.ListenerList
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package net.minecraftforge.fml.common.eventhandler;

import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.collect.MapMaker;
import com.google.common.collect.Sets;
import com.google.common.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;
import javax.annotation.Nonnull;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.MinecraftDummyContainer;
import net.minecraftforge.fml.common.ModContainer;
import net.minecraftforge.fml.common.eventhandler.ASMEventHandler;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.IContextSetter;
import net.minecraftforge.fml.common.eventhandler.IEventExceptionHandler;
import net.minecraftforge.fml.common.eventhandler.IEventListener;
import net.minecraftforge.fml.common.eventhandler.IGenericEvent;
import net.minecraftforge.fml.common.eventhandler.ListenerList;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.Logger;

public class EventBus
        implements IEventExceptionHandler {
    private static int maxID = 0;
    public ConcurrentHashMap<Object, ArrayList<IEventListener>> listeners = new ConcurrentHashMap();
    public Map<Object, ModContainer> listenerOwners = new MapMaker().weakKeys().weakValues().makeMap();
    public final int busID = maxID++;
    public IEventExceptionHandler exceptionHandler;
    private boolean shutdown;

    public EventBus() {
        ListenerList.resize((int)(this.busID + 1));
        this.exceptionHandler = this;
    }

    public EventBus(@Nonnull IEventExceptionHandler handler) {
        this();
        Preconditions.checkNotNull(handler, "EventBus exception handler can not be null");
        this.exceptionHandler = handler;
    }

    public void register(Object target) {
        boolean isStatic;
        if (this.listeners.containsKey(target)) {
            return;
        }
        ModContainer activeModContainer = Loader.instance().activeModContainer();
        if (activeModContainer == null) {
            FMLLog.log.error("Unable to determine registrant mod for {}. This is a critical error and should be impossible", target, (Object)new Throwable());
            activeModContainer = Loader.instance().getMinecraftModContainer();
        }
        this.listenerOwners.put(target, (ModContainer) activeModContainer);
        boolean bl = isStatic = target.getClass() == Class.class;
        Set supers = isStatic ? Sets.newHashSet(new Class[]{(Class)target}) : TypeToken.of(target.getClass()).getTypes().rawTypes();
        block2 : for (Method method : (isStatic ? (Class)target : target.getClass()).getMethods()) {
            if (isStatic && !Modifier.isStatic((int)method.getModifiers()) || !isStatic && Modifier.isStatic((int)method.getModifiers())) continue;
            for (Object cls : supers) {
                Method real = cls.getClass().getEnclosingMethod();
                if (!real.isAnnotationPresent(SubscribeEvent.class)) continue;
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length != 1) {
                    throw new IllegalArgumentException("Method " + (Object)method + " has @SubscribeEvent annotation, but requires " + parameterTypes.length + " arguments.  Event handler methods must require a single argument.");
                }
                Class eventType = parameterTypes[0];
                if (!Event.class.isAssignableFrom(eventType)) {
                    throw new IllegalArgumentException("Method " + (Object)method + " has @SubscribeEvent annotation, but takes a argument that is not an Event " + (Object)eventType);
                }
                this.register(eventType, target, real, activeModContainer);
                continue block2;
            }
        }
    }

    private void register(Class<?> eventType, Object target, Method method, final ModContainer owner) {
        try {
            ASMEventHandler asm;
            Constructor ctr = eventType.getConstructor(new Class[0]);
            ctr.setAccessible(true);
            Event event = (Event)ctr.newInstance(new Object[0]);
            Object listener = asm = new ASMEventHandler(target, method, owner, IGenericEvent.class.isAssignableFrom(eventType));
            if (IContextSetter.class.isAssignableFrom(eventType)) {
                listener = new IEventListener(){

                    public void invoke(Event event) {
                        ModContainer old = Loader.instance().activeModContainer();
                        Loader.instance().setActiveModContainer(owner);
                        ((IContextSetter)event).setModContainer(owner);
                        asm.invoke(event);
                        Loader.instance().setActiveModContainer(old);
                    }
                };
            }
            event.getListenerList().register(this.busID, asm.getPriority(), (IEventListener)listener);
            ArrayList others = (ArrayList)this.listeners.computeIfAbsent(target, k -> new ArrayList());
            others.add(listener);
        }
        catch (Exception e) {
            FMLLog.log.error("Error registering event handler: {} {} {}", (Object)owner, eventType, (Object)method, (Object)e);
        }
    }

    public void unregister(Object object) {
        ArrayList list = (ArrayList)this.listeners.remove(object);
        if (list == null) {
            return;
        }
        for (Object listener : list) {
            ListenerList.unregisterAll((int)this.busID, (IEventListener)listener);
        }
    }

    public boolean post(Event event) {
        int index = 0;
        if (this.shutdown) {
            return false;
        }
        IEventListener[] listeners = event.getListenerList().getListeners(this.busID);
        try {
            for (index = 0; index < listeners.length; ++index) {
                listeners[index].invoke(event);
            }
        }
        catch (Throwable throwable) {
            this.exceptionHandler.handleException(this, event, listeners, index, throwable);
            Throwables.throwIfUnchecked(throwable);
            throw new RuntimeException(throwable);
        }
        return event.isCancelable() && event.isCanceled();
    }

    public void shutdown() {
        FMLLog.log.warn("EventBus {} shutting down - future events will not be posted.", (Object)this.busID);
        this.shutdown = true;
    }

    public void handleException(EventBus bus, Event event, IEventListener[] listeners, int index, Throwable throwable) {
        FMLLog.log.error("Exception caught during firing event {}:", (Object)event, (Object)throwable);
        FMLLog.log.error("Index: {} Listeners:", (Object)index);
        for (int x = 0; x < listeners.length; ++x) {
            FMLLog.log.error("{}: {}", (Object)x, (Object)listeners[x]);
        }
    }

}

