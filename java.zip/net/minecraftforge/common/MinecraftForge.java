/*
 * Decompiled with CFR 0.0.
 *
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.Set
 *  javax.annotation.Nonnull
 *  net.minecraft.crash.CrashReport
 *  net.minecraft.crash.ICrashReportDetail
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.common.ForgeHooks
 *  net.minecraftforge.common.ForgeHooks$SeedEntry
 *  net.minecraftforge.common.ForgeInternalHandler
 *  net.minecraftforge.common.ForgeModContainer
 *  net.minecraftforge.common.ForgeVersion
 *  net.minecraftforge.common.UsernameCache
 *  net.minecraftforge.fluids.FluidRegistry
 *  net.minecraftforge.fml.common.FMLLog
 *  net.minecraftforge.fml.common.ICrashCallable
 *  net.minecraftforge.fml.common.discovery.ASMDataTable
 *  net.minecraftforge.fml.common.discovery.ASMDataTable$ASMData
 *  net.minecraftforge.oredict.OreDictionary
 */
package net.minecraftforge.common;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import javax.annotation.Nonnull;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.ForgeInternalHandler;
import net.minecraftforge.common.ForgeModContainer;
import net.minecraftforge.common.ForgeVersion;
import net.minecraftforge.common.UsernameCache;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.ICrashCallable;
import net.minecraftforge.fml.common.discovery.ASMDataTable;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.oredict.OreDictionary;
import org.apache.logging.log4j.Logger;

public class MinecraftForge {
    public static EventBus EVENT_BUS = new EventBus();
    public static final EventBus TERRAIN_GEN_BUS = new EventBus();
    public static final EventBus ORE_GEN_BUS = new EventBus();
    public static final String MC_VERSION = "1.12.2";
    static final ForgeInternalHandler INTERNAL_HANDLER = new ForgeInternalHandler();

    public static void addGrassSeed(@Nonnull ItemStack seed, int weight) {
        MinecraftForge.addGrassSeed(new ForgeHooks.SeedEntry(seed, weight));
    }

    public static void addGrassSeed(ForgeHooks.SeedEntry seed) {
        ForgeHooks.seedList.add((ForgeHooks.SeedEntry) seed);
    }

    public static void initialize() {
        FMLLog.log.info("MinecraftForge v{} Initialized", (Object)ForgeVersion.getVersion());
        OreDictionary.getOreName((int)0);
        UsernameCache.load();
        FluidRegistry.validateFluidRegistry();
        ForgeHooks.initTools();
        new CrashReport("ThisIsFake", (Throwable)new Exception("Not real"));
    }

    public static void preloadCrashClasses(ASMDataTable table, String modID, Set<String> classes) {
        ArrayList all = Lists.newArrayList();
        for (ASMDataTable.ASMData asm : table.getAll(ICrashReportDetail.class.getName().replace('.', '/'))) {
            all.add((Object)asm.getClassName());
        }
        for (ASMDataTable.ASMData asm : table.getAll(ICrashCallable.class.getName().replace('.', '/'))) {
            all.add((Object)asm.getClassName());
        }
        all.retainAll(classes);
        if (all.size() == 0) {
            return;
        }
        ForgeModContainer.log.debug("Preloading CrashReport Classes");
        Collections.sort(all);
        for (Object name : all) {
            ForgeModContainer.log.debug("\t{}", (Object)name);
        }
    }
}

