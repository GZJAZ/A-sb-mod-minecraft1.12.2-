//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package net.minecraft.client.renderer;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import com.google.common.collect.Sets;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockSign;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.chunk.ChunkRenderDispatcher;
import net.minecraft.client.renderer.chunk.CompiledChunk;
import net.minecraft.client.renderer.chunk.IRenderChunkFactory;
import net.minecraft.client.renderer.chunk.ListChunkFactory;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.renderer.chunk.VboChunkFactory;
import net.minecraft.client.renderer.chunk.VisGraph;
import net.minecraft.client.renderer.culling.ClippingHelper;
import net.minecraft.client.renderer.culling.ClippingHelperImpl;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.client.renderer.vertex.VertexFormatElement;
import net.minecraft.client.renderer.vertex.VertexFormatElement.EnumType;
import net.minecraft.client.renderer.vertex.VertexFormatElement.EnumUsage;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.client.shader.ShaderLinkHelper;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemRecord;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.PooledMutableBlockPos;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.IWorldEventListener;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.common.ForgeModContainer;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

@SideOnly(Side.CLIENT)
public class RenderGlobal implements IWorldEventListener, IResourceManagerReloadListener {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ResourceLocation MOON_PHASES_TEXTURES = new ResourceLocation("textures/environment/moon_phases.png");
    private static final ResourceLocation SUN_TEXTURES = new ResourceLocation("textures/environment/sun.png");
    private static final ResourceLocation CLOUDS_TEXTURES = new ResourceLocation("textures/environment/clouds.png");
    private static final ResourceLocation END_SKY_TEXTURES = new ResourceLocation("textures/environment/end_sky.png");
    private static final ResourceLocation FORCEFIELD_TEXTURES = new ResourceLocation("textures/misc/forcefield.png");
    private final Minecraft mc;
    private final TextureManager renderEngine;
    private final RenderManager renderManager;
    private WorldClient world;
    private Set<RenderChunk> chunksToUpdate = Sets.newLinkedHashSet();
    private List<ContainerLocalRenderInformation> renderInfos = Lists.newArrayListWithCapacity(69696);
    private final Set<TileEntity> setTileEntities = Sets.newHashSet();
    private ViewFrustum viewFrustum;
    private int starGLCallList = -1;
    private int glSkyList = -1;
    private int glSkyList2 = -1;
    private final VertexFormat vertexBufferFormat;
    private VertexBuffer starVBO;
    private VertexBuffer skyVBO;
    private VertexBuffer sky2VBO;
    private int cloudTickCounter;
    private final Map<Integer, DestroyBlockProgress> damagedBlocks = Maps.newHashMap();
    private final Map<BlockPos, ISound> mapSoundPositions = Maps.newHashMap();
    private final TextureAtlasSprite[] destroyBlockIcons = new TextureAtlasSprite[10];
    private Framebuffer entityOutlineFramebuffer;
    private ShaderGroup entityOutlineShader;
    private double frustumUpdatePosX = Double.MIN_VALUE;
    private double frustumUpdatePosY = Double.MIN_VALUE;
    private double frustumUpdatePosZ = Double.MIN_VALUE;
    private int frustumUpdatePosChunkX = Integer.MIN_VALUE;
    private int frustumUpdatePosChunkY = Integer.MIN_VALUE;
    private int frustumUpdatePosChunkZ = Integer.MIN_VALUE;
    private double lastViewEntityX = Double.MIN_VALUE;
    private double lastViewEntityY = Double.MIN_VALUE;
    private double lastViewEntityZ = Double.MIN_VALUE;
    private double lastViewEntityPitch = Double.MIN_VALUE;
    private double lastViewEntityYaw = Double.MIN_VALUE;
    private ChunkRenderDispatcher renderDispatcher;
    private ChunkRenderContainer renderContainer;
    private int renderDistanceChunks = -1;
    private int renderEntitiesStartupCounter = 2;
    private int countEntitiesTotal;
    private int countEntitiesRendered;
    private int countEntitiesHidden;
    private boolean debugFixTerrainFrustum;
    private ClippingHelper debugFixedClippingHelper;
    private final Vector4f[] debugTerrainMatrix = new Vector4f[8];
    private final Vector3d debugTerrainFrustumPosition = new Vector3d();
    private boolean vboEnabled;
    IRenderChunkFactory renderChunkFactory;
    private double prevRenderSortX;
    private double prevRenderSortY;
    private double prevRenderSortZ;
    private boolean displayListEntitiesDirty = true;
    private boolean entityOutlinesRendered;
    private final Set<BlockPos> setLightUpdates = Sets.newHashSet();

    public RenderGlobal(Minecraft p_i1249_1_) {
        this.mc = p_i1249_1_;
        this.renderManager = p_i1249_1_.getRenderManager();
        this.renderEngine = p_i1249_1_.getTextureManager();
        this.renderEngine.bindTexture(FORCEFIELD_TEXTURES);
        GlStateManager.glTexParameteri(3553, 10242, 10497);
        GlStateManager.glTexParameteri(3553, 10243, 10497);
        GlStateManager.bindTexture(0);
        this.updateDestroyBlockIcons();
        this.vboEnabled = OpenGlHelper.useVbo();
        if (this.vboEnabled) {
            this.renderContainer = new VboRenderList();
            this.renderChunkFactory = new VboChunkFactory();
        } else {
            this.renderContainer = new RenderList();
            this.renderChunkFactory = new ListChunkFactory();
        }

        this.vertexBufferFormat = new VertexFormat();
        this.vertexBufferFormat.addElement(new VertexFormatElement(0, EnumType.FLOAT, EnumUsage.POSITION, 3));
        this.generateStars();
        this.generateSky();
        this.generateSky2();
    }

    public void onResourceManagerReload(IResourceManager p_onResourceManagerReload_1_) {
        this.updateDestroyBlockIcons();
    }

    private void updateDestroyBlockIcons() {
        TextureMap texturemap = this.mc.getTextureMapBlocks();

        for(int i = 0; i < this.destroyBlockIcons.length; ++i) {
            this.destroyBlockIcons[i] = texturemap.getAtlasSprite("minecraft:blocks/destroy_stage_" + i);
        }

    }

    public void makeEntityOutlineShader() {
        if (OpenGlHelper.shadersSupported) {
            if (ShaderLinkHelper.getStaticShaderLinkHelper() == null) {
                ShaderLinkHelper.setNewStaticShaderLinkHelper();
            }

            ResourceLocation resourcelocation = new ResourceLocation("shaders/post/entity_outline.json");

            try {
                this.entityOutlineShader = new ShaderGroup(this.mc.getTextureManager(), this.mc.getResourceManager(), this.mc.getFramebuffer(), resourcelocation);
                this.entityOutlineShader.createBindFramebuffers(this.mc.displayWidth, this.mc.displayHeight);
                this.entityOutlineFramebuffer = this.entityOutlineShader.getFramebufferRaw("final");
            } catch (IOException var3) {
                LOGGER.warn("Failed to load shader: {}", resourcelocation, var3);
                this.entityOutlineShader = null;
                this.entityOutlineFramebuffer = null;
            } catch (JsonSyntaxException var4) {
                LOGGER.warn("Failed to load shader: {}", resourcelocation, var4);
                this.entityOutlineShader = null;
                this.entityOutlineFramebuffer = null;
            }
        } else {
            this.entityOutlineShader = null;
            this.entityOutlineFramebuffer = null;
        }

    }

    public void renderEntityOutlineFramebuffer() {
        if (this.isRenderEntityOutlines()) {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ZERO, DestFactor.ONE);
            this.entityOutlineFramebuffer.framebufferRenderExt(this.mc.displayWidth, this.mc.displayHeight, false);
            GlStateManager.disableBlend();
        }

    }

    protected boolean isRenderEntityOutlines() {
        return this.entityOutlineFramebuffer != null && this.entityOutlineShader != null && this.mc.player != null;
    }

    private void generateSky2() {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        if (this.sky2VBO != null) {
            this.sky2VBO.deleteGlBuffers();
        }

        if (this.glSkyList2 >= 0) {
            GLAllocation.deleteDisplayLists(this.glSkyList2);
            this.glSkyList2 = -1;
        }

        if (this.vboEnabled) {
            this.sky2VBO = new VertexBuffer(this.vertexBufferFormat);
            this.renderSky(bufferbuilder, -16.0F, true);
            bufferbuilder.finishDrawing();
            bufferbuilder.reset();
            this.sky2VBO.bufferData(bufferbuilder.getByteBuffer());
        } else {
            this.glSkyList2 = GLAllocation.generateDisplayLists(1);
            GlStateManager.glNewList(this.glSkyList2, 4864);
            this.renderSky(bufferbuilder, -16.0F, true);
            tessellator.draw();
            GlStateManager.glEndList();
        }

    }

    private void generateSky() {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        if (this.skyVBO != null) {
            this.skyVBO.deleteGlBuffers();
        }

        if (this.glSkyList >= 0) {
            GLAllocation.deleteDisplayLists(this.glSkyList);
            this.glSkyList = -1;
        }

        if (this.vboEnabled) {
            this.skyVBO = new VertexBuffer(this.vertexBufferFormat);
            this.renderSky(bufferbuilder, 16.0F, false);
            bufferbuilder.finishDrawing();
            bufferbuilder.reset();
            this.skyVBO.bufferData(bufferbuilder.getByteBuffer());
        } else {
            this.glSkyList = GLAllocation.generateDisplayLists(1);
            GlStateManager.glNewList(this.glSkyList, 4864);
            this.renderSky(bufferbuilder, 16.0F, false);
            tessellator.draw();
            GlStateManager.glEndList();
        }

    }

    private void renderSky(BufferBuilder p_renderSky_1_, float p_renderSky_2_, boolean p_renderSky_3_) {
        boolean i = true;
        boolean j = true;
        p_renderSky_1_.begin(7, DefaultVertexFormats.POSITION);

        for(int k = -384; k <= 384; k += 64) {
            for(int l = -384; l <= 384; l += 64) {
                float f = (float)k;
                float f1 = (float)(k + 64);
                if (p_renderSky_3_) {
                    f1 = (float)k;
                    f = (float)(k + 64);
                }

                p_renderSky_1_.pos((double)f, (double)p_renderSky_2_, (double)l).endVertex();
                p_renderSky_1_.pos((double)f1, (double)p_renderSky_2_, (double)l).endVertex();
                p_renderSky_1_.pos((double)f1, (double)p_renderSky_2_, (double)(l + 64)).endVertex();
                p_renderSky_1_.pos((double)f, (double)p_renderSky_2_, (double)(l + 64)).endVertex();
            }
        }

    }

    private void generateStars() {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        if (this.starVBO != null) {
            this.starVBO.deleteGlBuffers();
        }

        if (this.starGLCallList >= 0) {
            GLAllocation.deleteDisplayLists(this.starGLCallList);
            this.starGLCallList = -1;
        }

        if (this.vboEnabled) {
            this.starVBO = new VertexBuffer(this.vertexBufferFormat);
            this.renderStars(bufferbuilder);
            bufferbuilder.finishDrawing();
            bufferbuilder.reset();
            this.starVBO.bufferData(bufferbuilder.getByteBuffer());
        } else {
            this.starGLCallList = GLAllocation.generateDisplayLists(1);
            GlStateManager.pushMatrix();
            GlStateManager.glNewList(this.starGLCallList, 4864);
            this.renderStars(bufferbuilder);
            tessellator.draw();
            GlStateManager.glEndList();
            GlStateManager.popMatrix();
        }

    }

    private void renderStars(BufferBuilder p_renderStars_1_) {
        Random random = new Random(10842L);
        p_renderStars_1_.begin(7, DefaultVertexFormats.POSITION);

        for(int i = 0; i < 1500; ++i) {
            double d0 = (double)(random.nextFloat() * 2.0F - 1.0F);
            double d1 = (double)(random.nextFloat() * 2.0F - 1.0F);
            double d2 = (double)(random.nextFloat() * 2.0F - 1.0F);
            double d3 = (double)(0.15F + random.nextFloat() * 0.1F);
            double d4 = d0 * d0 + d1 * d1 + d2 * d2;
            if (d4 < 1.0 && d4 > 0.01) {
                d4 = 1.0 / Math.sqrt(d4);
                d0 *= d4;
                d1 *= d4;
                d2 *= d4;
                double d5 = d0 * 100.0;
                double d6 = d1 * 100.0;
                double d7 = d2 * 100.0;
                double d8 = Math.atan2(d0, d2);
                double d9 = Math.sin(d8);
                double d10 = Math.cos(d8);
                double d11 = Math.atan2(Math.sqrt(d0 * d0 + d2 * d2), d1);
                double d12 = Math.sin(d11);
                double d13 = Math.cos(d11);
                double d14 = random.nextDouble() * Math.PI * 2.0;
                double d15 = Math.sin(d14);
                double d16 = Math.cos(d14);

                for(int j = 0; j < 4; ++j) {
                    double d17 = 0.0;
                    double d18 = (double)((j & 2) - 1) * d3;
                    double d19 = (double)((j + 1 & 2) - 1) * d3;
                    double d20 = 0.0;
                    double d21 = d18 * d16 - d19 * d15;
                    double d22 = d19 * d16 + d18 * d15;
                    double d23 = d21 * d12 + 0.0 * d13;
                    double d24 = 0.0 * d12 - d21 * d13;
                    double d25 = d24 * d9 - d22 * d10;
                    double d26 = d22 * d9 + d24 * d10;
                    p_renderStars_1_.pos(d5 + d25, d6 + d23, d7 + d26).endVertex();
                }
            }
        }

    }

    public void setWorldAndLoadRenderers(@Nullable WorldClient p_setWorldAndLoadRenderers_1_) {
        if (this.world != null) {
            this.world.removeEventListener(this);
        }

        this.frustumUpdatePosX = Double.MIN_VALUE;
        this.frustumUpdatePosY = Double.MIN_VALUE;
        this.frustumUpdatePosZ = Double.MIN_VALUE;
        this.frustumUpdatePosChunkX = Integer.MIN_VALUE;
        this.frustumUpdatePosChunkY = Integer.MIN_VALUE;
        this.frustumUpdatePosChunkZ = Integer.MIN_VALUE;
        this.renderManager.setWorld(p_setWorldAndLoadRenderers_1_);
        this.world = p_setWorldAndLoadRenderers_1_;
        if (p_setWorldAndLoadRenderers_1_ != null) {
            p_setWorldAndLoadRenderers_1_.addEventListener(this);
            this.loadRenderers();
        } else {
            this.chunksToUpdate.clear();
            this.renderInfos.clear();
            if (this.viewFrustum != null) {
                this.viewFrustum.deleteGlResources();
                this.viewFrustum = null;
            }

            if (this.renderDispatcher != null) {
                this.renderDispatcher.stopWorkerThreads();
            }

            this.renderDispatcher = null;
        }

    }

    public void loadRenderers() {
        if (this.world != null) {
            if (this.renderDispatcher == null) {
                this.renderDispatcher = new ChunkRenderDispatcher();
            }

            this.displayListEntitiesDirty = true;
            Blocks.LEAVES.setGraphicsLevel(this.mc.gameSettings.fancyGraphics);
            Blocks.LEAVES2.setGraphicsLevel(this.mc.gameSettings.fancyGraphics);
            this.renderDistanceChunks = this.mc.gameSettings.renderDistanceChunks;
            boolean flag = this.vboEnabled;
            this.vboEnabled = OpenGlHelper.useVbo();
            if (flag && !this.vboEnabled) {
                this.renderContainer = new RenderList();
                this.renderChunkFactory = new ListChunkFactory();
            } else if (!flag && this.vboEnabled) {
                this.renderContainer = new VboRenderList();
                this.renderChunkFactory = new VboChunkFactory();
            }

            if (flag != this.vboEnabled) {
                this.generateStars();
                this.generateSky();
                this.generateSky2();
            }

            if (this.viewFrustum != null) {
                this.viewFrustum.deleteGlResources();
            }

            this.stopChunkUpdates();
            synchronized(this.setTileEntities) {
                this.setTileEntities.clear();
            }

            this.viewFrustum = new ViewFrustum(this.world, this.mc.gameSettings.renderDistanceChunks, this, this.renderChunkFactory);
            if (this.world != null) {
                Entity entity = this.mc.getRenderViewEntity();
                if (entity != null) {
                    this.viewFrustum.updateChunkPositions(entity.posX, entity.posZ);
                }
            }

            this.renderEntitiesStartupCounter = 2;
        }

    }

    protected void stopChunkUpdates() {
        this.chunksToUpdate.clear();
        this.renderDispatcher.stopChunkUpdates();
    }

    public void createBindEntityOutlineFbs(int p_createBindEntityOutlineFbs_1_, int p_createBindEntityOutlineFbs_2_) {
        if (OpenGlHelper.shadersSupported && this.entityOutlineShader != null) {
            this.entityOutlineShader.createBindFramebuffers(p_createBindEntityOutlineFbs_1_, p_createBindEntityOutlineFbs_2_);
        }

    }

    public void renderEntities(Entity p_renderEntities_1_, ICamera p_renderEntities_2_, float p_renderEntities_3_) {
        int pass = MinecraftForgeClient.getRenderPass();
        if (this.renderEntitiesStartupCounter > 0) {
            if (pass <= 0) {
                --this.renderEntitiesStartupCounter;
            }
        } else {
            double d0 = p_renderEntities_1_.prevPosX + (p_renderEntities_1_.posX - p_renderEntities_1_.prevPosX) * (double)p_renderEntities_3_;
            double d1 = p_renderEntities_1_.prevPosY + (p_renderEntities_1_.posY - p_renderEntities_1_.prevPosY) * (double)p_renderEntities_3_;
            double d2 = p_renderEntities_1_.prevPosZ + (p_renderEntities_1_.posZ - p_renderEntities_1_.prevPosZ) * (double)p_renderEntities_3_;
            this.world.profiler.startSection("prepare");
            TileEntityRendererDispatcher.instance.prepare(this.world, this.mc.getTextureManager(), this.mc.fontRenderer, this.mc.getRenderViewEntity(), this.mc.objectMouseOver, p_renderEntities_3_);
            this.renderManager.cacheActiveRenderInfo(this.world, this.mc.fontRenderer, this.mc.getRenderViewEntity(), this.mc.pointedEntity, this.mc.gameSettings, p_renderEntities_3_);
            if (pass == 0) {
                this.countEntitiesTotal = 0;
                this.countEntitiesRendered = 0;
                this.countEntitiesHidden = 0;
            }

            Entity entity = this.mc.getRenderViewEntity();
            double d3 = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)p_renderEntities_3_;
            double d4 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)p_renderEntities_3_;
            double d5 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)p_renderEntities_3_;
            TileEntityRendererDispatcher.staticPlayerX = d3;
            TileEntityRendererDispatcher.staticPlayerY = d4;
            TileEntityRendererDispatcher.staticPlayerZ = d5;
            this.renderManager.setRenderPosition(d3, d4, d5);
            this.mc.entityRenderer.enableLightmap();
            this.world.profiler.endStartSection("global");
            List<Entity> list = this.world.getLoadedEntityList();
            if (pass == 0) {
                this.countEntitiesTotal = list.size();
            }

            for(int i = 0; i < this.world.weatherEffects.size(); ++i) {
                Entity entity1 = (Entity)this.world.weatherEffects.get(i);
                if (entity1.shouldRenderInPass(pass)) {
                    ++this.countEntitiesRendered;
                    if (entity1.isInRangeToRender3d(d0, d1, d2)) {
                        this.renderManager.renderEntityStatic(entity1, p_renderEntities_3_, false);
                    }
                }
            }

            this.world.profiler.endStartSection("entities");
            List<Entity> list1 = Lists.newArrayList();
            List<Entity> list2 = Lists.newArrayList();
            BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = PooledMutableBlockPos.retain();
            Iterator var22 = this.renderInfos.iterator();

            label222:
            while(true) {
                ClassInheritanceMultiMap classinheritancemultimap;
                do {
                    ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation1;
                    if (!var22.hasNext()) {
                        blockpos$pooledmutableblockpos.release();
                        if (!list2.isEmpty()) {
                            var22 = list2.iterator();

                            while(var22.hasNext()) {
                                Entity entity3 = (Entity)var22.next();
                                this.renderManager.renderMultipass(entity3, p_renderEntities_3_);
                            }
                        }

                        if (pass == 0 && this.isRenderEntityOutlines() && (!list1.isEmpty() || this.entityOutlinesRendered)) {
                            this.world.profiler.endStartSection("entityOutlines");
                            this.entityOutlineFramebuffer.framebufferClear();
                            this.entityOutlinesRendered = !list1.isEmpty();
                            if (!list1.isEmpty()) {
                                GlStateManager.depthFunc(519);
                                GlStateManager.disableFog();
                                this.entityOutlineFramebuffer.bindFramebuffer(false);
                                RenderHelper.disableStandardItemLighting();
                                this.renderManager.setRenderOutlines(true);

                                for(int j = 0; j < list1.size(); ++j) {
                                    this.renderManager.renderEntityStatic((Entity)list1.get(j), p_renderEntities_3_, false);
                                }

                                this.renderManager.setRenderOutlines(false);
                                RenderHelper.enableStandardItemLighting();
                                GlStateManager.depthMask(false);
                                this.entityOutlineShader.render(p_renderEntities_3_);
                                GlStateManager.enableLighting();
                                GlStateManager.depthMask(true);
                                GlStateManager.enableFog();
                                GlStateManager.enableBlend();
                                GlStateManager.enableColorMaterial();
                                GlStateManager.depthFunc(515);
                                GlStateManager.enableDepth();
                                GlStateManager.enableAlpha();
                            }

                            this.mc.getFramebuffer().bindFramebuffer(false);
                        }

                        this.world.profiler.endStartSection("blockentities");
                        RenderHelper.enableStandardItemLighting();
                        TileEntityRendererDispatcher.instance.preDrawBatch();
                        var22 = this.renderInfos.iterator();

                        while(true) {
                            List list3;
                            do {
                                if (!var22.hasNext()) {
                                    synchronized(this.setTileEntities) {
                                        Iterator var36 = this.setTileEntities.iterator();

                                        while(true) {
                                            if (!var36.hasNext()) {
                                                break;
                                            }

                                            TileEntity tileentity = (TileEntity)var36.next();
                                            if (tileentity.shouldRenderInPass(pass) && p_renderEntities_2_.isBoundingBoxInFrustum(tileentity.getRenderBoundingBox())) {
                                                TileEntityRendererDispatcher.instance.render(tileentity, p_renderEntities_3_, -1);
                                            }
                                        }
                                    }

                                    TileEntityRendererDispatcher.instance.drawBatch(pass);
                                    this.preRenderDamagedBlocks();
                                    var22 = this.damagedBlocks.values().iterator();

                                    while(var22.hasNext()) {
                                        DestroyBlockProgress destroyblockprogress = (DestroyBlockProgress)var22.next();
                                        BlockPos blockpos = destroyblockprogress.getPosition();
                                        if (this.world.getBlockState(blockpos).getBlock().hasTileEntity()) {
                                            TileEntity tileentity1 = this.world.getTileEntity(blockpos);
                                            if (tileentity1 instanceof TileEntityChest) {
                                                TileEntityChest tileentitychest = (TileEntityChest)tileentity1;
                                                if (tileentitychest.adjacentChestXNeg != null) {
                                                    blockpos = blockpos.offset(EnumFacing.WEST);
                                                    tileentity1 = this.world.getTileEntity(blockpos);
                                                } else if (tileentitychest.adjacentChestZNeg != null) {
                                                    blockpos = blockpos.offset(EnumFacing.NORTH);
                                                    tileentity1 = this.world.getTileEntity(blockpos);
                                                }
                                            }

                                            IBlockState iblockstate = this.world.getBlockState(blockpos);
                                            if (tileentity1 != null && iblockstate.hasCustomBreakingProgress()) {
                                                TileEntityRendererDispatcher.instance.render(tileentity1, p_renderEntities_3_, destroyblockprogress.getPartialBlockDamage());
                                            }
                                        }
                                    }

                                    this.postRenderDamagedBlocks();
                                    this.mc.entityRenderer.disableLightmap();
                                    this.mc.mcProfiler.endSection();
                                    return;
                                }

                                renderglobal$containerlocalrenderinformation1 = (ContainerLocalRenderInformation)var22.next();
                                list3 = renderglobal$containerlocalrenderinformation1.renderChunk.getCompiledChunk().getTileEntities();
                            } while(list3.isEmpty());

                            Iterator var41 = list3.iterator();

                            while(var41.hasNext()) {
                                TileEntity tileentity2 = (TileEntity)var41.next();
                                if (tileentity2.shouldRenderInPass(pass) && p_renderEntities_2_.isBoundingBoxInFrustum(tileentity2.getRenderBoundingBox())) {
                                    TileEntityRendererDispatcher.instance.render(tileentity2, p_renderEntities_3_, -1);
                                }
                            }
                        }
                    }

                    renderglobal$containerlocalrenderinformation1 = (ContainerLocalRenderInformation)var22.next();
                    Chunk chunk = this.world.getChunkFromBlockCoords(renderglobal$containerlocalrenderinformation1.renderChunk.getPosition());
                    classinheritancemultimap = chunk.getEntityLists()[renderglobal$containerlocalrenderinformation1.renderChunk.getPosition().getY() / 16];
                } while(classinheritancemultimap.isEmpty());

                Iterator var26 = classinheritancemultimap.iterator();

                while(true) {
                    Entity entity2;
                    boolean flag1;
                    do {
                        do {
                            boolean flag;
                            do {
                                do {
                                    if (!var26.hasNext()) {
                                        continue label222;
                                    }

                                    entity2 = (Entity)var26.next();
                                } while(!entity2.shouldRenderInPass(pass));

                                flag = this.renderManager.shouldRender(entity2, p_renderEntities_2_, d0, d1, d2) || entity2.isRidingOrBeingRiddenBy(this.mc.player);
                            } while(!flag);

                            flag1 = this.mc.getRenderViewEntity() instanceof EntityLivingBase ? ((EntityLivingBase)this.mc.getRenderViewEntity()).isPlayerSleeping() : false;
                        } while(entity2 == this.mc.getRenderViewEntity() && this.mc.gameSettings.thirdPersonView == 0 && !flag1);
                    } while(!(entity2.posY < 0.0) && !(entity2.posY >= 256.0) && !this.world.isBlockLoaded(blockpos$pooledmutableblockpos.setPos(entity2)));

                    ++this.countEntitiesRendered;
                    this.renderManager.renderEntityStatic(entity2, p_renderEntities_3_, false);
                    if (this.isOutlineActive(entity2, entity, p_renderEntities_2_)) {
                        list1.add(entity2);
                    }

                    if (this.renderManager.isRenderMultipass(entity2)) {
                        list2.add(entity2);
                    }
                }
            }
        }
    }

    private boolean isOutlineActive(Entity p_isOutlineActive_1_, Entity p_isOutlineActive_2_, ICamera p_isOutlineActive_3_) {
        boolean flag = p_isOutlineActive_2_ instanceof EntityLivingBase && ((EntityLivingBase)p_isOutlineActive_2_).isPlayerSleeping();
        if (p_isOutlineActive_1_ == p_isOutlineActive_2_ && this.mc.gameSettings.thirdPersonView == 0 && !flag) {
            return false;
        } else if (p_isOutlineActive_1_.isGlowing()) {
            return true;
        } else if (this.mc.player.isSpectator() && this.mc.gameSettings.keyBindSpectatorOutlines.isKeyDown() && p_isOutlineActive_1_ instanceof EntityPlayer) {
            return p_isOutlineActive_1_.ignoreFrustumCheck || p_isOutlineActive_3_.isBoundingBoxInFrustum(p_isOutlineActive_1_.getEntityBoundingBox()) || p_isOutlineActive_1_.isRidingOrBeingRiddenBy(this.mc.player);
        } else {
            return false;
        }
    }

    public String getDebugInfoRenders() {
        int i = this.viewFrustum.renderChunks.length;
        int j = this.getRenderedChunks();
        return String.format("C: %d/%d %sD: %d, L: %d, %s", j, i, this.mc.renderChunksMany ? "(s) " : "", this.renderDistanceChunks, this.setLightUpdates.size(), this.renderDispatcher == null ? "null" : this.renderDispatcher.getDebugInfo());
    }

    public int getRenderedChunks() {
        int i = 0;
        Iterator var2 = this.renderInfos.iterator();

        while(var2.hasNext()) {
            ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation = (ContainerLocalRenderInformation)var2.next();
            CompiledChunk compiledchunk = renderglobal$containerlocalrenderinformation.renderChunk.compiledChunk;
            if (compiledchunk != CompiledChunk.DUMMY && !compiledchunk.isEmpty()) {
                ++i;
            }
        }

        return i;
    }

    public String getDebugInfoEntities() {
        return "E: " + this.countEntitiesRendered + "/" + this.countEntitiesTotal + ", B: " + this.countEntitiesHidden;
    }

    public void setupTerrain(Entity p_setupTerrain_1_, double p_setupTerrain_2_, ICamera p_setupTerrain_4_, int p_setupTerrain_5_, boolean p_setupTerrain_6_) {
        if (this.mc.gameSettings.renderDistanceChunks != this.renderDistanceChunks) {
            this.loadRenderers();
        }

        this.world.profiler.startSection("camera");
        double d0 = p_setupTerrain_1_.posX - this.frustumUpdatePosX;
        double d1 = p_setupTerrain_1_.posY - this.frustumUpdatePosY;
        double d2 = p_setupTerrain_1_.posZ - this.frustumUpdatePosZ;
        if (this.frustumUpdatePosChunkX != p_setupTerrain_1_.chunkCoordX || this.frustumUpdatePosChunkY != p_setupTerrain_1_.chunkCoordY || this.frustumUpdatePosChunkZ != p_setupTerrain_1_.chunkCoordZ || d0 * d0 + d1 * d1 + d2 * d2 > 16.0) {
            this.frustumUpdatePosX = p_setupTerrain_1_.posX;
            this.frustumUpdatePosY = p_setupTerrain_1_.posY;
            this.frustumUpdatePosZ = p_setupTerrain_1_.posZ;
            this.frustumUpdatePosChunkX = p_setupTerrain_1_.chunkCoordX;
            this.frustumUpdatePosChunkY = p_setupTerrain_1_.chunkCoordY;
            this.frustumUpdatePosChunkZ = p_setupTerrain_1_.chunkCoordZ;
            this.viewFrustum.updateChunkPositions(p_setupTerrain_1_.posX, p_setupTerrain_1_.posZ);
        }

        this.world.profiler.endStartSection("renderlistcamera");
        double d3 = p_setupTerrain_1_.lastTickPosX + (p_setupTerrain_1_.posX - p_setupTerrain_1_.lastTickPosX) * p_setupTerrain_2_;
        double d4 = p_setupTerrain_1_.lastTickPosY + (p_setupTerrain_1_.posY - p_setupTerrain_1_.lastTickPosY) * p_setupTerrain_2_;
        double d5 = p_setupTerrain_1_.lastTickPosZ + (p_setupTerrain_1_.posZ - p_setupTerrain_1_.lastTickPosZ) * p_setupTerrain_2_;
        this.renderContainer.initialize(d3, d4, d5);
        this.world.profiler.endStartSection("cull");
        if (this.debugFixedClippingHelper != null) {
            Frustum frustum = new Frustum(this.debugFixedClippingHelper);
            frustum.setPosition(this.debugTerrainFrustumPosition.x, this.debugTerrainFrustumPosition.y, this.debugTerrainFrustumPosition.z);
            p_setupTerrain_4_ = frustum;
        }

        this.mc.mcProfiler.endStartSection("culling");
        BlockPos blockpos1 = new BlockPos(d3, d4 + (double)p_setupTerrain_1_.getEyeHeight(), d5);
        RenderChunk renderchunk = this.viewFrustum.getRenderChunk(blockpos1);
        BlockPos blockpos = new BlockPos(MathHelper.floor(d3 / 16.0) * 16, MathHelper.floor(d4 / 16.0) * 16, MathHelper.floor(d5 / 16.0) * 16);
        this.displayListEntitiesDirty = this.displayListEntitiesDirty || !this.chunksToUpdate.isEmpty() || p_setupTerrain_1_.posX != this.lastViewEntityX || p_setupTerrain_1_.posY != this.lastViewEntityY || p_setupTerrain_1_.posZ != this.lastViewEntityZ || (double)p_setupTerrain_1_.rotationPitch != this.lastViewEntityPitch || (double)p_setupTerrain_1_.rotationYaw != this.lastViewEntityYaw;
        this.lastViewEntityX = p_setupTerrain_1_.posX;
        this.lastViewEntityY = p_setupTerrain_1_.posY;
        this.lastViewEntityZ = p_setupTerrain_1_.posZ;
        this.lastViewEntityPitch = (double)p_setupTerrain_1_.rotationPitch;
        this.lastViewEntityYaw = (double)p_setupTerrain_1_.rotationYaw;
        boolean flag = this.debugFixedClippingHelper != null;
        this.mc.mcProfiler.endStartSection("update");
        ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation1;
        RenderChunk renderchunk3;
        if (!flag && this.displayListEntitiesDirty) {
            this.displayListEntitiesDirty = false;
            this.renderInfos = Lists.newArrayList();
            Queue<ContainerLocalRenderInformation> queue = Queues.newArrayDeque();
            Entity.setRenderDistanceWeight(MathHelper.clamp((double)this.mc.gameSettings.renderDistanceChunks / 8.0, 1.0, 2.5));
            boolean flag1 = this.mc.renderChunksMany;
            if (renderchunk != null) {
                boolean flag2 = false;
                ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation3 = new ContainerLocalRenderInformation(renderchunk, (EnumFacing)null, 0);
                Set<EnumFacing> set1 = this.getVisibleFacings(blockpos1);
                if (set1.size() == 1) {
                    Vector3f vector3f = this.getViewVector(p_setupTerrain_1_, p_setupTerrain_2_);
                    EnumFacing enumfacing = EnumFacing.getFacingFromVector(vector3f.x, vector3f.y, vector3f.z).getOpposite();
                    set1.remove(enumfacing);
                }

                if (set1.isEmpty()) {
                    flag2 = true;
                }

                if (flag2 && !p_setupTerrain_6_) {
                    this.renderInfos.add(renderglobal$containerlocalrenderinformation3);
                } else {
                    if (p_setupTerrain_6_ && this.world.getBlockState(blockpos1).isOpaqueCube()) {
                        flag1 = false;
                    }

                    renderchunk.setFrameIndex(p_setupTerrain_5_);
                    queue.add(renderglobal$containerlocalrenderinformation3);
                }
            } else {
                int i = blockpos1.getY() > 0 ? 248 : 8;

                for(int j = -this.renderDistanceChunks; j <= this.renderDistanceChunks; ++j) {
                    for(int k = -this.renderDistanceChunks; k <= this.renderDistanceChunks; ++k) {
                        RenderChunk renderchunk1 = this.viewFrustum.getRenderChunk(new BlockPos((j << 4) + 8, i, (k << 4) + 8));
                        if (renderchunk1 != null && ((ICamera)p_setupTerrain_4_).isBoundingBoxInFrustum(renderchunk1.boundingBox.expand(0.0, blockpos1.getY() > 0 ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY, 0.0))) {
                            renderchunk1.setFrameIndex(p_setupTerrain_5_);
                            queue.add(new ContainerLocalRenderInformation(renderchunk1, (EnumFacing)null, 0));
                        }
                    }
                }
            }

            this.mc.mcProfiler.startSection("iteration");

            while(!queue.isEmpty()) {
                renderglobal$containerlocalrenderinformation1 = (ContainerLocalRenderInformation)queue.poll();
                renderchunk3 = renderglobal$containerlocalrenderinformation1.renderChunk;
                EnumFacing enumfacing2 = renderglobal$containerlocalrenderinformation1.facing;
                this.renderInfos.add(renderglobal$containerlocalrenderinformation1);
                EnumFacing[] var45 = EnumFacing.values();
                int var47 = var45.length;

                for(int var30 = 0; var30 < var47; ++var30) {
                    EnumFacing enumfacing1 = var45[var30];
                    RenderChunk renderchunk2 = this.getRenderChunkOffset(blockpos, renderchunk3, enumfacing1);
                    if ((!flag1 || !renderglobal$containerlocalrenderinformation1.hasDirection(enumfacing1.getOpposite())) && (!flag1 || enumfacing2 == null || renderchunk3.getCompiledChunk().isVisible(enumfacing2.getOpposite(), enumfacing1)) && renderchunk2 != null && renderchunk2.setFrameIndex(p_setupTerrain_5_) && ((ICamera)p_setupTerrain_4_).isBoundingBoxInFrustum(renderchunk2.boundingBox)) {
                        ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation = new ContainerLocalRenderInformation(renderchunk2, enumfacing1, renderglobal$containerlocalrenderinformation1.counter + 1);
                        renderglobal$containerlocalrenderinformation.setDirection(renderglobal$containerlocalrenderinformation1.setFacing, enumfacing1);
                        queue.add(renderglobal$containerlocalrenderinformation);
                    }
                }
            }

            this.mc.mcProfiler.endSection();
        }

        this.mc.mcProfiler.endStartSection("captureFrustum");
        if (this.debugFixTerrainFrustum) {
            this.fixTerrainFrustum(d3, d4, d5);
            this.debugFixTerrainFrustum = false;
        }

        this.mc.mcProfiler.endStartSection("rebuildNear");
        Set<RenderChunk> set = this.chunksToUpdate;
        this.chunksToUpdate = Sets.newLinkedHashSet();
        Iterator var36 = this.renderInfos.iterator();

        while(true) {
            while(true) {
                do {
                    if (!var36.hasNext()) {
                        this.chunksToUpdate.addAll(set);
                        this.mc.mcProfiler.endSection();
                        return;
                    }

                    renderglobal$containerlocalrenderinformation1 = (ContainerLocalRenderInformation)var36.next();
                    renderchunk3 = renderglobal$containerlocalrenderinformation1.renderChunk;
                } while(!renderchunk3.needsUpdate() && !set.contains(renderchunk3));

                this.displayListEntitiesDirty = true;
                BlockPos blockpos2 = renderchunk3.getPosition().add(8, 8, 8);
                boolean flag3 = blockpos2.distanceSq(blockpos1) < 768.0;
                if (!ForgeModContainer.alwaysSetupTerrainOffThread && (renderchunk3.needsImmediateUpdate() || flag3)) {
                    this.mc.mcProfiler.startSection("build near");
                    this.renderDispatcher.updateChunkNow(renderchunk3);
                    renderchunk3.clearNeedsUpdate();
                    this.mc.mcProfiler.endSection();
                } else {
                    this.chunksToUpdate.add(renderchunk3);
                }
            }
        }
    }

    private Set<EnumFacing> getVisibleFacings(BlockPos p_getVisibleFacings_1_) {
        VisGraph visgraph = new VisGraph();
        BlockPos blockpos = new BlockPos(p_getVisibleFacings_1_.getX() >> 4 << 4, p_getVisibleFacings_1_.getY() >> 4 << 4, p_getVisibleFacings_1_.getZ() >> 4 << 4);
        Chunk chunk = this.world.getChunkFromBlockCoords(blockpos);
        Iterator var5 = BlockPos.getAllInBoxMutable(blockpos, blockpos.add(15, 15, 15)).iterator();

        while(var5.hasNext()) {
            BlockPos.MutableBlockPos blockpos$mutableblockpos = (BlockPos.MutableBlockPos)var5.next();
            if (chunk.getBlockState(blockpos$mutableblockpos).isOpaqueCube()) {
                visgraph.setOpaqueCube(blockpos$mutableblockpos);
            }
        }

        return visgraph.getVisibleFacings(p_getVisibleFacings_1_);
    }

    @Nullable
    private RenderChunk getRenderChunkOffset(BlockPos p_getRenderChunkOffset_1_, RenderChunk p_getRenderChunkOffset_2_, EnumFacing p_getRenderChunkOffset_3_) {
        BlockPos blockpos = p_getRenderChunkOffset_2_.getBlockPosOffset16(p_getRenderChunkOffset_3_);
        if (MathHelper.abs(p_getRenderChunkOffset_1_.getX() - blockpos.getX()) > this.renderDistanceChunks * 16) {
            return null;
        } else if (blockpos.getY() >= 0 && blockpos.getY() < 256) {
            return MathHelper.abs(p_getRenderChunkOffset_1_.getZ() - blockpos.getZ()) > this.renderDistanceChunks * 16 ? null : this.viewFrustum.getRenderChunk(blockpos);
        } else {
            return null;
        }
    }

    private void fixTerrainFrustum(double p_fixTerrainFrustum_1_, double p_fixTerrainFrustum_3_, double p_fixTerrainFrustum_5_) {
        this.debugFixedClippingHelper = new ClippingHelperImpl();
        ((ClippingHelperImpl)this.debugFixedClippingHelper).init();
        Matrix4f matrix4f = new Matrix4f(this.debugFixedClippingHelper.modelviewMatrix);
        matrix4f.transpose();
        Matrix4f matrix4f1 = new Matrix4f(this.debugFixedClippingHelper.projectionMatrix);
        matrix4f1.transpose();
        Matrix4f matrix4f2 = new Matrix4f();
        Matrix4f.mul(matrix4f1, matrix4f, matrix4f2);
        matrix4f2.invert();
        this.debugTerrainFrustumPosition.x = p_fixTerrainFrustum_1_;
        this.debugTerrainFrustumPosition.y = p_fixTerrainFrustum_3_;
        this.debugTerrainFrustumPosition.z = p_fixTerrainFrustum_5_;
        this.debugTerrainMatrix[0] = new Vector4f(-1.0F, -1.0F, -1.0F, 1.0F);
        this.debugTerrainMatrix[1] = new Vector4f(1.0F, -1.0F, -1.0F, 1.0F);
        this.debugTerrainMatrix[2] = new Vector4f(1.0F, 1.0F, -1.0F, 1.0F);
        this.debugTerrainMatrix[3] = new Vector4f(-1.0F, 1.0F, -1.0F, 1.0F);
        this.debugTerrainMatrix[4] = new Vector4f(-1.0F, -1.0F, 1.0F, 1.0F);
        this.debugTerrainMatrix[5] = new Vector4f(1.0F, -1.0F, 1.0F, 1.0F);
        this.debugTerrainMatrix[6] = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
        this.debugTerrainMatrix[7] = new Vector4f(-1.0F, 1.0F, 1.0F, 1.0F);

        for(int i = 0; i < 8; ++i) {
            Matrix4f.transform(matrix4f2, this.debugTerrainMatrix[i], this.debugTerrainMatrix[i]);
            Vector4f var10000 = this.debugTerrainMatrix[i];
            var10000.x /= this.debugTerrainMatrix[i].w;
            var10000 = this.debugTerrainMatrix[i];
            var10000.y /= this.debugTerrainMatrix[i].w;
            var10000 = this.debugTerrainMatrix[i];
            var10000.z /= this.debugTerrainMatrix[i].w;
            this.debugTerrainMatrix[i].w = 1.0F;
        }

    }

    protected Vector3f getViewVector(Entity p_getViewVector_1_, double p_getViewVector_2_) {
        float f = (float)((double)p_getViewVector_1_.prevRotationPitch + (double)(p_getViewVector_1_.rotationPitch - p_getViewVector_1_.prevRotationPitch) * p_getViewVector_2_);
        float f1 = (float)((double)p_getViewVector_1_.prevRotationYaw + (double)(p_getViewVector_1_.rotationYaw - p_getViewVector_1_.prevRotationYaw) * p_getViewVector_2_);
        if (Minecraft.getMinecraft().gameSettings.thirdPersonView == 2) {
            f += 180.0F;
        }

        float f2 = MathHelper.cos(-f1 * 0.017453292F - 3.1415927F);
        float f3 = MathHelper.sin(-f1 * 0.017453292F - 3.1415927F);
        float f4 = -MathHelper.cos(-f * 0.017453292F);
        float f5 = MathHelper.sin(-f * 0.017453292F);
        return new Vector3f(f3 * f4, f5, f2 * f4);
    }

    public int renderBlockLayer(BlockRenderLayer p_renderBlockLayer_1_, double p_renderBlockLayer_2_, int p_renderBlockLayer_4_, Entity p_renderBlockLayer_5_) {
        RenderHelper.disableStandardItemLighting();
        if (p_renderBlockLayer_1_ == BlockRenderLayer.TRANSLUCENT) {
            this.mc.mcProfiler.startSection("translucent_sort");
            double d0 = p_renderBlockLayer_5_.posX - this.prevRenderSortX;
            double d1 = p_renderBlockLayer_5_.posY - this.prevRenderSortY;
            double d2 = p_renderBlockLayer_5_.posZ - this.prevRenderSortZ;
            if (d0 * d0 + d1 * d1 + d2 * d2 > 1.0) {
                this.prevRenderSortX = p_renderBlockLayer_5_.posX;
                this.prevRenderSortY = p_renderBlockLayer_5_.posY;
                this.prevRenderSortZ = p_renderBlockLayer_5_.posZ;
                int k = 0;
                Iterator var13 = this.renderInfos.iterator();

                while(var13.hasNext()) {
                    ContainerLocalRenderInformation renderglobal$containerlocalrenderinformation = (ContainerLocalRenderInformation)var13.next();
                    if (renderglobal$containerlocalrenderinformation.renderChunk.compiledChunk.isLayerStarted(p_renderBlockLayer_1_) && k++ < 15) {
                        this.renderDispatcher.updateTransparencyLater(renderglobal$containerlocalrenderinformation.renderChunk);
                    }
                }
            }

            this.mc.mcProfiler.endSection();
        }

        this.mc.mcProfiler.startSection("filterempty");
        int l = 0;
        boolean flag = p_renderBlockLayer_1_ == BlockRenderLayer.TRANSLUCENT;
        int i1 = flag ? this.renderInfos.size() - 1 : 0;
        int i = flag ? -1 : this.renderInfos.size();
        int j1 = flag ? -1 : 1;

        for(int j = i1; j != i; j += j1) {
            RenderChunk renderchunk = ((ContainerLocalRenderInformation)this.renderInfos.get(j)).renderChunk;
            if (!renderchunk.getCompiledChunk().isLayerEmpty(p_renderBlockLayer_1_)) {
                ++l;
                this.renderContainer.addRenderChunk(renderchunk, p_renderBlockLayer_1_);
            }
        }

        this.mc.mcProfiler.func_194339_b(() -> {
            return "render_" + p_renderBlockLayer_1_;
        });
        this.renderBlockLayer(p_renderBlockLayer_1_);
        this.mc.mcProfiler.endSection();
        return l;
    }

    private void renderBlockLayer(BlockRenderLayer p_renderBlockLayer_1_) {
        this.mc.entityRenderer.enableLightmap();
        if (OpenGlHelper.useVbo()) {
            GlStateManager.glEnableClientState(32884);
            OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
            GlStateManager.glEnableClientState(32888);
            OpenGlHelper.setClientActiveTexture(OpenGlHelper.lightmapTexUnit);
            GlStateManager.glEnableClientState(32888);
            OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
            GlStateManager.glEnableClientState(32886);
        }

        this.renderContainer.renderChunkLayer(p_renderBlockLayer_1_);
        if (OpenGlHelper.useVbo()) {
            Iterator var2 = DefaultVertexFormats.BLOCK.getElements().iterator();

            while(var2.hasNext()) {
                VertexFormatElement vertexformatelement = (VertexFormatElement)var2.next();
                VertexFormatElement.EnumUsage vertexformatelement$enumusage = vertexformatelement.getUsage();
                int k1 = vertexformatelement.getIndex();
                switch (vertexformatelement$enumusage) {
                    case POSITION:
                        GlStateManager.glDisableClientState(32884);
                        break;
                    case UV:
                        OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit + k1);
                        GlStateManager.glDisableClientState(32888);
                        OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
                        break;
                    case COLOR:
                        GlStateManager.glDisableClientState(32886);
                        GlStateManager.resetColor();
                }
            }
        }

        this.mc.entityRenderer.disableLightmap();
    }

    private void cleanupDamagedBlocks(Iterator<DestroyBlockProgress> p_cleanupDamagedBlocks_1_) {
        while(p_cleanupDamagedBlocks_1_.hasNext()) {
            DestroyBlockProgress destroyblockprogress = (DestroyBlockProgress)p_cleanupDamagedBlocks_1_.next();
            int k1 = destroyblockprogress.getCreationCloudUpdateTick();
            if (this.cloudTickCounter - k1 > 400) {
                p_cleanupDamagedBlocks_1_.remove();
            }
        }

    }

    public void updateClouds() {
        ++this.cloudTickCounter;
        if (this.cloudTickCounter % 20 == 0) {
            this.cleanupDamagedBlocks(this.damagedBlocks.values().iterator());
        }

        if (!this.setLightUpdates.isEmpty() && !this.renderDispatcher.hasNoFreeRenderBuilders() && this.chunksToUpdate.isEmpty()) {
            Iterator<BlockPos> iterator = this.setLightUpdates.iterator();

            while(iterator.hasNext()) {
                BlockPos blockpos = (BlockPos)iterator.next();
                iterator.remove();
                int k1 = blockpos.getX();
                int l1 = blockpos.getY();
                int i2 = blockpos.getZ();
                this.markBlocksForUpdate(k1 - 1, l1 - 1, i2 - 1, k1 + 1, l1 + 1, i2 + 1, false);
            }
        }

    }

    private void renderSkyEnd() {
        GlStateManager.disableFog();
        GlStateManager.disableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.depthMask(false);
        this.renderEngine.bindTexture(END_SKY_TEXTURES);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();

        for(int k1 = 0; k1 < 6; ++k1) {
            GlStateManager.pushMatrix();
            if (k1 == 1) {
                GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
            }

            if (k1 == 2) {
                GlStateManager.rotate(-90.0F, 1.0F, 0.0F, 0.0F);
            }

            if (k1 == 3) {
                GlStateManager.rotate(180.0F, 1.0F, 0.0F, 0.0F);
            }

            if (k1 == 4) {
                GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
            }

            if (k1 == 5) {
                GlStateManager.rotate(-90.0F, 0.0F, 0.0F, 1.0F);
            }

            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            bufferbuilder.pos(-100.0, -100.0, -100.0).tex(0.0, 0.0).color(40, 40, 40, 255).endVertex();
            bufferbuilder.pos(-100.0, -100.0, 100.0).tex(0.0, 16.0).color(40, 40, 40, 255).endVertex();
            bufferbuilder.pos(100.0, -100.0, 100.0).tex(16.0, 16.0).color(40, 40, 40, 255).endVertex();
            bufferbuilder.pos(100.0, -100.0, -100.0).tex(16.0, 0.0).color(40, 40, 40, 255).endVertex();
            tessellator.draw();
            GlStateManager.popMatrix();
        }

        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
    }

    public void renderSky(float p_renderSky_1_, int p_renderSky_2_) {
        IRenderHandler renderer = this.world.provider.getSkyRenderer();
        if (renderer != null) {
            renderer.render(p_renderSky_1_, this.world, this.mc);
        } else {
            if (this.mc.world.provider.getDimensionType().getId() == 1) {
                this.renderSkyEnd();
            } else if (this.mc.world.provider.isSurfaceWorld()) {
                GlStateManager.disableTexture2D();
                Vec3d vec3d = this.world.getSkyColor(this.mc.getRenderViewEntity(), p_renderSky_1_);
                float f = (float)vec3d.x;
                float f1 = (float)vec3d.y;
                float f2 = (float)vec3d.z;
                if (p_renderSky_2_ != 2) {
                    float f3 = (f * 30.0F + f1 * 59.0F + f2 * 11.0F) / 100.0F;
                    float f4 = (f * 30.0F + f1 * 70.0F) / 100.0F;
                    float f5 = (f * 30.0F + f2 * 70.0F) / 100.0F;
                    f = f3;
                    f1 = f4;
                    f2 = f5;
                }

                GlStateManager.color(f, f1, f2);
                Tessellator tessellator = Tessellator.getInstance();
                BufferBuilder bufferbuilder = tessellator.getBuffer();
                GlStateManager.depthMask(false);
                GlStateManager.enableFog();
                GlStateManager.color(f, f1, f2);
                if (this.vboEnabled) {
                    this.skyVBO.bindBuffer();
                    GlStateManager.glEnableClientState(32884);
                    GlStateManager.glVertexPointer(3, 5126, 12, 0);
                    this.skyVBO.drawArrays(7);
                    this.skyVBO.unbindBuffer();
                    GlStateManager.glDisableClientState(32884);
                } else {
                    GlStateManager.callList(this.glSkyList);
                }

                GlStateManager.disableFog();
                GlStateManager.disableAlpha();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
                RenderHelper.disableStandardItemLighting();
                float[] afloat = this.world.provider.calcSunriseSunsetColors(this.world.getCelestialAngle(p_renderSky_1_), p_renderSky_1_);
                float f6;
                float f7;
                float f21;
                float f12;
                float f13;
                int j2;
                if (afloat != null) {
                    GlStateManager.disableTexture2D();
                    GlStateManager.shadeModel(7425);
                    GlStateManager.pushMatrix();
                    GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
                    GlStateManager.rotate(MathHelper.sin(this.world.getCelestialAngleRadians(p_renderSky_1_)) < 0.0F ? 180.0F : 0.0F, 0.0F, 0.0F, 1.0F);
                    GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
                    f6 = afloat[0];
                    f7 = afloat[1];
                    float f8 = afloat[2];
                    if (p_renderSky_2_ != 2) {
                        float f9 = (f6 * 30.0F + f7 * 59.0F + f8 * 11.0F) / 100.0F;
                        float f10 = (f6 * 30.0F + f7 * 70.0F) / 100.0F;
                        f21 = (f6 * 30.0F + f8 * 70.0F) / 100.0F;
                        f6 = f9;
                        f7 = f10;
                        f8 = f21;
                    }

                    bufferbuilder.begin(6, DefaultVertexFormats.POSITION_COLOR);
                    bufferbuilder.pos(0.0, 100.0, 0.0).color(f6, f7, f8, afloat[3]).endVertex();
                    boolean l1 = true;

                    for(j2 = 0; j2 <= 16; ++j2) {
                        f21 = (float)j2 * 6.2831855F / 16.0F;
                        f12 = MathHelper.sin(f21);
                        f13 = MathHelper.cos(f21);
                        bufferbuilder.pos((double)(f12 * 120.0F), (double)(f13 * 120.0F), (double)(-f13 * 40.0F * afloat[3])).color(afloat[0], afloat[1], afloat[2], 0.0F).endVertex();
                    }

                    tessellator.draw();
                    GlStateManager.popMatrix();
                    GlStateManager.shadeModel(7424);
                }

                GlStateManager.enableTexture2D();
                GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE, SourceFactor.ONE, DestFactor.ZERO);
                GlStateManager.pushMatrix();
                f6 = 1.0F - this.world.getRainStrength(p_renderSky_1_);
                GlStateManager.color(1.0F, 1.0F, 1.0F, f6);
                GlStateManager.rotate(-90.0F, 0.0F, 1.0F, 0.0F);
                GlStateManager.rotate(this.world.getCelestialAngle(p_renderSky_1_) * 360.0F, 1.0F, 0.0F, 0.0F);
                f7 = 30.0F;
                this.renderEngine.bindTexture(SUN_TEXTURES);
                bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                bufferbuilder.pos((double)(-f7), 100.0, (double)(-f7)).tex(0.0, 0.0).endVertex();
                bufferbuilder.pos((double)f7, 100.0, (double)(-f7)).tex(1.0, 0.0).endVertex();
                bufferbuilder.pos((double)f7, 100.0, (double)f7).tex(1.0, 1.0).endVertex();
                bufferbuilder.pos((double)(-f7), 100.0, (double)f7).tex(0.0, 1.0).endVertex();
                tessellator.draw();
                f7 = 20.0F;
                this.renderEngine.bindTexture(MOON_PHASES_TEXTURES);
                int k1 = this.world.getMoonPhase();
                int i2 = k1 % 4;
                j2 = k1 / 4 % 2;
                f21 = (float)(i2 + 0) / 4.0F;
                f12 = (float)(j2 + 0) / 2.0F;
                f13 = (float)(i2 + 1) / 4.0F;
                float f14 = (float)(j2 + 1) / 2.0F;
                bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                bufferbuilder.pos((double)(-f7), -100.0, (double)f7).tex((double)f13, (double)f14).endVertex();
                bufferbuilder.pos((double)f7, -100.0, (double)f7).tex((double)f21, (double)f14).endVertex();
                bufferbuilder.pos((double)f7, -100.0, (double)(-f7)).tex((double)f21, (double)f12).endVertex();
                bufferbuilder.pos((double)(-f7), -100.0, (double)(-f7)).tex((double)f13, (double)f12).endVertex();
                tessellator.draw();
                GlStateManager.disableTexture2D();
                float f15 = this.world.getStarBrightness(p_renderSky_1_) * f6;
                if (f15 > 0.0F) {
                    GlStateManager.color(f15, f15, f15, f15);
                    if (this.vboEnabled) {
                        this.starVBO.bindBuffer();
                        GlStateManager.glEnableClientState(32884);
                        GlStateManager.glVertexPointer(3, 5126, 12, 0);
                        this.starVBO.drawArrays(7);
                        this.starVBO.unbindBuffer();
                        GlStateManager.glDisableClientState(32884);
                    } else {
                        GlStateManager.callList(this.starGLCallList);
                    }
                }

                GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
                GlStateManager.disableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableFog();
                GlStateManager.popMatrix();
                GlStateManager.disableTexture2D();
                GlStateManager.color(0.0F, 0.0F, 0.0F);
                double d3 = this.mc.player.getPositionEyes(p_renderSky_1_).y - this.world.getHorizon();
                if (d3 < 0.0) {
                    GlStateManager.pushMatrix();
                    GlStateManager.translate(0.0F, 12.0F, 0.0F);
                    if (this.vboEnabled) {
                        this.sky2VBO.bindBuffer();
                        GlStateManager.glEnableClientState(32884);
                        GlStateManager.glVertexPointer(3, 5126, 12, 0);
                        this.sky2VBO.drawArrays(7);
                        this.sky2VBO.unbindBuffer();
                        GlStateManager.glDisableClientState(32884);
                    } else {
                        GlStateManager.callList(this.glSkyList2);
                    }

                    GlStateManager.popMatrix();
                    float f18 = 1.0F;
                    float f19 = -((float)(d3 + 65.0));
                    float f20 = -1.0F;
                    bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
                    bufferbuilder.pos(-1.0, (double)f19, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, (double)f19, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, (double)f19, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, (double)f19, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, (double)f19, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, (double)f19, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, (double)f19, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, (double)f19, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(-1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, 1.0).color(0, 0, 0, 255).endVertex();
                    bufferbuilder.pos(1.0, -1.0, -1.0).color(0, 0, 0, 255).endVertex();
                    tessellator.draw();
                }

                if (this.world.provider.isSkyColored()) {
                    GlStateManager.color(f * 0.2F + 0.04F, f1 * 0.2F + 0.04F, f2 * 0.6F + 0.1F);
                } else {
                    GlStateManager.color(f, f1, f2);
                }

                GlStateManager.pushMatrix();
                GlStateManager.translate(0.0F, -((float)(d3 - 16.0)), 0.0F);
                GlStateManager.callList(this.glSkyList2);
                GlStateManager.popMatrix();
                GlStateManager.enableTexture2D();
                GlStateManager.depthMask(true);
            }

        }
    }

    public void renderClouds(float p_renderClouds_1_, int p_renderClouds_2_, double p_renderClouds_3_, double p_renderClouds_5_, double p_renderClouds_7_) {
        if (!FMLClientHandler.instance().renderClouds(this.cloudTickCounter, p_renderClouds_1_)) {
            if (this.mc.world.provider.isSurfaceWorld()) {
                if (this.mc.gameSettings.shouldRenderClouds() == 2) {
                    this.renderCloudsFancy(p_renderClouds_1_, p_renderClouds_2_, p_renderClouds_3_, p_renderClouds_5_, p_renderClouds_7_);
                } else {
                    GlStateManager.disableCull();
                    boolean k1 = true;
                    boolean l1 = true;
                    Tessellator tessellator = Tessellator.getInstance();
                    BufferBuilder bufferbuilder = tessellator.getBuffer();
                    this.renderEngine.bindTexture(CLOUDS_TEXTURES);
                    GlStateManager.enableBlend();
                    GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
                    Vec3d vec3d = this.world.getCloudColour(p_renderClouds_1_);
                    float f = (float)vec3d.x;
                    float f1 = (float)vec3d.y;
                    float f2 = (float)vec3d.z;
                    float f9;
                    if (p_renderClouds_2_ != 2) {
                        f9 = (f * 30.0F + f1 * 59.0F + f2 * 11.0F) / 100.0F;
                        float f4 = (f * 30.0F + f1 * 70.0F) / 100.0F;
                        float f5 = (f * 30.0F + f2 * 70.0F) / 100.0F;
                        f = f9;
                        f1 = f4;
                        f2 = f5;
                    }

                    f9 = 4.8828125E-4F;
                    double d5 = (double)((float)this.cloudTickCounter + p_renderClouds_1_);
                    double d3 = p_renderClouds_3_ + d5 * 0.029999999329447746;
                    int i2 = MathHelper.floor(d3 / 2048.0);
                    int j2 = MathHelper.floor(p_renderClouds_7_ / 2048.0);
                    d3 -= (double)(i2 * 2048);
                    double lvt_22_1_ = p_renderClouds_7_ - (double)(j2 * 2048);
                    float f6 = this.world.provider.getCloudHeight() - (float)p_renderClouds_5_ + 0.33F;
                    float f7 = (float)(d3 * 4.8828125E-4);
                    float f8 = (float)(lvt_22_1_ * 4.8828125E-4);
                    bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);

                    for(int k2 = -256; k2 < 256; k2 += 32) {
                        for(int l2 = -256; l2 < 256; l2 += 32) {
                            bufferbuilder.pos((double)(k2 + 0), (double)f6, (double)(l2 + 32)).tex((double)((float)(k2 + 0) * 4.8828125E-4F + f7), (double)((float)(l2 + 32) * 4.8828125E-4F + f8)).color(f, f1, f2, 0.8F).endVertex();
                            bufferbuilder.pos((double)(k2 + 32), (double)f6, (double)(l2 + 32)).tex((double)((float)(k2 + 32) * 4.8828125E-4F + f7), (double)((float)(l2 + 32) * 4.8828125E-4F + f8)).color(f, f1, f2, 0.8F).endVertex();
                            bufferbuilder.pos((double)(k2 + 32), (double)f6, (double)(l2 + 0)).tex((double)((float)(k2 + 32) * 4.8828125E-4F + f7), (double)((float)(l2 + 0) * 4.8828125E-4F + f8)).color(f, f1, f2, 0.8F).endVertex();
                            bufferbuilder.pos((double)(k2 + 0), (double)f6, (double)(l2 + 0)).tex((double)((float)(k2 + 0) * 4.8828125E-4F + f7), (double)((float)(l2 + 0) * 4.8828125E-4F + f8)).color(f, f1, f2, 0.8F).endVertex();
                        }
                    }

                    tessellator.draw();
                    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
                    GlStateManager.disableBlend();
                    GlStateManager.enableCull();
                }
            }

        }
    }

    public boolean hasCloudFog(double p_hasCloudFog_1_, double p_hasCloudFog_3_, double p_hasCloudFog_5_, float p_hasCloudFog_7_) {
        return false;
    }

    private void renderCloudsFancy(float p_renderCloudsFancy_1_, int p_renderCloudsFancy_2_, double p_renderCloudsFancy_3_, double p_renderCloudsFancy_5_, double p_renderCloudsFancy_7_) {
        GlStateManager.disableCull();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        float f = 12.0F;
        float f1 = 4.0F;
        double d3 = (double)((float)this.cloudTickCounter + p_renderCloudsFancy_1_);
        double d4 = (p_renderCloudsFancy_3_ + d3 * 0.029999999329447746) / 12.0;
        double d5 = p_renderCloudsFancy_7_ / 12.0 + 0.33000001311302185;
        float f2 = this.world.provider.getCloudHeight() - (float)p_renderCloudsFancy_5_ + 0.33F;
        int k1 = MathHelper.floor(d4 / 2048.0);
        int l1 = MathHelper.floor(d5 / 2048.0);
        d4 -= (double)(k1 * 2048);
        d5 -= (double)(l1 * 2048);
        this.renderEngine.bindTexture(CLOUDS_TEXTURES);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
        Vec3d vec3d = this.world.getCloudColour(p_renderCloudsFancy_1_);
        float f3 = (float)vec3d.x;
        float f4 = (float)vec3d.y;
        float f5 = (float)vec3d.z;
        float f25;
        float f26;
        float f27;
        if (p_renderCloudsFancy_2_ != 2) {
            f25 = (f3 * 30.0F + f4 * 59.0F + f5 * 11.0F) / 100.0F;
            f26 = (f3 * 30.0F + f4 * 70.0F) / 100.0F;
            f27 = (f3 * 30.0F + f5 * 70.0F) / 100.0F;
            f3 = f25;
            f4 = f26;
            f5 = f27;
        }

        f25 = f3 * 0.9F;
        f26 = f4 * 0.9F;
        f27 = f5 * 0.9F;
        float f9 = f3 * 0.7F;
        float f10 = f4 * 0.7F;
        float f11 = f5 * 0.7F;
        float f12 = f3 * 0.8F;
        float f13 = f4 * 0.8F;
        float f14 = f5 * 0.8F;
        float f15 = 0.00390625F;
        float f16 = (float)MathHelper.floor(d4) * 0.00390625F;
        float f17 = (float)MathHelper.floor(d5) * 0.00390625F;
        float f18 = (float)(d4 - (double)MathHelper.floor(d4));
        float f19 = (float)(d5 - (double)MathHelper.floor(d5));
        boolean i2 = true;
        boolean j2 = true;
        float f20 = 9.765625E-4F;
        GlStateManager.scale(12.0F, 1.0F, 12.0F);

        for(int k2 = 0; k2 < 2; ++k2) {
            if (k2 == 0) {
                GlStateManager.colorMask(false, false, false, false);
            } else {
                switch (p_renderCloudsFancy_2_) {
                    case 0:
                        GlStateManager.colorMask(false, true, true, true);
                        break;
                    case 1:
                        GlStateManager.colorMask(true, false, false, true);
                        break;
                    case 2:
                        GlStateManager.colorMask(true, true, true, true);
                }
            }

            for(int l2 = -3; l2 <= 4; ++l2) {
                for(int i3 = -3; i3 <= 4; ++i3) {
                    bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR_NORMAL);
                    float f21 = (float)(l2 * 8);
                    float f22 = (float)(i3 * 8);
                    float f23 = f21 - f18;
                    float f24 = f22 - f19;
                    if (f2 > -5.0F) {
                        bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + 8.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f9, f10, f11, 0.8F).normal(0.0F, -1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 0.0F), (double)(f24 + 8.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f9, f10, f11, 0.8F).normal(0.0F, -1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 0.0F), (double)(f24 + 0.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f9, f10, f11, 0.8F).normal(0.0F, -1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + 0.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f9, f10, f11, 0.8F).normal(0.0F, -1.0F, 0.0F).endVertex();
                    }

                    if (f2 <= 5.0F) {
                        bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 4.0F - 9.765625E-4F), (double)(f24 + 8.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f3, f4, f5, 0.8F).normal(0.0F, 1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 4.0F - 9.765625E-4F), (double)(f24 + 8.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f3, f4, f5, 0.8F).normal(0.0F, 1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 4.0F - 9.765625E-4F), (double)(f24 + 0.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f3, f4, f5, 0.8F).normal(0.0F, 1.0F, 0.0F).endVertex();
                        bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 4.0F - 9.765625E-4F), (double)(f24 + 0.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f3, f4, f5, 0.8F).normal(0.0F, 1.0F, 0.0F).endVertex();
                    }

                    int i4;
                    if (l2 > -1) {
                        for(i4 = 0; i4 < 8; ++i4) {
                            bufferbuilder.pos((double)(f23 + (float)i4 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + 8.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(-1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 0.0F), (double)(f2 + 4.0F), (double)(f24 + 8.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(-1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 0.0F), (double)(f2 + 4.0F), (double)(f24 + 0.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(-1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + 0.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(-1.0F, 0.0F, 0.0F).endVertex();
                        }
                    }

                    if (l2 <= 1) {
                        for(i4 = 0; i4 < 8; ++i4) {
                            bufferbuilder.pos((double)(f23 + (float)i4 + 1.0F - 9.765625E-4F), (double)(f2 + 0.0F), (double)(f24 + 8.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 1.0F - 9.765625E-4F), (double)(f2 + 4.0F), (double)(f24 + 8.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 8.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 1.0F - 9.765625E-4F), (double)(f2 + 4.0F), (double)(f24 + 0.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(1.0F, 0.0F, 0.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + (float)i4 + 1.0F - 9.765625E-4F), (double)(f2 + 0.0F), (double)(f24 + 0.0F)).tex((double)((f21 + (float)i4 + 0.5F) * 0.00390625F + f16), (double)((f22 + 0.0F) * 0.00390625F + f17)).color(f25, f26, f27, 0.8F).normal(1.0F, 0.0F, 0.0F).endVertex();
                        }
                    }

                    if (i3 > -1) {
                        for(i4 = 0; i4 < 8; ++i4) {
                            bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 4.0F), (double)(f24 + (float)i4 + 0.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, -1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 4.0F), (double)(f24 + (float)i4 + 0.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, -1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 0.0F), (double)(f24 + (float)i4 + 0.0F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, -1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + (float)i4 + 0.0F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, -1.0F).endVertex();
                        }
                    }

                    if (i3 <= 1) {
                        for(i4 = 0; i4 < 8; ++i4) {
                            bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 4.0F), (double)(f24 + (float)i4 + 1.0F - 9.765625E-4F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, 1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 4.0F), (double)(f24 + (float)i4 + 1.0F - 9.765625E-4F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, 1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 8.0F), (double)(f2 + 0.0F), (double)(f24 + (float)i4 + 1.0F - 9.765625E-4F)).tex((double)((f21 + 8.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, 1.0F).endVertex();
                            bufferbuilder.pos((double)(f23 + 0.0F), (double)(f2 + 0.0F), (double)(f24 + (float)i4 + 1.0F - 9.765625E-4F)).tex((double)((f21 + 0.0F) * 0.00390625F + f16), (double)((f22 + (float)i4 + 0.5F) * 0.00390625F + f17)).color(f12, f13, f14, 0.8F).normal(0.0F, 0.0F, 1.0F).endVertex();
                        }
                    }

                    tessellator.draw();
                }
            }
        }

        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
    }

    public void updateChunks(long p_updateChunks_1_) {
        this.displayListEntitiesDirty |= this.renderDispatcher.runChunkUploads(p_updateChunks_1_);
        if (!this.chunksToUpdate.isEmpty()) {
            Iterator<RenderChunk> iterator = this.chunksToUpdate.iterator();

            while(iterator.hasNext()) {
                RenderChunk renderchunk1 = (RenderChunk)iterator.next();
                boolean flag1;
                if (renderchunk1.needsImmediateUpdate()) {
                    flag1 = this.renderDispatcher.updateChunkNow(renderchunk1);
                } else {
                    flag1 = this.renderDispatcher.updateChunkLater(renderchunk1);
                }

                if (!flag1) {
                    break;
                }

                renderchunk1.clearNeedsUpdate();
                iterator.remove();
                long k1 = p_updateChunks_1_ - System.nanoTime();
                if (k1 < 0L) {
                    break;
                }
            }
        }

    }

    public void renderWorldBorder(Entity p_renderWorldBorder_1_, float p_renderWorldBorder_2_) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        WorldBorder worldborder = this.world.getWorldBorder();
        double d3 = (double)(this.mc.gameSettings.renderDistanceChunks * 16);
        if (p_renderWorldBorder_1_.posX >= worldborder.maxX() - d3 || p_renderWorldBorder_1_.posX <= worldborder.minX() + d3 || p_renderWorldBorder_1_.posZ >= worldborder.maxZ() - d3 || p_renderWorldBorder_1_.posZ <= worldborder.minZ() + d3) {
            double d4 = 1.0 - worldborder.getClosestDistance(p_renderWorldBorder_1_) / d3;
            d4 = Math.pow(d4, 4.0);
            double d5 = p_renderWorldBorder_1_.lastTickPosX + (p_renderWorldBorder_1_.posX - p_renderWorldBorder_1_.lastTickPosX) * (double)p_renderWorldBorder_2_;
            double d6 = p_renderWorldBorder_1_.lastTickPosY + (p_renderWorldBorder_1_.posY - p_renderWorldBorder_1_.lastTickPosY) * (double)p_renderWorldBorder_2_;
            double d7 = p_renderWorldBorder_1_.lastTickPosZ + (p_renderWorldBorder_1_.posZ - p_renderWorldBorder_1_.lastTickPosZ) * (double)p_renderWorldBorder_2_;
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE, SourceFactor.ONE, DestFactor.ZERO);
            this.renderEngine.bindTexture(FORCEFIELD_TEXTURES);
            GlStateManager.depthMask(false);
            GlStateManager.pushMatrix();
            int k1 = worldborder.getStatus().getColor();
            float f = (float)(k1 >> 16 & 255) / 255.0F;
            float f1 = (float)(k1 >> 8 & 255) / 255.0F;
            float f2 = (float)(k1 & 255) / 255.0F;
            GlStateManager.color(f, f1, f2, (float)d4);
            GlStateManager.doPolygonOffset(-3.0F, -3.0F);
            GlStateManager.enablePolygonOffset();
            GlStateManager.alphaFunc(516, 0.1F);
            GlStateManager.enableAlpha();
            GlStateManager.disableCull();
            float f3 = (float)(Minecraft.getSystemTime() % 3000L) / 3000.0F;
            float f4 = 0.0F;
            float f5 = 0.0F;
            float f6 = 128.0F;
            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
            bufferbuilder.setTranslation(-d5, -d6, -d7);
            double d8 = Math.max((double)MathHelper.floor(d7 - d3), worldborder.minZ());
            double d9 = Math.min((double)MathHelper.ceil(d7 + d3), worldborder.maxZ());
            float f11;
            double d14;
            double d17;
            float f14;
            if (d5 > worldborder.maxX() - d3) {
                f11 = 0.0F;

                for(d14 = d8; d14 < d9; f11 += 0.5F) {
                    d17 = Math.min(1.0, d9 - d14);
                    f14 = (float)d17 * 0.5F;
                    bufferbuilder.pos(worldborder.maxX(), 256.0, d14).tex((double)(f3 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(worldborder.maxX(), 256.0, d14 + d17).tex((double)(f3 + f14 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(worldborder.maxX(), 0.0, d14 + d17).tex((double)(f3 + f14 + f11), (double)(f3 + 128.0F)).endVertex();
                    bufferbuilder.pos(worldborder.maxX(), 0.0, d14).tex((double)(f3 + f11), (double)(f3 + 128.0F)).endVertex();
                    ++d14;
                }
            }

            if (d5 < worldborder.minX() + d3) {
                f11 = 0.0F;

                for(d14 = d8; d14 < d9; f11 += 0.5F) {
                    d17 = Math.min(1.0, d9 - d14);
                    f14 = (float)d17 * 0.5F;
                    bufferbuilder.pos(worldborder.minX(), 256.0, d14).tex((double)(f3 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(worldborder.minX(), 256.0, d14 + d17).tex((double)(f3 + f14 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(worldborder.minX(), 0.0, d14 + d17).tex((double)(f3 + f14 + f11), (double)(f3 + 128.0F)).endVertex();
                    bufferbuilder.pos(worldborder.minX(), 0.0, d14).tex((double)(f3 + f11), (double)(f3 + 128.0F)).endVertex();
                    ++d14;
                }
            }

            d8 = Math.max((double)MathHelper.floor(d5 - d3), worldborder.minX());
            d9 = Math.min((double)MathHelper.ceil(d5 + d3), worldborder.maxX());
            if (d7 > worldborder.maxZ() - d3) {
                f11 = 0.0F;

                for(d14 = d8; d14 < d9; f11 += 0.5F) {
                    d17 = Math.min(1.0, d9 - d14);
                    f14 = (float)d17 * 0.5F;
                    bufferbuilder.pos(d14, 256.0, worldborder.maxZ()).tex((double)(f3 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(d14 + d17, 256.0, worldborder.maxZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(d14 + d17, 0.0, worldborder.maxZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 128.0F)).endVertex();
                    bufferbuilder.pos(d14, 0.0, worldborder.maxZ()).tex((double)(f3 + f11), (double)(f3 + 128.0F)).endVertex();
                    ++d14;
                }
            }

            if (d7 < worldborder.minZ() + d3) {
                f11 = 0.0F;

                for(d14 = d8; d14 < d9; f11 += 0.5F) {
                    d17 = Math.min(1.0, d9 - d14);
                    f14 = (float)d17 * 0.5F;
                    bufferbuilder.pos(d14, 256.0, worldborder.minZ()).tex((double)(f3 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(d14 + d17, 256.0, worldborder.minZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 0.0F)).endVertex();
                    bufferbuilder.pos(d14 + d17, 0.0, worldborder.minZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 128.0F)).endVertex();
                    bufferbuilder.pos(d14, 0.0, worldborder.minZ()).tex((double)(f3 + f11), (double)(f3 + 128.0F)).endVertex();
                    ++d14;
                }
            }

            tessellator.draw();
            bufferbuilder.setTranslation(0.0, 0.0, 0.0);
            GlStateManager.enableCull();
            GlStateManager.disableAlpha();
            GlStateManager.doPolygonOffset(0.0F, 0.0F);
            GlStateManager.disablePolygonOffset();
            GlStateManager.enableAlpha();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
            GlStateManager.depthMask(true);
        }

    }

    private void preRenderDamagedBlocks() {
        GlStateManager.tryBlendFuncSeparate(SourceFactor.DST_COLOR, DestFactor.SRC_COLOR, SourceFactor.ONE, DestFactor.ZERO);
        GlStateManager.enableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 0.5F);
        GlStateManager.doPolygonOffset(-1.0F, -10.0F);
        GlStateManager.enablePolygonOffset();
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.enableAlpha();
        GlStateManager.pushMatrix();
    }

    private void postRenderDamagedBlocks() {
        GlStateManager.disableAlpha();
        GlStateManager.doPolygonOffset(0.0F, 0.0F);
        GlStateManager.disablePolygonOffset();
        GlStateManager.enableAlpha();
        GlStateManager.depthMask(true);
        GlStateManager.popMatrix();
    }

    public void drawBlockDamageTexture(Tessellator p_drawBlockDamageTexture_1_, BufferBuilder p_drawBlockDamageTexture_2_, Entity p_drawBlockDamageTexture_3_, float p_drawBlockDamageTexture_4_) {
        double d3 = p_drawBlockDamageTexture_3_.lastTickPosX + (p_drawBlockDamageTexture_3_.posX - p_drawBlockDamageTexture_3_.lastTickPosX) * (double)p_drawBlockDamageTexture_4_;
        double d4 = p_drawBlockDamageTexture_3_.lastTickPosY + (p_drawBlockDamageTexture_3_.posY - p_drawBlockDamageTexture_3_.lastTickPosY) * (double)p_drawBlockDamageTexture_4_;
        double d5 = p_drawBlockDamageTexture_3_.lastTickPosZ + (p_drawBlockDamageTexture_3_.posZ - p_drawBlockDamageTexture_3_.lastTickPosZ) * (double)p_drawBlockDamageTexture_4_;
        if (!this.damagedBlocks.isEmpty()) {
            this.renderEngine.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
            this.preRenderDamagedBlocks();
            p_drawBlockDamageTexture_2_.begin(7, DefaultVertexFormats.BLOCK);
            p_drawBlockDamageTexture_2_.setTranslation(-d3, -d4, -d5);
            p_drawBlockDamageTexture_2_.noColor();
            Iterator<DestroyBlockProgress> iterator = this.damagedBlocks.values().iterator();

            while(iterator.hasNext()) {
                DestroyBlockProgress destroyblockprogress = (DestroyBlockProgress)iterator.next();
                BlockPos blockpos = destroyblockprogress.getPosition();
                double d6 = (double)blockpos.getX() - d3;
                double d7 = (double)blockpos.getY() - d4;
                double d8 = (double)blockpos.getZ() - d5;
                Block block = this.world.getBlockState(blockpos).getBlock();
                TileEntity te = this.world.getTileEntity(blockpos);
                boolean hasBreak = block instanceof BlockChest || block instanceof BlockEnderChest || block instanceof BlockSign || block instanceof BlockSkull;
                if (!hasBreak) {
                    hasBreak = te != null && te.canRenderBreaking();
                }

                if (!hasBreak) {
                    if (d6 * d6 + d7 * d7 + d8 * d8 > 1024.0) {
                        iterator.remove();
                    } else {
                        IBlockState iblockstate = this.world.getBlockState(blockpos);
                        if (iblockstate.getMaterial() != Material.AIR) {
                            int k1 = destroyblockprogress.getPartialBlockDamage();
                            TextureAtlasSprite textureatlassprite = this.destroyBlockIcons[k1];
                            BlockRendererDispatcher blockrendererdispatcher = this.mc.getBlockRendererDispatcher();
                            blockrendererdispatcher.renderBlockDamage(iblockstate, blockpos, textureatlassprite, this.world);
                        }
                    }
                }
            }

            p_drawBlockDamageTexture_1_.draw();
            p_drawBlockDamageTexture_2_.setTranslation(0.0, 0.0, 0.0);
            this.postRenderDamagedBlocks();
        }

    }

    public void drawSelectionBox(EntityPlayer p_drawSelectionBox_1_, RayTraceResult p_drawSelectionBox_2_, int p_drawSelectionBox_3_, float p_drawSelectionBox_4_) {
        if (p_drawSelectionBox_3_ == 0 && p_drawSelectionBox_2_.typeOfHit == Type.BLOCK) {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
            GlStateManager.glLineWidth(2.0F);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
            BlockPos blockpos = p_drawSelectionBox_2_.getBlockPos();
            IBlockState iblockstate = this.world.getBlockState(blockpos);
            if (iblockstate.getMaterial() != Material.AIR && this.world.getWorldBorder().contains(blockpos)) {
                double d3 = p_drawSelectionBox_1_.lastTickPosX + (p_drawSelectionBox_1_.posX - p_drawSelectionBox_1_.lastTickPosX) * (double)p_drawSelectionBox_4_;
                double d4 = p_drawSelectionBox_1_.lastTickPosY + (p_drawSelectionBox_1_.posY - p_drawSelectionBox_1_.lastTickPosY) * (double)p_drawSelectionBox_4_;
                double d5 = p_drawSelectionBox_1_.lastTickPosZ + (p_drawSelectionBox_1_.posZ - p_drawSelectionBox_1_.lastTickPosZ) * (double)p_drawSelectionBox_4_;
                drawSelectionBoundingBox(iblockstate.getSelectedBoundingBox(this.world, blockpos).grow(0.0020000000949949026).offset(-d3, -d4, -d5), 0.0F, 0.0F, 0.0F, 0.4F);
            }

            GlStateManager.depthMask(true);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
        }

    }

    public static void drawSelectionBoundingBox(AxisAlignedBB p_drawSelectionBoundingBox_0_, float p_drawSelectionBoundingBox_1_, float p_drawSelectionBoundingBox_2_, float p_drawSelectionBoundingBox_3_, float p_drawSelectionBoundingBox_4_) {
        drawBoundingBox(p_drawSelectionBoundingBox_0_.minX, p_drawSelectionBoundingBox_0_.minY, p_drawSelectionBoundingBox_0_.minZ, p_drawSelectionBoundingBox_0_.maxX, p_drawSelectionBoundingBox_0_.maxY, p_drawSelectionBoundingBox_0_.maxZ, p_drawSelectionBoundingBox_1_, p_drawSelectionBoundingBox_2_, p_drawSelectionBoundingBox_3_, p_drawSelectionBoundingBox_4_);
    }

    public static void drawBoundingBox(double p_drawBoundingBox_0_, double p_drawBoundingBox_2_, double p_drawBoundingBox_4_, double p_drawBoundingBox_6_, double p_drawBoundingBox_8_, double p_drawBoundingBox_10_, float p_drawBoundingBox_12_, float p_drawBoundingBox_13_, float p_drawBoundingBox_14_, float p_drawBoundingBox_15_) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
        drawBoundingBox(bufferbuilder, p_drawBoundingBox_0_, p_drawBoundingBox_2_, p_drawBoundingBox_4_, p_drawBoundingBox_6_, p_drawBoundingBox_8_, p_drawBoundingBox_10_, p_drawBoundingBox_12_, p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_);
        tessellator.draw();
    }

    public static void drawBoundingBox(BufferBuilder p_drawBoundingBox_0_, double p_drawBoundingBox_1_, double p_drawBoundingBox_3_, double p_drawBoundingBox_5_, double p_drawBoundingBox_7_, double p_drawBoundingBox_9_, double p_drawBoundingBox_11_, float p_drawBoundingBox_13_, float p_drawBoundingBox_14_, float p_drawBoundingBox_15_, float p_drawBoundingBox_16_) {
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, 0.0F).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_3_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_3_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_9_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_9_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_9_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_9_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_9_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_9_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, 0.0F).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_1_, p_drawBoundingBox_3_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_9_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, 0.0F).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_3_, p_drawBoundingBox_11_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_9_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, 0.0F).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, p_drawBoundingBox_16_).endVertex();
        p_drawBoundingBox_0_.pos(p_drawBoundingBox_7_, p_drawBoundingBox_3_, p_drawBoundingBox_5_).color(p_drawBoundingBox_13_, p_drawBoundingBox_14_, p_drawBoundingBox_15_, 0.0F).endVertex();
    }

    public static void renderFilledBox(AxisAlignedBB p_renderFilledBox_0_, float p_renderFilledBox_1_, float p_renderFilledBox_2_, float p_renderFilledBox_3_, float p_renderFilledBox_4_) {
        renderFilledBox(p_renderFilledBox_0_.minX, p_renderFilledBox_0_.minY, p_renderFilledBox_0_.minZ, p_renderFilledBox_0_.maxX, p_renderFilledBox_0_.maxY, p_renderFilledBox_0_.maxZ, p_renderFilledBox_1_, p_renderFilledBox_2_, p_renderFilledBox_3_, p_renderFilledBox_4_);
    }

    public static void renderFilledBox(double p_renderFilledBox_0_, double p_renderFilledBox_2_, double p_renderFilledBox_4_, double p_renderFilledBox_6_, double p_renderFilledBox_8_, double p_renderFilledBox_10_, float p_renderFilledBox_12_, float p_renderFilledBox_13_, float p_renderFilledBox_14_, float p_renderFilledBox_15_) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(5, DefaultVertexFormats.POSITION_COLOR);
        addChainedFilledBoxVertices(bufferbuilder, p_renderFilledBox_0_, p_renderFilledBox_2_, p_renderFilledBox_4_, p_renderFilledBox_6_, p_renderFilledBox_8_, p_renderFilledBox_10_, p_renderFilledBox_12_, p_renderFilledBox_13_, p_renderFilledBox_14_, p_renderFilledBox_15_);
        tessellator.draw();
    }

    public static void addChainedFilledBoxVertices(BufferBuilder p_addChainedFilledBoxVertices_0_, double p_addChainedFilledBoxVertices_1_, double p_addChainedFilledBoxVertices_3_, double p_addChainedFilledBoxVertices_5_, double p_addChainedFilledBoxVertices_7_, double p_addChainedFilledBoxVertices_9_, double p_addChainedFilledBoxVertices_11_, float p_addChainedFilledBoxVertices_13_, float p_addChainedFilledBoxVertices_14_, float p_addChainedFilledBoxVertices_15_, float p_addChainedFilledBoxVertices_16_) {
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_3_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_1_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_5_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
        p_addChainedFilledBoxVertices_0_.pos(p_addChainedFilledBoxVertices_7_, p_addChainedFilledBoxVertices_9_, p_addChainedFilledBoxVertices_11_).color(p_addChainedFilledBoxVertices_13_, p_addChainedFilledBoxVertices_14_, p_addChainedFilledBoxVertices_15_, p_addChainedFilledBoxVertices_16_).endVertex();
    }

    private void markBlocksForUpdate(int p_markBlocksForUpdate_1_, int p_markBlocksForUpdate_2_, int p_markBlocksForUpdate_3_, int p_markBlocksForUpdate_4_, int p_markBlocksForUpdate_5_, int p_markBlocksForUpdate_6_, boolean p_markBlocksForUpdate_7_) {
        this.viewFrustum.markBlocksForUpdate(p_markBlocksForUpdate_1_, p_markBlocksForUpdate_2_, p_markBlocksForUpdate_3_, p_markBlocksForUpdate_4_, p_markBlocksForUpdate_5_, p_markBlocksForUpdate_6_, p_markBlocksForUpdate_7_);
    }

    public void notifyBlockUpdate(World p_notifyBlockUpdate_1_, BlockPos p_notifyBlockUpdate_2_, IBlockState p_notifyBlockUpdate_3_, IBlockState p_notifyBlockUpdate_4_, int p_notifyBlockUpdate_5_) {
        int k1 = p_notifyBlockUpdate_2_.getX();
        int l1 = p_notifyBlockUpdate_2_.getY();
        int i2 = p_notifyBlockUpdate_2_.getZ();
        this.markBlocksForUpdate(k1 - 1, l1 - 1, i2 - 1, k1 + 1, l1 + 1, i2 + 1, (p_notifyBlockUpdate_5_ & 8) != 0);
    }

    public void notifyLightSet(BlockPos p_notifyLightSet_1_) {
        this.setLightUpdates.add(p_notifyLightSet_1_.toImmutable());
    }

    public void markBlockRangeForRenderUpdate(int p_markBlockRangeForRenderUpdate_1_, int p_markBlockRangeForRenderUpdate_2_, int p_markBlockRangeForRenderUpdate_3_, int p_markBlockRangeForRenderUpdate_4_, int p_markBlockRangeForRenderUpdate_5_, int p_markBlockRangeForRenderUpdate_6_) {
        this.markBlocksForUpdate(p_markBlockRangeForRenderUpdate_1_ - 1, p_markBlockRangeForRenderUpdate_2_ - 1, p_markBlockRangeForRenderUpdate_3_ - 1, p_markBlockRangeForRenderUpdate_4_ + 1, p_markBlockRangeForRenderUpdate_5_ + 1, p_markBlockRangeForRenderUpdate_6_ + 1, false);
    }

    public void playRecord(@Nullable SoundEvent p_playRecord_1_, BlockPos p_playRecord_2_) {
        ISound isound = (ISound)this.mapSoundPositions.get(p_playRecord_2_);
        if (isound != null) {
            this.mc.getSoundHandler().stopSound(isound);
            this.mapSoundPositions.remove(p_playRecord_2_);
        }

        if (p_playRecord_1_ != null) {
            ItemRecord itemrecord = ItemRecord.getBySound(p_playRecord_1_);
            if (itemrecord != null) {
                this.mc.ingameGUI.setRecordPlayingMessage(itemrecord.getRecordNameLocal());
            }

            ISound positionedsoundrecord = PositionedSoundRecord.getRecordSoundRecord(p_playRecord_1_, (float)p_playRecord_2_.getX(), (float)p_playRecord_2_.getY(), (float)p_playRecord_2_.getZ());
            this.mapSoundPositions.put(p_playRecord_2_, positionedsoundrecord);
            this.mc.getSoundHandler().playSound(positionedsoundrecord);
        }

        this.setPartying(this.world, p_playRecord_2_, p_playRecord_1_ != null);
    }

    private void setPartying(World p_setPartying_1_, BlockPos p_setPartying_2_, boolean p_setPartying_3_) {
        Iterator var4 = p_setPartying_1_.getEntitiesWithinAABB(EntityLivingBase.class, (new AxisAlignedBB(p_setPartying_2_)).grow(3.0)).iterator();

        while(var4.hasNext()) {
            EntityLivingBase entitylivingbase = (EntityLivingBase)var4.next();
            entitylivingbase.setPartying(p_setPartying_2_, p_setPartying_3_);
        }

    }

    public void playSoundToAllNearExcept(@Nullable EntityPlayer p_playSoundToAllNearExcept_1_, SoundEvent p_playSoundToAllNearExcept_2_, SoundCategory p_playSoundToAllNearExcept_3_, double p_playSoundToAllNearExcept_4_, double p_playSoundToAllNearExcept_6_, double p_playSoundToAllNearExcept_8_, float p_playSoundToAllNearExcept_10_, float p_playSoundToAllNearExcept_11_) {
    }

    public void spawnParticle(int p_spawnParticle_1_, boolean p_spawnParticle_2_, double p_spawnParticle_3_, double p_spawnParticle_5_, double p_spawnParticle_7_, double p_spawnParticle_9_, double p_spawnParticle_11_, double p_spawnParticle_13_, int... p_spawnParticle_15_) {
        this.spawnParticle(p_spawnParticle_1_, p_spawnParticle_2_, false, p_spawnParticle_3_, p_spawnParticle_5_, p_spawnParticle_7_, p_spawnParticle_9_, p_spawnParticle_11_, p_spawnParticle_13_, p_spawnParticle_15_);
    }

    public void spawnParticle(int p_spawnParticle_1_, boolean p_spawnParticle_2_, boolean p_spawnParticle_3_, final double p_spawnParticle_4_, final double p_spawnParticle_6_, final double p_spawnParticle_8_, double p_spawnParticle_10_, double p_spawnParticle_12_, double p_spawnParticle_14_, int... p_spawnParticle_16_) {
        try {
            this.spawnParticle0(p_spawnParticle_1_, p_spawnParticle_2_, p_spawnParticle_3_, p_spawnParticle_4_, p_spawnParticle_6_, p_spawnParticle_8_, p_spawnParticle_10_, p_spawnParticle_12_, p_spawnParticle_14_, p_spawnParticle_16_);
        } catch (Throwable var20) {
            CrashReport crashreport = CrashReport.makeCrashReport(var20, "Exception while adding particle");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Particle being added");
            crashreportcategory.addCrashSection("ID", p_spawnParticle_1_);
            if (p_spawnParticle_16_ != null) {
                crashreportcategory.addCrashSection("Parameters", p_spawnParticle_16_);
            }

            crashreportcategory.addDetail("Position", new ICrashReportDetail<String>() {
                public String call() throws Exception {
                    return CrashReportCategory.getCoordinateInfo(p_spawnParticle_4_, p_spawnParticle_6_, p_spawnParticle_8_);
                }
            });
            throw new ReportedException(crashreport);
        }
    }

    private void spawnParticle(EnumParticleTypes p_spawnParticle_1_, double p_spawnParticle_2_, double p_spawnParticle_4_, double p_spawnParticle_6_, double p_spawnParticle_8_, double p_spawnParticle_10_, double p_spawnParticle_12_, int... p_spawnParticle_14_) {
        this.spawnParticle(p_spawnParticle_1_.getParticleID(), p_spawnParticle_1_.getShouldIgnoreRange(), p_spawnParticle_2_, p_spawnParticle_4_, p_spawnParticle_6_, p_spawnParticle_8_, p_spawnParticle_10_, p_spawnParticle_12_, p_spawnParticle_14_);
    }

    @Nullable
    private Particle spawnParticle0(int p_spawnParticle0_1_, boolean p_spawnParticle0_2_, double p_spawnParticle0_3_, double p_spawnParticle0_5_, double p_spawnParticle0_7_, double p_spawnParticle0_9_, double p_spawnParticle0_11_, double p_spawnParticle0_13_, int... p_spawnParticle0_15_) {
        return this.spawnParticle0(p_spawnParticle0_1_, p_spawnParticle0_2_, false, p_spawnParticle0_3_, p_spawnParticle0_5_, p_spawnParticle0_7_, p_spawnParticle0_9_, p_spawnParticle0_11_, p_spawnParticle0_13_, p_spawnParticle0_15_);
    }

    @Nullable
    private Particle spawnParticle0(int p_spawnParticle0_1_, boolean p_spawnParticle0_2_, boolean p_spawnParticle0_3_, double p_spawnParticle0_4_, double p_spawnParticle0_6_, double p_spawnParticle0_8_, double p_spawnParticle0_10_, double p_spawnParticle0_12_, double p_spawnParticle0_14_, int... p_spawnParticle0_16_) {
        Entity entity = this.mc.getRenderViewEntity();
        if (this.mc != null && entity != null && this.mc.effectRenderer != null) {
            int k1 = this.calculateParticleLevel(p_spawnParticle0_3_);
            double d3 = entity.posX - p_spawnParticle0_4_;
            double d4 = entity.posY - p_spawnParticle0_6_;
            double d5 = entity.posZ - p_spawnParticle0_8_;
            if (p_spawnParticle0_2_) {
                return this.mc.effectRenderer.spawnEffectParticle(p_spawnParticle0_1_, p_spawnParticle0_4_, p_spawnParticle0_6_, p_spawnParticle0_8_, p_spawnParticle0_10_, p_spawnParticle0_12_, p_spawnParticle0_14_, p_spawnParticle0_16_);
            } else if (d3 * d3 + d4 * d4 + d5 * d5 > 1024.0) {
                return null;
            } else {
                return k1 > 1 ? null : this.mc.effectRenderer.spawnEffectParticle(p_spawnParticle0_1_, p_spawnParticle0_4_, p_spawnParticle0_6_, p_spawnParticle0_8_, p_spawnParticle0_10_, p_spawnParticle0_12_, p_spawnParticle0_14_, p_spawnParticle0_16_);
            }
        } else {
            return null;
        }
    }

    private int calculateParticleLevel(boolean p_calculateParticleLevel_1_) {
        int k1 = this.mc.gameSettings.particleSetting;
        if (p_calculateParticleLevel_1_ && k1 == 2 && this.world.rand.nextInt(10) == 0) {
            k1 = 1;
        }

        if (k1 == 1 && this.world.rand.nextInt(3) == 0) {
            k1 = 2;
        }

        return k1;
    }

    public void onEntityAdded(Entity p_onEntityAdded_1_) {
    }

    public void onEntityRemoved(Entity p_onEntityRemoved_1_) {
    }

    public void deleteAllDisplayLists() {
    }

    public void broadcastSound(int p_broadcastSound_1_, BlockPos p_broadcastSound_2_, int p_broadcastSound_3_) {
        switch (p_broadcastSound_1_) {
            case 1023:
            case 1028:
            case 1038:
                Entity entity = this.mc.getRenderViewEntity();
                if (entity != null) {
                    double d3 = (double)p_broadcastSound_2_.getX() - entity.posX;
                    double d4 = (double)p_broadcastSound_2_.getY() - entity.posY;
                    double d5 = (double)p_broadcastSound_2_.getZ() - entity.posZ;
                    double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
                    double d7 = entity.posX;
                    double d8 = entity.posY;
                    double d9 = entity.posZ;
                    if (d6 > 0.0) {
                        d7 += d3 / d6 * 2.0;
                        d8 += d4 / d6 * 2.0;
                        d9 += d5 / d6 * 2.0;
                    }

                    if (p_broadcastSound_1_ == 1023) {
                        this.world.playSound(d7, d8, d9, SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 1.0F, 1.0F, false);
                    } else if (p_broadcastSound_1_ == 1038) {
                        this.world.playSound(d7, d8, d9, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.HOSTILE, 1.0F, 1.0F, false);
                    } else {
                        this.world.playSound(d7, d8, d9, SoundEvents.ENTITY_ENDERDRAGON_DEATH, SoundCategory.HOSTILE, 5.0F, 1.0F, false);
                    }
                }
            default:
        }
    }

    public void playEvent(EntityPlayer p_playEvent_1_, int p_playEvent_2_, BlockPos p_playEvent_3_, int p_playEvent_4_) {
        Random random = this.world.rand;
        double d9;
        double d10;
        double d12;
        double d3;
        double d4;
        int l1;
        double d28;
        double d7;
        double d26;
        switch (p_playEvent_2_) {
            case 1000:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_DISPENSER_DISPENSE, SoundCategory.BLOCKS, 1.0F, 1.0F, false);
                break;
            case 1001:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.BLOCKS, 1.0F, 1.2F, false);
                break;
            case 1002:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_DISPENSER_LAUNCH, SoundCategory.BLOCKS, 1.0F, 1.2F, false);
                break;
            case 1003:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ENDEREYE_LAUNCH, SoundCategory.NEUTRAL, 1.0F, 1.2F, false);
                break;
            case 1004:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_FIREWORK_SHOOT, SoundCategory.NEUTRAL, 1.0F, 1.2F, false);
                break;
            case 1005:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_IRON_DOOR_OPEN, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1006:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_WOODEN_DOOR_OPEN, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1007:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_WOODEN_TRAPDOOR_OPEN, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1008:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_FENCE_GATE_OPEN, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1009:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.5F, 2.6F + (random.nextFloat() - random.nextFloat()) * 0.8F, false);
                break;
            case 1010:
                if (Item.getItemById(p_playEvent_4_) instanceof ItemRecord) {
                    this.world.playRecord(p_playEvent_3_, ((ItemRecord)Item.getItemById(p_playEvent_4_)).getSound());
                } else {
                    this.world.playRecord(p_playEvent_3_, (SoundEvent)null);
                }
                break;
            case 1011:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_IRON_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1012:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1013:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_WOODEN_TRAPDOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1014:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_FENCE_GATE_CLOSE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1015:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_GHAST_WARN, SoundCategory.HOSTILE, 10.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1016:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_GHAST_SHOOT, SoundCategory.HOSTILE, 10.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1017:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ENDERDRAGON_SHOOT, SoundCategory.HOSTILE, 10.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1018:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1019:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ZOMBIE_ATTACK_DOOR_WOOD, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1020:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1021:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ZOMBIE_BREAK_DOOR_WOOD, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1022:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_WITHER_BREAK_BLOCK, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1024:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_WITHER_SHOOT, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1025:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_BAT_TAKEOFF, SoundCategory.NEUTRAL, 0.05F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1026:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ZOMBIE_INFECT, SoundCategory.HOSTILE, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1027:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ZOMBIE_VILLAGER_CONVERTED, SoundCategory.NEUTRAL, 2.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F, false);
                break;
            case 1029:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_ANVIL_DESTROY, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1030:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1031:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 0.3F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1032:
                this.mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.BLOCK_PORTAL_TRAVEL, random.nextFloat() * 0.4F + 0.8F));
                break;
            case 1033:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_CHORUS_FLOWER_GROW, SoundCategory.BLOCKS, 1.0F, 1.0F, false);
                break;
            case 1034:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_CHORUS_FLOWER_DEATH, SoundCategory.BLOCKS, 1.0F, 1.0F, false);
                break;
            case 1035:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_BREWING_STAND_BREW, SoundCategory.BLOCKS, 1.0F, 1.0F, false);
                break;
            case 1036:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 1037:
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, SoundCategory.BLOCKS, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 2000:
                int j2 = p_playEvent_4_ % 3 - 1;
                int k1 = p_playEvent_4_ / 3 % 3 - 1;
                double d11 = (double)p_playEvent_3_.getX() + (double)j2 * 0.6 + 0.5;
                double d13 = (double)p_playEvent_3_.getY() + 0.5;
                double d15 = (double)p_playEvent_3_.getZ() + (double)k1 * 0.6 + 0.5;

                for(int l2 = 0; l2 < 10; ++l2) {
                    d9 = random.nextDouble() * 0.2 + 0.01;
                    d10 = d11 + (double)j2 * 0.01 + (random.nextDouble() - 0.5) * (double)k1 * 0.5;
                    d12 = d13 + (random.nextDouble() - 0.5) * 0.5;
                    double d25 = d15 + (double)k1 * 0.01 + (random.nextDouble() - 0.5) * (double)j2 * 0.5;
                    double d27 = (double)j2 * d9 + random.nextGaussian() * 0.01;
                    d3 = -0.03 + random.nextGaussian() * 0.01;
                    d4 = (double)k1 * d9 + random.nextGaussian() * 0.01;
                    this.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, d10, d12, d25, d27, d3, d4);
                }

                return;
            case 2001:
                Block block = Block.getBlockById(p_playEvent_4_ & 4095);
                if (block.getDefaultState().getMaterial() != Material.AIR) {
                    SoundType soundtype = block.getSoundType(Block.getStateById(p_playEvent_4_), this.world, p_playEvent_3_, (Entity)null);
                    this.world.playSound(p_playEvent_3_, soundtype.getBreakSound(), SoundCategory.BLOCKS, (soundtype.getVolume() + 1.0F) / 2.0F, soundtype.getPitch() * 0.8F, false);
                }

                this.mc.effectRenderer.addBlockDestroyEffects(p_playEvent_3_, block.getStateFromMeta(p_playEvent_4_ >> 12 & 255));
                break;
            case 2002:
            case 2007:
                d9 = (double)p_playEvent_3_.getX();
                d10 = (double)p_playEvent_3_.getY();
                d12 = (double)p_playEvent_3_.getZ();

                for(int k2 = 0; k2 < 8; ++k2) {
                    this.spawnParticle(EnumParticleTypes.ITEM_CRACK, d9, d10, d12, random.nextGaussian() * 0.15, random.nextDouble() * 0.2, random.nextGaussian() * 0.15, Item.getIdFromItem(Items.SPLASH_POTION));
                }

                float f5 = (float)(p_playEvent_4_ >> 16 & 255) / 255.0F;
                float f = (float)(p_playEvent_4_ >> 8 & 255) / 255.0F;
                float f1 = (float)(p_playEvent_4_ >> 0 & 255) / 255.0F;
                EnumParticleTypes enumparticletypes = p_playEvent_2_ == 2007 ? EnumParticleTypes.SPELL_INSTANT : EnumParticleTypes.SPELL;

                for(int j3 = 0; j3 < 100; ++j3) {
                    double d18 = random.nextDouble() * 4.0;
                    double d21 = random.nextDouble() * Math.PI * 2.0;
                    double d24 = Math.cos(d21) * d18;
                    d26 = 0.01 + random.nextDouble() * 0.5;
                    d28 = Math.sin(d21) * d18;
                    Particle particle1 = this.spawnParticle0(enumparticletypes.getParticleID(), enumparticletypes.getShouldIgnoreRange(), d9 + d24 * 0.1, d10 + 0.3, d12 + d28 * 0.1, d24, d26, d28);
                    if (particle1 != null) {
                        float f4 = 0.75F + random.nextFloat() * 0.25F;
                        particle1.setRBGColorF(f5 * f4, f * f4, f1 * f4);
                        particle1.multiplyVelocity((float)d18);
                    }
                }

                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_SPLASH_POTION_BREAK, SoundCategory.NEUTRAL, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 2003:
                d3 = (double)p_playEvent_3_.getX() + 0.5;
                d4 = (double)p_playEvent_3_.getY();
                double d5 = (double)p_playEvent_3_.getZ() + 0.5;

                for(l1 = 0; l1 < 8; ++l1) {
                    this.spawnParticle(EnumParticleTypes.ITEM_CRACK, d3, d4, d5, random.nextGaussian() * 0.15, random.nextDouble() * 0.2, random.nextGaussian() * 0.15, Item.getIdFromItem(Items.ENDER_EYE));
                }

                for(double d14 = 0.0; d14 < 6.283185307179586; d14 += 0.15707963267948966) {
                    this.spawnParticle(EnumParticleTypes.PORTAL, d3 + Math.cos(d14) * 5.0, d4 - 0.4, d5 + Math.sin(d14) * 5.0, Math.cos(d14) * -5.0, 0.0, Math.sin(d14) * -5.0);
                    this.spawnParticle(EnumParticleTypes.PORTAL, d3 + Math.cos(d14) * 5.0, d4 - 0.4, d5 + Math.sin(d14) * 5.0, Math.cos(d14) * -7.0, 0.0, Math.sin(d14) * -7.0);
                }

                return;
            case 2004:
                for(l1 = 0; l1 < 20; ++l1) {
                    d26 = (double)p_playEvent_3_.getX() + 0.5 + ((double)this.world.rand.nextFloat() - 0.5) * 2.0;
                    d28 = (double)p_playEvent_3_.getY() + 0.5 + ((double)this.world.rand.nextFloat() - 0.5) * 2.0;
                    d7 = (double)p_playEvent_3_.getZ() + 0.5 + ((double)this.world.rand.nextFloat() - 0.5) * 2.0;
                    this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, d26, d28, d7, 0.0, 0.0, 0.0, new int[0]);
                    this.world.spawnParticle(EnumParticleTypes.FLAME, d26, d28, d7, 0.0, 0.0, 0.0, new int[0]);
                }

                return;
            case 2005:
                ItemDye.spawnBonemealParticles(this.world, p_playEvent_3_, p_playEvent_4_);
                break;
            case 2006:
                for(l1 = 0; l1 < 200; ++l1) {
                    float f2 = random.nextFloat() * 4.0F;
                    float f3 = random.nextFloat() * 6.2831855F;
                    d28 = (double)(MathHelper.cos(f3) * f2);
                    d7 = 0.01 + random.nextDouble() * 0.5;
                    double d8 = (double)(MathHelper.sin(f3) * f2);
                    Particle particle = this.spawnParticle0(EnumParticleTypes.DRAGON_BREATH.getParticleID(), false, (double)p_playEvent_3_.getX() + d28 * 0.1, (double)p_playEvent_3_.getY() + 0.3, (double)p_playEvent_3_.getZ() + d8 * 0.1, d28, d7, d8);
                    if (particle != null) {
                        particle.multiplyVelocity(f2);
                    }
                }

                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ENDERDRAGON_FIREBALL_EPLD, SoundCategory.HOSTILE, 1.0F, this.world.rand.nextFloat() * 0.1F + 0.9F, false);
                break;
            case 3000:
                this.world.spawnParticle(EnumParticleTypes.EXPLOSION_HUGE, true, (double)p_playEvent_3_.getX() + 0.5, (double)p_playEvent_3_.getY() + 0.5, (double)p_playEvent_3_.getZ() + 0.5, 0.0, 0.0, 0.0, new int[0]);
                this.world.playSound(p_playEvent_3_, SoundEvents.BLOCK_END_GATEWAY_SPAWN, SoundCategory.BLOCKS, 10.0F, (1.0F + (this.world.rand.nextFloat() - this.world.rand.nextFloat()) * 0.2F) * 0.7F, false);
                break;
            case 3001:
                this.world.playSound(p_playEvent_3_, SoundEvents.ENTITY_ENDERDRAGON_GROWL, SoundCategory.HOSTILE, 64.0F, 0.8F + this.world.rand.nextFloat() * 0.3F, false);
        }

    }

    public void sendBlockBreakProgress(int p_sendBlockBreakProgress_1_, BlockPos p_sendBlockBreakProgress_2_, int p_sendBlockBreakProgress_3_) {
        if (p_sendBlockBreakProgress_3_ >= 0 && p_sendBlockBreakProgress_3_ < 10) {
            DestroyBlockProgress destroyblockprogress = (DestroyBlockProgress)this.damagedBlocks.get(p_sendBlockBreakProgress_1_);
            if (destroyblockprogress == null || destroyblockprogress.getPosition().getX() != p_sendBlockBreakProgress_2_.getX() || destroyblockprogress.getPosition().getY() != p_sendBlockBreakProgress_2_.getY() || destroyblockprogress.getPosition().getZ() != p_sendBlockBreakProgress_2_.getZ()) {
                destroyblockprogress = new DestroyBlockProgress(p_sendBlockBreakProgress_1_, p_sendBlockBreakProgress_2_);
                this.damagedBlocks.put(p_sendBlockBreakProgress_1_, destroyblockprogress);
            }

            destroyblockprogress.setPartialBlockDamage(p_sendBlockBreakProgress_3_);
            destroyblockprogress.setCloudUpdateTick(this.cloudTickCounter);
        } else {
            this.damagedBlocks.remove(p_sendBlockBreakProgress_1_);
        }

    }

    public boolean hasNoChunkUpdates() {
        return this.chunksToUpdate.isEmpty() && this.renderDispatcher.hasChunkUpdates();
    }

    public void setDisplayListEntitiesDirty() {
        this.displayListEntitiesDirty = true;
    }

    public void updateTileEntities(Collection<TileEntity> p_updateTileEntities_1_, Collection<TileEntity> p_updateTileEntities_2_) {
        synchronized(this.setTileEntities) {
            this.setTileEntities.removeAll(p_updateTileEntities_1_);
            this.setTileEntities.addAll(p_updateTileEntities_2_);
        }
    }

    @SideOnly(Side.CLIENT)
    class ContainerLocalRenderInformation {
        final RenderChunk renderChunk;
        final EnumFacing facing;
        byte setFacing;
        final int counter;

        private ContainerLocalRenderInformation(RenderChunk p_i46248_2_, EnumFacing p_i46248_3_, @Nullable int p_i46248_4_) {
            this.renderChunk = p_i46248_2_;
            this.facing = p_i46248_3_;
            this.counter = p_i46248_4_;
        }

        public void setDirection(byte p_setDirection_1_, EnumFacing p_setDirection_2_) {
            this.setFacing = (byte)(this.setFacing | p_setDirection_1_ | 1 << p_setDirection_2_.ordinal());
        }

        public boolean hasDirection(EnumFacing p_hasDirection_1_) {
            return (this.setFacing & 1 << p_hasDirection_1_.ordinal()) > 0;
        }
    }
}
