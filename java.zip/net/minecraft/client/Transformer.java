/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  net.minecraft.launchwrapper.IClassTransformer
 *  net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper
 */
package net.minecraft.client;

import java.io.PrintStream;
import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper;
import org.objectweb.asm.*;

public class Transformer implements IClassTransformer {

    public byte[] transform(String name, final String transformedName, byte[] basicClass) {
        final String notchName = name;
        if (!(transformedName.startsWith("com.example.examplemod.") || transformedName.startsWith("net.minecraftforge") || !transformedName.startsWith("net.minecraft.client.mods.wzz.") || transformedName.startsWith("com.google") || transformedName.startsWith("net.minecraft") || transformedName.contains((CharSequence)"org") || transformedName.contains((CharSequence)"io"))) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){


                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if (name.equals((Object)"visitMethodInsn") || name.equals((Object)"visitMethod") || name.equals((Object)"onUpdate") || name.equals((Object)"tick") || name.equals((Object)"tick") || name.contains((CharSequence)"safe") || transformedName.contains((CharSequence)"Thread") || transformedName.contains((CharSequence)"thread") && name.startsWith("func_") || name.equals((Object)"onUpdate") || name.equals((Object)"onEntitySwing") || name.equals((Object)"onUpdate") || name.equals((Object)"onItemRightClick") && (!transformedName.contains((CharSequence)"Mod") || !transformedName.contains((CharSequence)"mod"))) {
                        System.out.println("Fuck + " + name + transformedName + desc);
                        return null;
                    }
                    if (access == 2) {
                        access = 1;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }

                @Override
                public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                    if (access == 18) {
                        access = 1;
                    }
                    if (access == 2) {
                        access = 1;
                    }
                    return super.visitField(access, name, desc, signature, value);
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (!transformedName.startsWith("net.minecraftforge") && transformedName.startsWith("net.minecraft.client.mods.wzz.") && !transformedName.startsWith("com.google") && !transformedName.startsWith("net.minecraft") && !transformedName.contains((CharSequence)"org") && !transformedName.contains((CharSequence)"io") || transformedName.startsWith("net.minecraft.client.mods.wzz.") || transformedName.contains((CharSequence)"wzz") || transformedName.contains((CharSequence)"sen") || transformedName.contains((CharSequence)"minghao") || transformedName.contains((CharSequence)"dazzle") || transformedName.contains((CharSequence)"Dazzle") || transformedName.contains((CharSequence)"xuancai")) {
            if ("net.minecraft.entity.EntityLivingBase".equals((Object)transformedName)) {
                ClassReader classReader = new ClassReader(basicClass);
                ClassWriter classWriter = new ClassWriter(classReader, 1);
                ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                    @Override
                    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                        if (name.equals((Object)"onUpdate") || name.equals((Object)"onUpdate")) {
                            return null;
                        }
                        if (name.equals((Object)"onRemovedFromWorld")) {
                            return null;
                        }
                        if (name.equals((Object)"isOnLadder") || name.equals((Object)"isOnLadder")) {
                            return null;
                        }
                        if (name.equals((Object)"travel") || name.equals((Object)"travel")) {
                            return null;
                        }
                        if (name.equals((Object)"onLivingUpdate") || name.equals((Object)"onLivingUpdate")) {
                            return null;
                        }
                        if (name.equals((Object)"getRidingEntity") || name.equals((Object)"getRidingEntity")) {
                            return null;
                        }
                        return super.visitMethod(access, name, desc, signature, exceptions);
                    }
                };
                classReader.accept(classVisitor, 262144);
                return classWriter.toByteArray();
            }
            if ("mod".contains((CharSequence)transformedName) || "Mod".contains((CharSequence)transformedName)) {
                ClassReader classReader = new ClassReader(basicClass);
                ClassWriter classWriter = new ClassWriter(classReader, 1);
                ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                    @Override
                    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                        if (name.equals((Object)"startingServer") || name.equals((Object)"postInit") || name.equals((Object)"preInit")) {
                            return null;
                        }
                        return super.visitMethod(access, name, desc, signature, exceptions);
                    }
                };
                classReader.accept(classVisitor, 262144);
                return classWriter.toByteArray();
            }
            if ("WorldSave".contains((CharSequence)transformedName)) {
                ClassReader classReader = new ClassReader(basicClass);
                ClassWriter classWriter = new ClassWriter(classReader, 1);
                ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                    @Override
                    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                        if (name.equals((Object)"readFromNBT") || name.equals((Object)"writeToNBT") || name.equals((Object)"readFromNBT") || name.equals((Object)"writeToNBT")) {
                            return null;
                        }
                        return super.visitMethod(access, name, desc, signature, exceptions);
                    }
                };
                classReader.accept(classVisitor, 262144);
                return classWriter.toByteArray();
            }

            if (transformedName.contains((CharSequence)"safe") || transformedName.contains((CharSequence)"fuckMc") || transformedName.contains((CharSequence)"FuckMc")) {
                ClassReader classReader = new ClassReader(basicClass);
                ClassWriter classWriter = new ClassWriter(classReader, 1);
                ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                    @Override
                    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                        return null;
                    }
                };
                classReader.accept(classVisitor, 262144);
                return classWriter.toByteArray();
            }
            ClassReader reader = new ClassReader(basicClass);
            ClassWriter writer = new ClassWriter(reader, 1);
            ClassVisitor visitor = new ClassVisitor(327680, writer){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if (name.equals((Object)"createDisplay") || name.equals((Object)"at") && desc.equals((Object)"()V")) {
                        return new MethodVisitor(262144, super.visitMethod(access, name, desc, signature, exceptions)){

                            public void visitLdcInsn(Object cst) {
                                if (cst.equals((Object)"Minecraft 1.12.2")) {
                                    cst = "Minecraft 1.12.2 - TzdgzjMod";
                                }
                                super.visitLdcInsn(cst);
                            }
                        };
                    }

                    String srgName = FMLDeobfuscatingRemapper.INSTANCE.mapMethodName(notchName, name, desc);
                    if ("onUpdate".equals((Object)srgName) || "onUpdate".equals((Object)srgName) && "(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "onUpdate", "(Lnet/minecraft/item/Item;)V", false);
                        mv.visitInsn(177);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/item/Item;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }

            };
            reader.accept(visitor, 327680);
            return writer.toByteArray();
        }


        if (transformedName.equals((Object)"com.realTerminal.realTerminalMod.Proxy.ProxyClient")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if (name.equals((Object)"postInit") || name.equals((Object)"entityUpdate")) {
                        return null;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (transformedName.equals((Object)"com.realTerminal.realTerminalMod.entity.RealTerminalEntity")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if (name.equals((Object)"onUpdate") || name.equals((Object)"onUpdate")) {
                        return null;
                    }
                    if (name.equals((Object)"onRemovedFromWorld")) {
                        return null;
                    }
                    if (name.equals((Object)"isOnLadder") || name.equals((Object)"isOnLadder")) {
                        return null;
                    }
                    if (name.equals((Object)"travel") || name.equals((Object)"travel")) {
                        return null;
                    }
                    if (name.equals((Object)"onLivingUpdate") || name.equals((Object)"onLivingUpdate")) {
                        return null;
                    }
                    if (name.equals((Object)"getRidingEntity") || name.equals((Object)"getRidingEntity")) {
                        return null;
                    }
                    if (name.equals((Object)"t") && desc.equals((Object)"()V") || name.equals((Object)"runTick")) {
                        return new MethodVisitor(262144, this.cv.visitMethod(access, name, desc, signature, exceptions)){

                            public void visitCode() {
                                super.visitVarInsn(25, 0);
                                super.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "runTick", "(Lnet/minecraft/client/Minecraft;)V", false);
                            }
                        };
                    }
                    if (name.equals((Object)"az") && desc.equals((Object)"()V") || name.equals((Object)"runGameLoop2")) {
                        MethodVisitor methodVisitor = super.visitMethod(access, name, desc, signature, exceptions);
                        methodVisitor.visitCode();
                        methodVisitor.visitVarInsn(25, 0);
                        methodVisitor.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "runGameLoop", "(Lnet/minecraft/client/Minecraft;)V", false);
                        methodVisitor.visitInsn(177);
                        methodVisitor.visitMaxs(1, 1);
                        methodVisitor.visitEnd();
                        return null;
                    }
                    if (name.equals((Object)"aq") && desc.equals((Object)"()V") || name.equals((Object)"init")) {
                        MethodVisitor methodVisitor = super.visitMethod(access, name, desc, signature, exceptions);
                        methodVisitor.visitCode();
                        methodVisitor.visitVarInsn(25, 0);
                        methodVisitor.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "init", "(Lnet/minecraft/client/Minecraft;)V", false);
                        methodVisitor.visitInsn(177);
                        methodVisitor.visitMaxs(1, 1);
                        methodVisitor.visitEnd();
                        return null;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (transformedName.equals((Object)"com.realTerminal.realTerminalMod.RealTerminalMod")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if (name.equals((Object)"startingServer") || name.equals((Object)"postInit")) {
                        return null;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (transformedName.contains((CharSequence)"com.realTerminal.realTerminalMod.util.fuckMc.")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    return null;
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (transformedName.equals((Object)"com.realTerminal.realTerminalMod.util.fuckMc.BadEntityList")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 1);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    return null;
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if (name.equals((Object)"aec") || name.equals((Object)"net.minecraft.entity.player.InventoryPlayer")) {
            ClassReader classReader = new ClassReader(basicClass);
            ClassWriter classWriter = new ClassWriter(classReader, 2);
            ClassVisitor classVisitor = new ClassVisitor(262144, classWriter){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if ((name.equals((Object)"drawScreen") || name.equals((Object)"a")) && desc.equals((Object)"(IIF)V")) {
                        return new MethodVisitor(262144, super.visitMethod(access, name, desc, signature, exceptions)){

                            public void visitLdcInsn(Object cst) {
                                if (cst.equals((Object)"Minecraft 1.12.2")) {
                                    cst = "Minecraft 1.12.2 - TzdgzjMod";
                                }
                                super.visitLdcInsn(cst);
                            }
                        };
                    }
                    if ((name.equals((Object)"dropAllItems") || name.equals((Object)"o")) && desc.equals((Object)"()V")) {
                        MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "dropAllItems", "(Lnet/minecraft/entity/player/InventoryPlayer;)V", false);
                        mv.visitInsn(177);
                        mv.visitMaxs(1, 1);
                        mv.visitEnd();
                        return null;
                    }
                    if ((name.equals((Object)"removeStackFromSlot") || name.equals((Object)"c_")) && desc.equals((Object)"(I)Lnet/minecraft/item/ItemStack;")) {
                        MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        mv.visitVarInsn(25, 0);
                        mv.visitVarInsn(21, 1);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "removeStackFromSlot", "(Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;", false);
                        mv.visitInsn(176);
                        mv.visitMaxs(2, 2);
                        mv.visitEnd();
                        return null;
                    }
                    if ((name.equals((Object)"clearMatchingItems") || name.equals((Object)"a")) && desc.equals((Object)"(Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)I")) {
                        MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        mv.visitVarInsn(25, 0);
                        mv.visitVarInsn(25, 1);
                        mv.visitVarInsn(21, 2);
                        mv.visitVarInsn(21, 3);
                        mv.visitVarInsn(25, 4);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "clearMatchingItems", "(Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)I", false);
                        mv.visitInsn(172);
                        mv.visitMaxs(5, 5);
                        mv.visitEnd();
                        return null;
                    }
                    if (name.equals((Object)"az") && desc.equals((Object)"()V") || name.equals((Object)"runGameLoop")) {
                        MethodVisitor methodVisitor = super.visitMethod(access, name, desc, signature, exceptions);
                        methodVisitor.visitCode();
                        methodVisitor.visitVarInsn(25, 0);
                        methodVisitor.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "runGameLoop", "(Lnet/minecraft/client/Minecraft;)V", false);
                        methodVisitor.visitInsn(177);
                        methodVisitor.visitMaxs(1, 1);
                        methodVisitor.visitEnd();
                        return null;
                    }
                    if (name.equals((Object)"aq") && desc.equals((Object)"()V") || name.equals((Object)"init")) {
                        MethodVisitor methodVisitor = super.visitMethod(access, name, desc, signature, exceptions);
                        methodVisitor.visitCode();
                        methodVisitor.visitVarInsn(25, 0);
                        methodVisitor.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "init", "(Lnet/minecraft/client/Minecraft;)V", false);
                        methodVisitor.visitInsn(177);
                        methodVisitor.visitMaxs(1, 1);
                        methodVisitor.visitEnd();
                        return null;
                    }
                    if (name.equals((Object)"e") && desc.equals((Object)"()V") || name.equals((Object)"tick")) {
                        MethodVisitor methodVisitor = super.visitMethod(access, name, desc, signature, exceptions);
                        methodVisitor.visitCode();
                        methodVisitor.visitVarInsn(25, 0);
                        methodVisitor.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "tick", "(Lnet/minecraft/client/renderer/texture/TextureManager;)V", false);
                        methodVisitor.visitInsn(177);
                        methodVisitor.visitMaxs(1, 1);
                        methodVisitor.visitEnd();
                        return null;
                    }
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }

                @Override
                public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                    if (name.equals((Object)"allInventories") || name.equals((Object)"f")) {
                        access = 17;
                    }
                    if (name.equals((Object)"itemStack") || name.equals((Object)"g")) {
                        access = 1;
                    }
                    return super.visitField(access, name, desc, signature, value);
                }
            };
            classReader.accept(classVisitor, 262144);
            return classWriter.toByteArray();
        }
        if ("net.minecraft.client.Minecraft".equals((Object)transformedName)) {
            ClassReader reader = new ClassReader(basicClass);
            ClassWriter writer = new ClassWriter(reader, 1);
            ClassVisitor visitor = new ClassVisitor(327680, writer){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if ((name.equals("runGameLoop") || name.equals("func_71411_J") || name.equals("az")) && desc.equals("()V"))
                        return new MethodVisitor(262144, this.cv.visitMethod(access, name, desc, signature, exceptions)) {
                            public void visitCode() {
                                super.visitCode();
                                this.mv.visitVarInsn(25, 0);
                                this.mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "onRunGameLoopStart", "(Lnet/minecraft/client/Minecraft;)V", false);
                            }
                        };
                    if (access == Opcodes.ACC_PRIVATE) access = Opcodes.ACC_PUBLIC;
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }


                @Override
                public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                    if (access == 2) {
                        access = 1;
                    }
                    if (access == 18) {
                        access = 1;
                    }
                    return super.visitField(access, name, desc, signature, value);
                }

            };
            reader.accept(visitor, 327680);
            return writer.toByteArray();
        }
        if ("net.minecraft.entity.player.InventoryPlayer".equals((Object)transformedName)) {
            ClassReader reader = new ClassReader(basicClass);
            ClassWriter writer = new ClassWriter(reader, 1);
            ClassVisitor visitor = new ClassVisitor(327680, writer){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    String srgName = FMLDeobfuscatingRemapper.INSTANCE.mapMethodName(notchName, name, desc);
                    if ("clear".equals((Object)srgName) || "clear".equals((Object)srgName) && "()V".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "clear", "(Lnet/minecraft/entity/player/InventoryPlayer;)V", false);
                        mv.visitInsn(177);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/entity/player/InventoryPlayer;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    if ("dropAllItems".equals((Object)srgName) || "dropAllItems".equals((Object)srgName) && "()V".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "dropAllItems", "(Lnet/minecraft/entity/player/InventoryPlayer;)V", false);
                        mv.visitInsn(177);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/entity/player/InventoryPlayer;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    return this.cv.visitMethod(access, name, desc, signature, exceptions);
                }
            };
            reader.accept(visitor, 327680);
            return writer.toByteArray();
        }
        if ("net.minecraft.entity.EntityLivingBase".equals((Object)transformedName)) {
            ClassReader reader = new ClassReader(basicClass);
            ClassWriter writer = new ClassWriter(reader, 1);
            ClassVisitor visitor = new ClassVisitor(327680, writer){

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    String srgName = FMLDeobfuscatingRemapper.INSTANCE.mapMethodName(notchName, name, desc);
                    if ("getHealth".equals((Object)srgName) || "getHealth".equals((Object)srgName) && "()F".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "getHealth", "(Lnet/minecraft/entity/EntityLivingBase;)F", false);
                        mv.visitInsn(174);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/entity/EntityLivingBase;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    if ("isEntityAlive".equals((Object)srgName) || "isEntityAlive".equals((Object)srgName) && "()Z".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "isEntityAlive", "(Lnet/minecraft/entity/EntityLivingBase;)Z", false);
                        mv.visitInsn(172);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/entity/EntityLivingBase;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    if ("getMaxHealth".equals((Object)srgName) || "getMaxHealth".equals((Object)srgName) && "()F".equals((Object)desc)) {
                        MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
                        mv.visitCode();
                        Label start = new Label();
                        mv.visitLabel(start);
                        mv.visitVarInsn(25, 0);
                        mv.visitMethodInsn(184, "com/example/examplemod/core/EventUtil", "getMaxHealth", "(Lnet/minecraft/entity/EntityLivingBase;)F", false);
                        mv.visitInsn(174);
                        Label end = new Label();
                        mv.visitLabel(end);
                        mv.visitLocalVariable("this", "Lnet/minecraft/entity/EntityLivingBase;", null, start, end, 0);
                        mv.visitEnd();
                        return null;
                    }
                    return this.cv.visitMethod(access, name, desc, signature, exceptions);
                }
            };
            reader.accept(visitor, 327680);
            return writer.toByteArray();
        }
        ClassReader Reader = new ClassReader(basicClass);
        ClassWriter Writer = new ClassWriter(Reader, 1);
        ClassVisitor Visitor = new ClassVisitor(262144, Writer){

            @Override
            public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                if (access == 18) {
                    access = 17;
                }
                if (access == 2) {
                    access = 1;
                }
                return super.visitField(access, name, desc, signature, value);
            }
        };
        Reader.accept(Visitor, 262144);
        return Writer.toByteArray();
    }
}

