//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package net.minecraft.client.gui;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.awt.Toolkit;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.util.ITooltipFlag.TooltipFlags;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraft.util.text.event.HoverEvent.Action;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.fml.client.config.GuiUtils;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

@SideOnly(Side.CLIENT)
public abstract class GuiScreen extends Gui implements GuiYesNoCallback {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Set<String> PROTOCOLS = Sets.newHashSet(new String[]{"http", "https"});
    private static final Splitter NEWLINE_SPLITTER = Splitter.on('\n');
    public Minecraft mc;
    protected RenderItem itemRender;
    public int width;
    public int height;
    public List<GuiButton> buttonList = Lists.newArrayList();
    protected List<GuiLabel> labelList = Lists.newArrayList();
    public boolean allowUserInput;
    protected FontRenderer fontRenderer;
    protected GuiButton selectedButton;
    private int eventButton;
    private long lastMouseEvent;
    private int touchValue;
    private URI clickedLinkURI;
    public boolean focused;
    protected boolean keyHandled;
    protected boolean mouseHandled;

    public GuiScreen() {
    }

    public void drawScreen(int p_drawScreen_1_, int p_drawScreen_2_, float p_drawScreen_3_) {
        int j;
        for(j = 0; j < this.buttonList.size(); ++j) {
            ((GuiButton)this.buttonList.get(j)).drawButton(this.mc, p_drawScreen_1_, p_drawScreen_2_, p_drawScreen_3_);
        }

        for(j = 0; j < this.labelList.size(); ++j) {
            ((GuiLabel)this.labelList.get(j)).drawLabel(this.mc, p_drawScreen_1_, p_drawScreen_2_);
        }

    }

    protected void keyTyped(char p_keyTyped_1_, int p_keyTyped_2_) throws IOException {
        if (p_keyTyped_2_ == 1) {
            this.mc.displayGuiScreen((GuiScreen)null);
            if (this.mc.currentScreen == null) {
                this.mc.setIngameFocus();
            }
        }

    }

    protected <T extends GuiButton> T addButton(T p_addButton_1_) {
        this.buttonList.add(p_addButton_1_);
        return p_addButton_1_;
    }

    public static String getClipboardString() {
        try {
            Transferable transferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents((Object)null);
            if (transferable != null && transferable.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String)transferable.getTransferData(DataFlavor.stringFlavor);
            }
        } catch (Exception var1) {
        }

        return "";
    }

    public static void setClipboardString(String p_setClipboardString_0_) {
        if (!StringUtils.isEmpty(p_setClipboardString_0_)) {
            try {
                StringSelection stringselection = new StringSelection(p_setClipboardString_0_);
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection, (ClipboardOwner)null);
            } catch (Exception var2) {
            }
        }

    }

    protected void renderToolTip(ItemStack p_renderToolTip_1_, int p_renderToolTip_2_, int p_renderToolTip_3_) {
        FontRenderer font = p_renderToolTip_1_.getItem().getFontRenderer(p_renderToolTip_1_);
        GuiUtils.preItemToolTip(p_renderToolTip_1_);
        this.drawHoveringText(this.getItemToolTip(p_renderToolTip_1_), p_renderToolTip_2_, p_renderToolTip_3_, font == null ? this.fontRenderer : font);
        GuiUtils.postItemToolTip();
    }

    public List<String> getItemToolTip(ItemStack p_getItemToolTip_1_) {
        List<String> list = p_getItemToolTip_1_.getTooltip(this.mc.player, this.mc.gameSettings.advancedItemTooltips ? TooltipFlags.ADVANCED : TooltipFlags.NORMAL);

        for(int i = 0; i < list.size(); ++i) {
            if (i == 0) {
                list.set(i, p_getItemToolTip_1_.getRarity().rarityColor + (String)list.get(i));
            } else {
                list.set(i, TextFormatting.GRAY + (String)list.get(i));
            }
        }

        return list;
    }

    public void drawHoveringText(String p_drawHoveringText_1_, int p_drawHoveringText_2_, int p_drawHoveringText_3_) {
        this.drawHoveringText(Arrays.asList(p_drawHoveringText_1_), p_drawHoveringText_2_, p_drawHoveringText_3_);
    }

    public void setFocused(boolean p_setFocused_1_) {
        this.focused = p_setFocused_1_;
    }

    public boolean isFocused() {
        return this.focused;
    }

    public void drawHoveringText(List<String> p_drawHoveringText_1_, int p_drawHoveringText_2_, int p_drawHoveringText_3_) {
        this.drawHoveringText(p_drawHoveringText_1_, p_drawHoveringText_2_, p_drawHoveringText_3_, this.fontRenderer);
    }

    protected void drawHoveringText(List<String> p_drawHoveringText_1_, int p_drawHoveringText_2_, int p_drawHoveringText_3_, FontRenderer p_drawHoveringText_4_) {
        GuiUtils.drawHoveringText(p_drawHoveringText_1_, p_drawHoveringText_2_, p_drawHoveringText_3_, this.width, this.height, -1, p_drawHoveringText_4_);
    }

    protected void handleComponentHover(ITextComponent p_handleComponentHover_1_, int p_handleComponentHover_2_, int p_handleComponentHover_3_) {
        if (p_handleComponentHover_1_ != null && p_handleComponentHover_1_.getStyle().getHoverEvent() != null) {
            HoverEvent hoverevent = p_handleComponentHover_1_.getStyle().getHoverEvent();
            if (hoverevent.getAction() == Action.SHOW_ITEM) {
                ItemStack itemstack = ItemStack.EMPTY;

                try {
                    NBTBase nbtbase = JsonToNBT.getTagFromJson(hoverevent.getValue().getUnformattedText());
                    if (nbtbase instanceof NBTTagCompound) {
                        itemstack = new ItemStack((NBTTagCompound)nbtbase);
                    }
                } catch (NBTException var9) {
                }

                if (itemstack.isEmpty()) {
                    this.drawHoveringText(TextFormatting.RED + "Invalid Item!", p_handleComponentHover_2_, p_handleComponentHover_3_);
                } else {
                    this.renderToolTip(itemstack, p_handleComponentHover_2_, p_handleComponentHover_3_);
                }
            } else if (hoverevent.getAction() == Action.SHOW_ENTITY) {
                if (this.mc.gameSettings.advancedItemTooltips) {
                    try {
                        NBTTagCompound nbttagcompound = JsonToNBT.getTagFromJson(hoverevent.getValue().getUnformattedText());
                        List<String> list = Lists.newArrayList();
                        list.add(nbttagcompound.getString("name"));
                        if (nbttagcompound.hasKey("type", 8)) {
                            String s = nbttagcompound.getString("type");
                            list.add("Type: " + s);
                        }

                        list.add(nbttagcompound.getString("id"));
                        this.drawHoveringText((List)list, p_handleComponentHover_2_, p_handleComponentHover_3_);
                    } catch (NBTException var8) {
                        this.drawHoveringText(TextFormatting.RED + "Invalid Entity!", p_handleComponentHover_2_, p_handleComponentHover_3_);
                    }
                }
            } else if (hoverevent.getAction() == Action.SHOW_TEXT) {
                this.drawHoveringText(this.mc.fontRenderer.listFormattedStringToWidth(hoverevent.getValue().getFormattedText(), Math.max(this.width / 2, 200)), p_handleComponentHover_2_, p_handleComponentHover_3_);
            }

            GlStateManager.disableLighting();
        }

    }

    protected void setText(String p_setText_1_, boolean p_setText_2_) {
    }

    public boolean handleComponentClick(ITextComponent p_handleComponentClick_1_) {
        if (p_handleComponentClick_1_ == null) {
            return false;
        } else {
            ClickEvent clickevent = p_handleComponentClick_1_.getStyle().getClickEvent();
            if (isShiftKeyDown()) {
                if (p_handleComponentClick_1_.getStyle().getInsertion() != null) {
                    this.setText(p_handleComponentClick_1_.getStyle().getInsertion(), false);
                }
            } else if (clickevent != null) {
                URI uri;
                if (clickevent.getAction() == net.minecraft.util.text.event.ClickEvent.Action.OPEN_URL) {
                    if (!this.mc.gameSettings.chatLinks) {
                        return false;
                    }

                    try {
                        uri = new URI(clickevent.getValue());
                        String s = uri.getScheme();
                        if (s == null) {
                            throw new URISyntaxException(clickevent.getValue(), "Missing protocol");
                        }

                        if (!PROTOCOLS.contains(s.toLowerCase(Locale.ROOT))) {
                            throw new URISyntaxException(clickevent.getValue(), "Unsupported protocol: " + s.toLowerCase(Locale.ROOT));
                        }

                        if (this.mc.gameSettings.chatLinksPrompt) {
                            this.clickedLinkURI = uri;
                            this.mc.displayGuiScreen(new GuiConfirmOpenLink(this, clickevent.getValue(), 31102009, false));
                        } else {
                            this.openWebLink(uri);
                        }
                    } catch (URISyntaxException var5) {
                        LOGGER.error("Can't open url for {}", clickevent, var5);
                    }
                } else if (clickevent.getAction() == net.minecraft.util.text.event.ClickEvent.Action.OPEN_FILE) {
                    uri = (new File(clickevent.getValue())).toURI();
                    this.openWebLink(uri);
                } else if (clickevent.getAction() == net.minecraft.util.text.event.ClickEvent.Action.SUGGEST_COMMAND) {
                    this.setText(clickevent.getValue(), true);
                } else if (clickevent.getAction() == net.minecraft.util.text.event.ClickEvent.Action.RUN_COMMAND) {
                    this.sendChatMessage(clickevent.getValue(), false);
                } else {
                    LOGGER.error("Don't know how to handle {}", clickevent);
                }

                return true;
            }

            return false;
        }
    }

    public void sendChatMessage(String p_sendChatMessage_1_) {
        this.sendChatMessage(p_sendChatMessage_1_, true);
    }

    public void sendChatMessage(String p_sendChatMessage_1_, boolean p_sendChatMessage_2_) {
        p_sendChatMessage_1_ = ForgeEventFactory.onClientSendMessage(p_sendChatMessage_1_);
        if (!p_sendChatMessage_1_.isEmpty()) {
            if (p_sendChatMessage_2_) {
                this.mc.ingameGUI.getChatGUI().addToSentMessages(p_sendChatMessage_1_);
            }

            if (ClientCommandHandler.instance.executeCommand(this.mc.player, p_sendChatMessage_1_) == 0) {
                this.mc.player.sendChatMessage(p_sendChatMessage_1_);
            }
        }
    }

    protected void mouseClicked(int p_mouseClicked_1_, int p_mouseClicked_2_, int p_mouseClicked_3_) throws IOException {
        if (p_mouseClicked_3_ == 0) {
            for(int i = 0; i < this.buttonList.size(); ++i) {
                GuiButton guibutton = (GuiButton)this.buttonList.get(i);
                if (guibutton.mousePressed(this.mc, p_mouseClicked_1_, p_mouseClicked_2_)) {
                    GuiScreenEvent.ActionPerformedEvent.Pre event = new GuiScreenEvent.ActionPerformedEvent.Pre(this, guibutton, this.buttonList);
                    if (MinecraftForge.EVENT_BUS.post(event)) {
                        break;
                    }

                    guibutton = event.getButton();
                    this.selectedButton = guibutton;
                    guibutton.playPressSound(this.mc.getSoundHandler());
                    this.actionPerformed(guibutton);
                    if (this.equals(this.mc.currentScreen)) {
                        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.ActionPerformedEvent.Post(this, event.getButton(), this.buttonList));
                    }
                }
            }
        }

    }

    protected void mouseReleased(int p_mouseReleased_1_, int p_mouseReleased_2_, int p_mouseReleased_3_) {
        if (this.selectedButton != null && p_mouseReleased_3_ == 0) {
            this.selectedButton.mouseReleased(p_mouseReleased_1_, p_mouseReleased_2_);
            this.selectedButton = null;
        }

    }

    protected void mouseClickMove(int p_mouseClickMove_1_, int p_mouseClickMove_2_, int p_mouseClickMove_3_, long p_mouseClickMove_4_) {
    }

    protected void actionPerformed(GuiButton p_actionPerformed_1_) throws IOException {
    }

    public void setWorldAndResolution(Minecraft p_setWorldAndResolution_1_, int p_setWorldAndResolution_2_, int p_setWorldAndResolution_3_) {
        this.mc = p_setWorldAndResolution_1_;
        this.itemRender = p_setWorldAndResolution_1_.getRenderItem();
        this.fontRenderer = p_setWorldAndResolution_1_.fontRenderer;
        this.width = p_setWorldAndResolution_2_;
        this.height = p_setWorldAndResolution_3_;
        if (!MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.InitGuiEvent.Pre(this, this.buttonList))) {
            this.buttonList.clear();
            this.initGui();
        }

        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.InitGuiEvent.Post(this, this.buttonList));
    }

    public void setGuiSize(int p_setGuiSize_1_, int p_setGuiSize_2_) {
        this.width = p_setGuiSize_1_;
        this.height = p_setGuiSize_2_;
    }

    public void initGui() {
    }

    public void handleInput() throws IOException {
        if (Mouse.isCreated()) {
            while(Mouse.next()) {
                this.mouseHandled = false;
                if (!MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.MouseInputEvent.Pre(this))) {
                    this.handleMouseInput();
                    if (this.equals(this.mc.currentScreen) && !this.mouseHandled) {
                        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.MouseInputEvent.Post(this));
                    }
                }
            }
        }

        if (Keyboard.isCreated()) {
            while(Keyboard.next()) {
                this.keyHandled = false;
                if (!MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.KeyboardInputEvent.Pre(this))) {
                    this.handleKeyboardInput();
                    if (this.equals(this.mc.currentScreen) && !this.keyHandled) {
                        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.KeyboardInputEvent.Post(this));
                    }
                }
            }
        }

    }

    public void handleMouseInput() throws IOException {
        int i = Mouse.getEventX() * this.width / this.mc.displayWidth;
        int j = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
        int k = Mouse.getEventButton();
        if (Mouse.getEventButtonState()) {
            if (this.mc.gameSettings.touchscreen && this.touchValue++ > 0) {
                return;
            }

            this.eventButton = k;
            this.lastMouseEvent = Minecraft.getSystemTime();
            this.mouseClicked(i, j, this.eventButton);
        } else if (k != -1) {
            if (this.mc.gameSettings.touchscreen && --this.touchValue > 0) {
                return;
            }

            this.eventButton = -1;
            this.mouseReleased(i, j, k);
        } else if (this.eventButton != -1 && this.lastMouseEvent > 0L) {
            long l = Minecraft.getSystemTime() - this.lastMouseEvent;
            this.mouseClickMove(i, j, this.eventButton, l);
        }

    }

    public void handleKeyboardInput() throws IOException {
        char c0 = Keyboard.getEventCharacter();
        if (Keyboard.getEventKey() == 0 && c0 >= ' ' || Keyboard.getEventKeyState()) {
            this.keyTyped(c0, Keyboard.getEventKey());
        }

        this.mc.dispatchKeypresses();
    }

    public void updateScreen() {
    }

    public void onGuiClosed() {
    }

    public void drawDefaultBackground() {
        this.drawWorldBackground(0);
        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.BackgroundDrawnEvent(this));
    }

    public void drawWorldBackground(int p_drawWorldBackground_1_) {
        if (this.mc.world != null) {
            this.drawGradientRect(0, 0, this.width, this.height, -1072689136, -804253680);
        } else {
            this.drawBackground(p_drawWorldBackground_1_);
        }

    }

    public void drawBackground(int p_drawBackground_1_) {
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        this.mc.getTextureManager().bindTexture(OPTIONS_BACKGROUND);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        float f = 32.0F;
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        bufferbuilder.pos(0.0, (double)this.height, 0.0).tex(0.0, (double)((float)this.height / 32.0F + (float)p_drawBackground_1_)).color(64, 64, 64, 255).endVertex();
        bufferbuilder.pos((double)this.width, (double)this.height, 0.0).tex((double)((float)this.width / 32.0F), (double)((float)this.height / 32.0F + (float)p_drawBackground_1_)).color(64, 64, 64, 255).endVertex();
        bufferbuilder.pos((double)this.width, 0.0, 0.0).tex((double)((float)this.width / 32.0F), (double)p_drawBackground_1_).color(64, 64, 64, 255).endVertex();
        bufferbuilder.pos(0.0, 0.0, 0.0).tex(0.0, (double)p_drawBackground_1_).color(64, 64, 64, 255).endVertex();
        tessellator.draw();
    }

    public boolean doesGuiPauseGame() {
        return true;
    }

    public void confirmClicked(boolean p_confirmClicked_1_, int p_confirmClicked_2_) {
        if (p_confirmClicked_2_ == 31102009) {
            if (p_confirmClicked_1_) {
                this.openWebLink(this.clickedLinkURI);
            }

            this.clickedLinkURI = null;
            this.mc.displayGuiScreen(this);
        }

    }

    private void openWebLink(URI p_openWebLink_1_) {
        try {
            Class<?> oclass = Class.forName("java.awt.Desktop");
            Object object = oclass.getMethod("getDesktop").invoke((Object)null);
            oclass.getMethod("browse", URI.class).invoke(object, p_openWebLink_1_);
        } catch (Throwable var4) {
            Throwable throwable = var4.getCause();
            LOGGER.error("Couldn't open link: {}", throwable == null ? "<UNKNOWN>" : throwable.getMessage());
        }

    }

    public static boolean isCtrlKeyDown() {
        if (Minecraft.IS_RUNNING_ON_MAC) {
            return Keyboard.isKeyDown(219) || Keyboard.isKeyDown(220);
        } else {
            return Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157);
        }
    }

    public static boolean isShiftKeyDown() {
        return Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54);
    }

    public static boolean isAltKeyDown() {
        return Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184);
    }

    public static boolean isKeyComboCtrlX(int p_isKeyComboCtrlX_0_) {
        return p_isKeyComboCtrlX_0_ == 45 && isCtrlKeyDown() && !isShiftKeyDown() && !isAltKeyDown();
    }

    public static boolean isKeyComboCtrlV(int p_isKeyComboCtrlV_0_) {
        return p_isKeyComboCtrlV_0_ == 47 && isCtrlKeyDown() && !isShiftKeyDown() && !isAltKeyDown();
    }

    public static boolean isKeyComboCtrlC(int p_isKeyComboCtrlC_0_) {
        return p_isKeyComboCtrlC_0_ == 46 && isCtrlKeyDown() && !isShiftKeyDown() && !isAltKeyDown();
    }

    public static boolean isKeyComboCtrlA(int p_isKeyComboCtrlA_0_) {
        return p_isKeyComboCtrlA_0_ == 30 && isCtrlKeyDown() && !isShiftKeyDown() && !isAltKeyDown();
    }

    public void onResize(Minecraft p_onResize_1_, int p_onResize_2_, int p_onResize_3_) {
        this.setWorldAndResolution(p_onResize_1_, p_onResize_2_, p_onResize_3_);
    }
}
