//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package net.minecraft.util;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class Timer {
    public int elapsedTicks;
    public float renderPartialTicks;
    public float elapsedPartialTicks;
    private long lastSyncSysClock;
    public float tickLength;

    public Timer(float p_i1018_1_) {
        this.tickLength = 1000.0F / p_i1018_1_;
        this.lastSyncSysClock = Minecraft.getSystemTime();
    }

    public void updateTimer() {
        long lvt_1_1_ = Minecraft.getSystemTime();
        this.elapsedPartialTicks = (float)(lvt_1_1_ - this.lastSyncSysClock) / this.tickLength;
        this.lastSyncSysClock = lvt_1_1_;
        this.renderPartialTicks += this.elapsedPartialTicks;
        this.elapsedTicks = (int)this.renderPartialTicks;
        this.renderPartialTicks -= (float)this.elapsedTicks;
    }
}
