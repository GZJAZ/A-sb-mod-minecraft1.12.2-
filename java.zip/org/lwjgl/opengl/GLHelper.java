/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.lwjgl.opengl.ContextCapabilities
 *  org.lwjgl.opengl.GLContext
 */
package org.lwjgl.opengl;

import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GLContext;

public class GLHelper {
    public static final ContextCapabilities caps = GLContext.getCapabilities();
    public static final long glPushMatrix = GLContext.getFunctionAddress((String)"glPushMatrix");
    public static final long glEnable = GLContext.getFunctionAddress((String)"glEnable");
    public static final long glDisable = GLContext.getFunctionAddress((String)"glDisable");
    public static final long glLoadIdentity = GLContext.getFunctionAddress((String)"glLoadIdentity");
    public static final long glPopMatrix = GLContext.getFunctionAddress((String)"glPopMatrix");
}

