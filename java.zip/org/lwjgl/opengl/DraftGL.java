/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.IntBuffer
 *  org.lwjgl.LWJGLUtil
 *  org.lwjgl.MemoryUtil
 *  org.lwjgl.opengl.APIUtil
 *  org.lwjgl.opengl.ARBMultitexture
 *  org.lwjgl.opengl.ContextCapabilities
 *  org.lwjgl.opengl.EXTFramebufferObject
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL13
 *  org.lwjgl.opengl.GL20
 *  org.lwjgl.opengl.GL30
 *  org.lwjgl.opengl.References
 *  org.lwjgl.opengl.StateTracker
 */
package org.lwjgl.opengl;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.LWJGLUtil;
import org.lwjgl.MemoryUtil;
import org.lwjgl.opengl.APIUtil;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.DefaultGL;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.References;
import org.lwjgl.opengl.StateTracker;

public class DraftGL {
    public DraftGL() {
        System.loadLibrary((String)"glfw");
        System.loadLibrary((String)"jemalloc");
        System.loadLibrary((String)"lwjgl");
        System.loadLibrary((String)"lwjgl_opengl");
        System.loadLibrary((String)"lwjgl_stb");
        System.loadLibrary((String)"lwjgl_tinyfd");
        System.loadLibrary((String)"OpenAL");
        System.loadLibrary((String)"SAPIWrapper_x64");
    }

    public static void glDrawArrays(int mode, int first, int count) {
        long function_pointer = DefaultGL.glDrawArrays;
        GL11.nglDrawArrays((int)mode, (int)first, (int)count, (long)function_pointer);
    }

    public static void glEnd() {
        ContextCapabilities caps = DefaultGL.caps;
        long function_pointer = DefaultGL.glEnd;
        GL11.nglEnd((long)function_pointer);
    }

    public static void glTexCoord2f(float s, float t) {
        ContextCapabilities caps = DefaultGL.caps;
        long function_pointer = DefaultGL.glTexCoord2f;
        GL11.nglTexCoord2f((float)s, (float)t, (long)function_pointer);
    }

    public static void glBegin(int mode) {
        ContextCapabilities caps = DefaultGL.caps;
        long function_pointer = DefaultGL.glBegin;
        GL11.nglBegin((int)mode, (long)function_pointer);
    }

    public static void glVertex3f(float x, float y, float z) {
        long function_pointer = DefaultGL.glVertex3f;
        GL11.nglVertex3f((float)x, (float)y, (float)z, (long)function_pointer);
    }

    public static void glVertexPointer(int size, int type, int stride, ByteBuffer pointer) {
        ContextCapabilities caps = DefaultGL.caps;
        long function_pointer = DefaultGL.glVertexPointer;
        if (LWJGLUtil.CHECKS) {
            StateTracker.getReferences((ContextCapabilities)caps).GL11_glVertexPointer_pointer = pointer;
        }
        GL11.nglVertexPointer((int)size, (int)type, (int)stride, (long)MemoryUtil.getAddress((ByteBuffer)pointer), (long)function_pointer);
    }

    public static int glGenTextures() {
        long function_pointer = DefaultGL.glGenTextures;
        IntBuffer textures = APIUtil.getBufferInt((ContextCapabilities)DefaultGL.caps);
        GL11.nglGenTextures((int)1, (long)MemoryUtil.getAddress((IntBuffer)textures), (long)function_pointer);
        return textures.get(0);
    }

    public static void nglBindFramebufferEXT(int target, int framebuffer) {
        long function_pointer = DefaultGL.glBindFramebufferEXT;
        EXTFramebufferObject.nglBindFramebufferEXT((int)target, (int)framebuffer, (long)function_pointer);
    }

    public static int glGenFramebuffers() {
        long function_pointer = DefaultGL.glGenFramebuffers;
        IntBuffer framebuffers = APIUtil.getBufferInt((ContextCapabilities)DefaultGL.caps);
        GL30.nglGenFramebuffers((int)1, (long)MemoryUtil.getAddress((IntBuffer)framebuffers), (long)function_pointer);
        return framebuffers.get(0);
    }

    public static int glGenFramebuffersEXT() {
        long function_pointer = DefaultGL.glGenFramebuffersEXT;
        IntBuffer framebuffers = APIUtil.getBufferInt((ContextCapabilities)DefaultGL.caps);
        EXTFramebufferObject.nglGenFramebuffersEXT((int)1, (long)MemoryUtil.getAddress((IntBuffer)framebuffers), (long)function_pointer);
        return framebuffers.get(0);
    }

    public static void glClientActiveTextureARB(int texture) {
        long function_pointer = DefaultGL.glClientActiveTextureARB;
        ARBMultitexture.nglClientActiveTextureARB((int)texture, (long)function_pointer);
    }

    public static void nglEnable(int cap) {
        long function_pointer = DefaultGL.glEnable;
        GL11.nglEnable((int)cap, (long)function_pointer);
    }

    public static void nglDisable(int cap) {
        long function_pointer = DefaultGL.glDisable;
        GL11.nglDisable((int)cap, (long)function_pointer);
    }

    public static void glShadeModel(int mode) {
        long function_pointer = DefaultGL.glShadeModel;
        GL11.nglShadeModel((int)mode, (long)function_pointer);
    }

    public static void ortho(double left, double right, double bottom, double top, double zNear, double zFar) {
        long function_pointer = DefaultGL.glOrtho;
        GL11.nglOrtho((double)left, (double)right, (double)bottom, (double)top, (double)zNear, (double)zFar, (long)function_pointer);
    }

    public static void nglClear(int mask) {
        long function_pointer = DefaultGL.glClear;
        GL11.nglClear((int)mask, (long)function_pointer);
    }

    public static void glBindFramebuffer(int target, int framebufferIn) {
        DraftGL.nglBindFramebuffer(target, framebufferIn);
    }

    public static void nglPopMatrix() {
        long function_pointer = DefaultGL.glPopMatrix;
        GL11.nglPopMatrix((long)function_pointer);
    }

    public static void nglPushMatrix() {
        long function_pointer = DefaultGL.glPushMatrix;
        GL11.nglPushMatrix((long)function_pointer);
    }

    public static void nglBindFramebuffer(int target, int framebufferIn) {
        long function_pointer = DefaultGL.glBindFramebuffer;
        GL30.nglBindFramebuffer((int)target, (int)framebufferIn, (long)function_pointer);
    }

    public static void setState(int cap) {
        long function_pointer = DefaultGL.glDisable;
        GL11.nglDisable((int)cap, (long)function_pointer);
    }

    public static void translate(float x, float y, float z) {
        long function_pointer = DefaultGL.glTranslatef;
        GL11.nglTranslatef((float)x, (float)y, (float)z, (long)function_pointer);
    }

    public static void color(float red, float green, float blue, float alpha) {
        long function_pointer = DefaultGL.glColor4f;
        GL11.nglColor4f((float)red, (float)green, (float)blue, (float)alpha, (long)function_pointer);
    }

    public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha) {
        long function_pointer = DefaultGL.glColorMask;
        GL11.nglColorMask((boolean)red, (boolean)green, (boolean)blue, (boolean)alpha, (long)function_pointer);
    }

    public static void depthMask(boolean flagIn) {
        long function_pointer = DefaultGL.glDepthMask;
        GL11.nglDepthMask((boolean)flagIn, (long)function_pointer);
    }

    public static void popMatrix() {
        long function_pointer = DefaultGL.glPopMatrix;
        GL11.nglPopMatrix((long)function_pointer);
    }

    public static void shadeModel(int mode) {
        long function_pointer = DefaultGL.glShadeModel;
        GL11.nglShadeModel((int)mode, (long)function_pointer);
    }

    public static void loadIdentity() {
        long function_pointer = DefaultGL.glLoadIdentity;
        GL11.nglLoadIdentity((long)function_pointer);
    }

    public static void clear(int mask) {
        long function_pointer = DefaultGL.glClear;
        GL11.nglClear((int)mask, (long)function_pointer);
    }

    public static void bindTexture(int texture) {
        long function_pointer = DefaultGL.glBindTexture;
        GL11.nglBindTexture((int)3553, (int)texture, (long)function_pointer);
    }

    public static void glTexParameteri(int target, int parameterName, int parameter) {
        long function_pointer = DefaultGL.glTexParameteri;
        GL11.nglTexParameteri((int)target, (int)parameterName, (int)parameter, (long)function_pointer);
    }

    public static void glPushMatrix() {
        long function_pointer = DefaultGL.glPushMatrix;
        GL11.nglPushMatrix((long)function_pointer);
    }

    public static void glScalef(float x, float y, float z) {
        long function_pointer = DefaultGL.glScalef;
        GL11.nglScalef((float)x, (float)y, (float)z, (long)function_pointer);
    }

    public static void matrixMode(int mode) {
        long function_pointer = DefaultGL.glMatrixMode;
        GL11.nglMatrixMode((int)mode, (long)function_pointer);
    }

    public static void glPopMatrix() {
        long function_pointer = DefaultGL.glPopMatrix;
        GL11.nglPopMatrix((long)function_pointer);
    }

    public static void pushMatrix() {
        long function_pointer = DefaultGL.glPushMatrix;
        GL11.nglPushMatrix((long)function_pointer);
    }

    public static void viewport(int x, int y, int width, int height) {
        long function_pointer = DefaultGL.glViewport;
        GL11.nglViewport((int)x, (int)y, (int)width, (int)height, (long)function_pointer);
    }

    public static void glDisableVertexAttribArray(int index) {
        long function_pointer = DefaultGL.glDisableVertexAttribArray;
        GL20.nglDisableVertexAttribArray((int)index, (long)function_pointer);
    }

    public static void glEnableVertexAttribArray(int index) {
        long function_pointer = DefaultGL.glEnableVertexAttribArray;
        GL20.nglEnableVertexAttribArray((int)index, (long)function_pointer);
    }

    public static void glVertexAttribPointer(int index, int size, int type, boolean normalized, int stride, ByteBuffer buffer) {
        long function_pointer = DefaultGL.glVertexAttribPointer;
        if (LWJGLUtil.CHECKS) {
            StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).glVertexAttribPointer_buffer[index] = buffer;
        }
        GL20.nglVertexAttribPointer((int)index, (int)size, (int)type, (boolean)normalized, (int)stride, (long)MemoryUtil.getAddress((ByteBuffer)buffer), (long)function_pointer);
    }

    public static void glEnableClientState(int cap) {
        long function_pointer = DefaultGL.glEnableClientState;
        GL11.nglEnableClientState((int)cap, (long)function_pointer);
    }

    public static void glTexCoordPointer(int size, int type, int stride, ByteBuffer pointer) {
        long function_pointer = DefaultGL.glTexCoordPointer;
        if (LWJGLUtil.CHECKS) {
            StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).glTexCoordPointer_buffer[StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).glClientActiveTexture] = pointer;
        }
        GL11.nglTexCoordPointer((int)size, (int)type, (int)stride, (long)MemoryUtil.getAddress((ByteBuffer)pointer), (long)function_pointer);
    }

    public static void glDisableClientState(int cap) {
        long function_pointer = DefaultGL.glDisableClientState;
        GL11.nglDisableClientState((int)cap, (long)function_pointer);
    }

    public static void glClientActiveTexture(int texture) {
        long function_pointer = DefaultGL.glClientActiveTexture;
        StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).glClientActiveTexture = texture - 33984;
        GL13.nglClientActiveTexture((int)texture, (long)function_pointer);
    }

    public static void glColorPointer(int size, int type, int stride, ByteBuffer pointer) {
        long function_pointer = DefaultGL.glColorPointer;
        if (LWJGLUtil.CHECKS) {
            StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).GL11_glColorPointer_pointer = pointer;
        }
        GL11.nglColorPointer((int)size, (int)type, (int)stride, (long)MemoryUtil.getAddress((ByteBuffer)pointer), (long)function_pointer);
    }

    public static void glNormalPointer(int type, int stride, ByteBuffer pointer) {
        long function_pointer = DefaultGL.glNormalPointer;
        if (LWJGLUtil.CHECKS) {
            StateTracker.getReferences((ContextCapabilities)DefaultGL.caps).GL11_glNormalPointer_pointer = pointer;
        }
        GL11.nglNormalPointer((int)type, (int)stride, (long)MemoryUtil.getAddress((ByteBuffer)pointer), (long)function_pointer);
    }
}

