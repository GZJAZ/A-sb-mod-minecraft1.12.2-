/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.lwjgl.opengl.ContextCapabilities
 *  org.lwjgl.opengl.GLContext
 */
package org.lwjgl.opengl;

import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GLContext;

public class DefaultGL {
    public static ContextCapabilities caps = GLContext.getCapabilities();
    public static long glPushMatrix = GLContext.getFunctionAddress((String)"glPushMatrix");
    public static long glOrtho = GLContext.getFunctionAddress((String)"glOrtho");
    public static long glClear = GLContext.getFunctionAddress((String)"glClear");
    public static long glShadeModel = GLContext.getFunctionAddress((String)"glShadeModel");
    public static long glPopMatrix = GLContext.getFunctionAddress((String)"glPopMatrix");
    public static long glBindFramebuffer = GLContext.getFunctionAddress((String)"glBindFramebuffer");
    public static long glDisable = GLContext.getFunctionAddress((String)"glDisable");
    public static long glTranslatef = GLContext.getFunctionAddress((String)"glTranslatef");
    public static long glColor4f = GLContext.getFunctionAddress((String)"glColor4f");
    public static long glColorMask = GLContext.getFunctionAddress((String)"glColorMask");
    public static long glLoadIdentity = GLContext.getFunctionAddress((String)"glLoadIdentity");
    public static long glBindTexture = GLContext.getFunctionAddress((String)"glBindTexture");
    public static long glTexParameteri = GLContext.getFunctionAddress((String)"glTexParameteri");
    public static long glScalef = GLContext.getFunctionAddress((String)"glScalef");
    public static long glMatrixMode = GLContext.getFunctionAddress((String)"glMatrixMode");
    public static long glViewport = GLContext.getFunctionAddress((String)"glViewport");
    public static long glDepthMask = GLContext.getFunctionAddress((String)"glDepthMask");
    public static long glDisableClientState = GLContext.getFunctionAddress((String)"glDisableClientState");
    public static long glClientActiveTexture = GLContext.getFunctionAddress((String)"glClientActiveTexture");
    public static long glClientActiveTextureARB = GLContext.getFunctionAddress((String)"glClientActiveTextureARB");
    public static long glDisableVertexAttribArray = GLContext.getFunctionAddress((String)"glDisableVertexAttribArray");
    public static long glEnable = GLContext.getFunctionAddress((String)"glEnable");
    public static long glVertexPointer = GLContext.getFunctionAddress((String)"glVertexPointer");
    public static long glEnableClientState = GLContext.getFunctionAddress((String)"glEnableClientState");
    public static long glTexCoordPointer = GLContext.getFunctionAddress((String)"glTexCoordPointer");
    public static long glEnableVertexAttribArray = GLContext.getFunctionAddress((String)"glTexCoordPointer");
    public static long glVertexAttribPointer = GLContext.getFunctionAddress((String)"glVertexAttribPointer");
    public static long glDrawArrays = GLContext.getFunctionAddress((String)"glDrawArrays");
    public static long glColorPointer = GLContext.getFunctionAddress((String)"glDrawArrays");
    public static long glNormalPointer = GLContext.getFunctionAddress((String)"glNormalPointer");
    public static long glBindFramebufferEXT = GLContext.getFunctionAddress((String)"glBindFramebufferEXT");
    public static long glGenFramebuffers = GLContext.getFunctionAddress((String)"glGenFramebuffers");
    public static long glGenFramebuffersEXT = GLContext.getFunctionAddress((String)"glGenFramebuffersEXT");
    public static long glGenTextures = GLContext.getFunctionAddress((String)"glGenTextures");
    public static long glVertex3f = GLContext.getFunctionAddress((String)"glVertex3f");
    public static long glBegin = GLContext.getFunctionAddress((String)"glBegin");
    public static long glTexCoord2f = GLContext.getFunctionAddress((String)"glTexCoord2f");
    public static long glEnd = GLContext.getFunctionAddress((String)"glEnd");

    public static void Render() {
        caps = GLContext.getCapabilities();
        glPushMatrix = GLContext.getFunctionAddress((String)"glPushMatrix");
        glOrtho = GLContext.getFunctionAddress((String)"glOrtho");
        glClear = GLContext.getFunctionAddress((String)"glClear");
        glShadeModel = GLContext.getFunctionAddress((String)"glShadeModel");
        glPopMatrix = GLContext.getFunctionAddress((String)"glPopMatrix");
        glBindFramebuffer = GLContext.getFunctionAddress((String)"glBindFramebuffer");
        glDisable = GLContext.getFunctionAddress((String)"glDisable");
        glTranslatef = GLContext.getFunctionAddress((String)"glTranslatef");
        glColor4f = GLContext.getFunctionAddress((String)"glColor4f");
        glColorMask = GLContext.getFunctionAddress((String)"glColorMask");
        glLoadIdentity = GLContext.getFunctionAddress((String)"glLoadIdentity");
        glBindTexture = GLContext.getFunctionAddress((String)"glBindTexture");
        glTexParameteri = GLContext.getFunctionAddress((String)"glTexParameteri");
        glScalef = GLContext.getFunctionAddress((String)"glScalef");
        glMatrixMode = GLContext.getFunctionAddress((String)"glMatrixMode");
        glViewport = GLContext.getFunctionAddress((String)"glViewport");
        glDepthMask = GLContext.getFunctionAddress((String)"glDepthMask");
        glDisableClientState = GLContext.getFunctionAddress((String)"glDisableClientState");
        glClientActiveTexture = GLContext.getFunctionAddress((String)"glClientActiveTexture");
        glClientActiveTextureARB = GLContext.getFunctionAddress((String)"glClientActiveTextureARB");
        glDisableVertexAttribArray = GLContext.getFunctionAddress((String)"glDisableVertexAttribArray");
        glEnable = GLContext.getFunctionAddress((String)"glEnable");
        glVertexPointer = GLContext.getFunctionAddress((String)"glVertexPointer");
        glEnableClientState = GLContext.getFunctionAddress((String)"glEnableClientState");
        glTexCoordPointer = GLContext.getFunctionAddress((String)"glTexCoordPointer");
        glEnableVertexAttribArray = GLContext.getFunctionAddress((String)"glTexCoordPointer");
        glVertexAttribPointer = GLContext.getFunctionAddress((String)"glVertexAttribPointer");
        glDrawArrays = GLContext.getFunctionAddress((String)"glDrawArrays");
        glColorPointer = GLContext.getFunctionAddress((String)"glDrawArrays");
        glNormalPointer = GLContext.getFunctionAddress((String)"glNormalPointer");
        glBindFramebufferEXT = GLContext.getFunctionAddress((String)"glBindFramebufferEXT");
        glGenFramebuffers = GLContext.getFunctionAddress((String)"glGenFramebuffers");
        glGenFramebuffersEXT = GLContext.getFunctionAddress((String)"glGenFramebuffersEXT");
        glGenTextures = GLContext.getFunctionAddress((String)"glGenTextures");
        glVertex3f = GLContext.getFunctionAddress((String)"glVertex3f");
        glBegin = GLContext.getFunctionAddress((String)"glBegin");
        glTexCoord2f = GLContext.getFunctionAddress((String)"glTexCoord2f");
        glEnd = GLContext.getFunctionAddress((String)"glEnd");
    }
}

